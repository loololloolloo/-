'use strict';
/*
 * Retro Goal browser reconstruction — audited runtime pass.
 *
 * Provenance rule:
 *   [APK-DIRECT] = recovered resource/name/data from game.droid/libyoyo.so.
 *   [REIMPLEMENTED] = browser implementation of behavior evidenced by YYC/GML symbols.
 *   [APPROX] = behavior not numerically recoverable from the stripped YYC build.
 *
 * The renderer and recovered assets are intentionally retained from the previous build.
 */
const C=document.getElementById('game'),X=C.getContext('2d'); X.imageSmoothingEnabled=false;
const W=C.width,H=C.height,A='assets/';
const imgCache=new Map();
function img(src){if(!imgCache.has(src)){const i=new Image();i.src=A+src;imgCache.set(src,i)}return imgCache.get(src)}
function loadImage(src){return new Promise((resolve)=>{
  const i=img(src);
  if(i.complete && i.naturalWidth>0){resolve(i);return}
  const done=()=>resolve(i);
  i.onload=done; i.onerror=done;
})}
let teams=[],titleFont,bodyFont;
async function loadFont(name){const meta=name==='title'?window.FONT_TITLE:window.FONT_BODY;const im=await loadImage('fonts/'+name+'.png');return {meta,im}}
const keys={
 idleS:n=>`frames/spr_player_idle_stripes/${String(n%2).padStart(2,'0')}.png`,runS:n=>`frames/spr_player_run_stripes/${String(n%8).padStart(2,'0')}.png`,kickS:n=>`frames/spr_player_kick_stripes/${String(n%5).padStart(2,'0')}.png`,passS:n=>`frames/spr_player_pass_stripes/00.png`,slideS:n=>`frames/spr_player_slide_stripes/${String(n%3).padStart(2,'0')}.png`,
 idleH:n=>`frames/spr_player_idle_hoops/${String(n%2).padStart(2,'0')}.png`,runH:n=>`frames/spr_player_run_hoops/${String(n%8).padStart(2,'0')}.png`,kickH:n=>`frames/spr_player_kick_hoops/${String(n%5).padStart(2,'0')}.png`,passH:n=>`frames/spr_player_pass_hoops/00.png`,slideH:n=>`frames/spr_player_slide_hoops/${String(n%3).padStart(2,'0')}.png`,
 ballS:n=>`frames/spr_ball1/${String(n%6).padStart(2,'0')}.png`,ballH:n=>`frames/spr_ball2/${String(n%6).padStart(2,'0')}.png`
};
const field=img('field.png'),logo=img('recovered_sprites/223_spr_title_logo.png'),splash=img('splash.png'),button=img('button.png'),scoreboard=img('scoreboard.png');
const visual={
  titleBg:img('recovered_sprites/162_spr_title_background_wide.png'),
  titleLogo:img('recovered_sprites/223_spr_title_logo.png'),
  titlePlayer:img('recovered_sprites/258_spr_title_player.png'),
  titleBall:img('recovered_sprites/034_spr_title_ball.png'),
  titleOverlay:img('recovered_sprites/283_spr_title_digitaloverlay_wide.png'),
  copyright:img('recovered_sprites/176_spr_title_copyright.png'),
  matchHeader:img('recovered_sprites/204_spr_header.png'),
  goalFore:img('recovered_sprites/123_spr_goal_fore.png'),
  goalBack:img('recovered_sprites/270_spr_goal_back.png'),
  highlight:img('recovered_sprites/051_spr_player_highlight.png'),
  star:img('frames_gm/spr_player_highlight2/00.png'),
  goalFore:img('recovered_sprites/123_spr_goal_fore.png'),
  goalBack:img('recovered_sprites/270_spr_goal_back.png')
};
const SPRITE_ORIGIN={player:{x:16,y:29},highlight:{x:16,y:7},goal:{x:0,y:96}};
// [APK-DIRECT] The native clothes shader uses these exact 12-bit palette key colours.
// Reimplementing the shader on Canvas removes the rainbow placeholder colours from the raw atlas.
const KIT_KEYS={
  // [APK-DIRECT] These keys partition the 12 flat placeholder colours used by the
  // clothes shader into its semantic channels. The player atlas is intentionally
  // rainbow-coloured until this shader pass is applied.
  hair:'#ff0000',
  shirt:'#ffff00',shirt2:'#808000',
  skin:'#00ff00',skin2:'#008000',
  shorts:'#0000ff',shorts2:'#800080',
  socks:'#00ffff',socks2:'#008080',
  stripes:'#ff00ff',stripes2:'#000080',
  boots:'#000000'
};
const playerRasterCache=new Map();
const playerHeadMaskCache=new Map();
function parseHex(h){h=(h||'#ffffff').replace('#','');return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
function darken(h,f=.72){const [r,g,b]=parseHex(h);return '#'+[r,g,b].map(v=>Math.round(v*f).toString(16).padStart(2,'0')).join('');}
function playerKit(team,away,variant=0){
  const primary=away?team.away1:team.home1, secondary=away?team.away2:team.home2, shorts=team.shorts||secondary;
  const skins=['#eec39a','#ba8857','#5d3324'], hairs=['#fac80a','#5a2d08','#141414'];
  return {shirt:primary,shirt2:darken(primary),stripes:secondary,stripes2:darken(secondary),shorts,shorts2:darken(shorts),socks:primary,socks2:darken(primary),
    skin:skins[variant%skins.length],skin2:skins[(variant+1)%skins.length],hair:hairs[variant%hairs.length],boots:'#141414'};
}
function buildPlayerHeadMask(im,px,w,h){
  const cacheKey=im.src+'|'+w+'x'+h; const cached=playerHeadMaskCache.get(cacheKey); if(cached)return cached;
  // The source artwork is a real indexed/palette-style texture. Hair/skin are
  // the semantic seeds in that texture. Other palette colours are reused as
  // pixel-art shading inside the head, so a blind global kit replacement paints
  // jersey colours onto faces. Build the mask from the recovered pixels rather
  // than drawing an invented ellipse.
  const srcHair=srcRGB.hair, srcSkin=srcRGB.skin, srcSkin2=srcRGB.skin2;
  const mask=new Uint8Array(w*h), queue=[];
  for(let y=0;y<Math.min(18,h);y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4, rgb=[px[i],px[i+1],px[i+2]];
    if(px[i+3]===255 && (sameRGB(rgb,srcHair)||sameRGB(rgb,srcSkin)||sameRGB(rgb,srcSkin2))){
      mask[y*w+x]=1; queue.push(x,y);
    }
  }
  let head=0;
  while(head<queue.length){
    const x=queue[head++],y=queue[head++];
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=w||ny>=Math.min(18,h))continue;
      const mi=ny*w+nx;if(mask[mi])continue;const pi=mi*4;if(px[pi+3]!==255)continue;
      mask[mi]=1;queue.push(nx,ny);
    }
  }
  playerHeadMaskCache.set(cacheKey,mask);return mask;
}
function sameRGB(a,b){return a[0]===b[0]&&a[1]===b[1]&&a[2]===b[2]}
const srcRGB={};for(const [k,v] of Object.entries(KIT_KEYS))srcRGB[k]=parseHex(v);
function nearestHeadSemantic(px,i,mask,w,h){
  let best=null,bestD=1e9;
  // Find the nearest recovered hair/skin semantic pixel. This keeps the source
  // texture untouched while preventing shared palette shading from becoming a
  // team colour on the face/head.
  for(let r=1;r<=8 && !best;r++){
    for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){
      if(Math.max(Math.abs(dx),Math.abs(dy))!==r)continue;
      const x=(i/4)%w+dx,y=Math.floor((i/4)/w)+dy;if(x<0||y<0||x>=w||y>=h)continue;
      const j=(y*w+x)*4;if(px[j+3]!==255)continue;
      const rgb=[px[j],px[j+1],px[j+2]];
      let semantic=null;if(sameRGB(rgb,srcRGB.hair))semantic='hair';else if(sameRGB(rgb,srcRGB.skin))semantic='skin';else if(sameRGB(rgb,srcRGB.skin2))semantic='skin2';
      if(semantic){best=semantic;bestD=r;break}
    }
  }
  return best||'hair';
}
function recolorPlayerImage(im,kitKey){
  const key=kitKey+'|'+im.src; const hit=playerRasterCache.get(key); if(hit)return hit;
  if(!im.complete||!im.naturalWidth)return im;
  const c=document.createElement('canvas');c.width=im.naturalWidth;c.height=im.naturalHeight;const g=c.getContext('2d',{willReadFrequently:true});
  g.imageSmoothingEnabled=false;g.drawImage(im,0,0);const d=g.getImageData(0,0,c.width,c.height),px=d.data;
  const map={}; for(const [k,v] of Object.entries(KIT_KEYS))map[k]=parseHex(kitKeyObj[kitKey]?.[k]||'#ffffff');
  const headMask=buildPlayerHeadMask(im,px,c.width,c.height);
  const src=srcRGB;
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
    const i=(y*c.width+x)*4;if(px[i+3]!==255)continue;
    let k=null;for(const name of Object.keys(src)){const a=src[name];if(px[i]===a[0]&&px[i+1]===a[1]&&px[i+2]===a[2]){k=name;break}}
    if(!k)continue;
    // [APK-DIRECT] Native sh_ColorReplaceClip performs a global RGB-key replacement.
    // Do not apply a browser-invented head-region correction.
    const q=map[k];px[i]=q[0];px[i+1]=q[1];px[i+2]=q[2];
  }
  g.putImageData(d,0,0);playerRasterCache.set(key,c);return c;
}
const kitKeyObj={};
function kitId(team,away,variant=0){return team.id+'_'+(away?'away':'home')+'_'+(variant%3);}
function prepareKit(team,away,variant=0){const id=kitId(team,away,variant);kitKeyObj[id]=playerKit(team,away,variant);return id;}
function playerFrameImage(p,src){const team=teams[p.team===0?state.home:state.away];const id=prepareKit(team,p.team===1,p.idx);return recolorPlayerImage(img(src),id)}
let audio=null; function startMusic(){if(audio)return;audio=new Audio('assets/track1.ogg');audio.loop=true;audio.volume=.32;audio.play().catch(()=>{})}

// [APK-DIRECT] match pitch resources and the match controller/ball/player object model are present in the APK.
const MATCH_ROOM={width:1743,height:530};
const PITCH={left:95,right:1648,top:140,bottom:487,goalLeft:95,goalRight:1648,goalTop:265,goalBottom:378,centerX:871.5,centerY:313.5};
function cameraTarget(){const p=state.players[state.controlled],focus=p||state.ball;if(!focus)return 0;return clamp(focus.x-W*.5,0,MATCH_ROOM.width-W)}
function updateMatchCamera(dt){const target=cameraTarget(),response=1-Math.exp(-dt*8);state.cam+=(target-state.cam)*response;if(Math.abs(state.cam-target)<.05)state.cam=target}
const state={screen:'title',home:0,away:1,menu:0,selectSide:0,cam:0,score:[0,0],clock:0,half:1,paused:false,ended:false,flash:0,flashText:'',controlled:1,drag:null,players:[],ball:null,particles:[],restart:null,offside:null,events:[],last:performance.now(),kickCooldown:0,matchSpeed:1,seed:0,runtimeRoom:'room_title',roomMenu:0,homeUI:{selected:0,hover:-1,pressed:-1,buttons:[],continueTarget:'room_field',lastAction:null},title:{phase:'intro',stage:0,t:0,stageTime:0,outDelay:0,fade:0,ready:false,playerX:-230,ballX:-40,ballY:180,ballVx:185,ballVy:-95,opacity:0,xTitle:0,yTitle:134,xScroll:0,yScroll:0,xCopy:0,yCopy:240,sTitle:200,sBall:124,rBall:1,continueRequested:false,pendingConfirm:false,playerAnimation:null,ballAnimation:null},transition:null};
const keysDown=new Set();
// [REIMPLEMENTED] Match loop state. Keep simulation independent of render-frame cadence so
// a backgrounded Chromebook tab cannot make the match appear frozen.
const loopState={last:performance.now(),accumulator:0,step:1/60,started:false};
// [REIMPLEMENTED] GameMaker-style animation player.  SPRITE_META is recovered from SPRT;
// callers provide the same image-speed/state concepts rather than hand-picking PNGs.
// [REIMPLEMENTED/B] Generic GameMaker-style sprite animation. Frame metadata is
// recovered from SPRT/TPAG; timing is normalized to frames/second where exact
// image_speed is not readable from the stripped YYC build.
class GMAnimation{
  constructor(spriteName,imageSpeed=0){this.sprite=spriteName;this.imageSpeed=imageSpeed;this.imageIndex=0;this.playing=true;this.loop=true;this.time=0;this.onFrame=null}
  meta(){return window.GM_ANIMATION_DATA?.sprites?.[this.sprite] || (window.SPRITE_META||{})[this.sprite] || {frames:1,w:0,h:0,ox:0,oy:0}}
  frames(){const m=this.meta();return Math.max(1,Array.isArray(m.frames)?m.frames.length:(m.frames||1))}
  set(spriteName,imageSpeed=this.imageSpeed){if(this.sprite!==spriteName){this.sprite=spriteName;this.imageIndex=0;this.time=0}this.imageSpeed=imageSpeed;this.playing=true;return this}
  reset(){this.imageIndex=0;this.time=0;return this}
  update(dt){if(!this.playing)return;const n=this.frames(),before=Math.floor(this.imageIndex);this.time+=dt;this.imageIndex+=dt*this.imageSpeed;if(this.loop)this.imageIndex=((this.imageIndex%n)+n)%n;else if(this.imageIndex>=n-1){this.imageIndex=n-1;this.playing=false}const after=Math.floor(this.imageIndex);if(after!==before&&this.onFrame)this.onFrame(after,this)}
  frame(){return Math.min(this.frames()-1,Math.max(0,Math.floor(this.imageIndex)))}
  frameData(){const m=this.meta(),f=Array.isArray(m.frames)?m.frames[this.frame()]:null;return f||{index:this.frame(),path:null,texturePage:null,sourceX:0,sourceY:0,sourceW:m.w||0,sourceH:m.h||0,targetX:0,targetY:0,targetW:m.w||0,targetH:m.h||0}}
  framePath(){const f=this.frameData();return f.path?(f.path.startsWith('assets/')?f.path.slice(7):f.path):null}
}
// [REIMPLEMENTED] Shared sprite draw primitive using recovered origins.
function drawGMAnimation(anim,x,y,opts={}){const m=anim.meta(),path=anim.framePath();if(!path)return false;const im=img(path);if(!im.complete)return false;const sx=(opts.scaleX??1)*(opts.flipX?-1:1),sy=opts.scaleY??1;X.save();X.globalAlpha*=opts.alpha??1;X.translate(x,y);if(opts.rotation)X.rotate(opts.rotation);X.scale(sx,sy);X.drawImage(im,Math.round(-(m.ox??0)),Math.round(-(m.oy??0)),m.w||im.naturalWidth,m.h||im.naturalHeight);X.restore();return true}
state.title.playerAnimation=new GMAnimation('spr_title_player',0);state.title.ballAnimation=new GMAnimation('spr_title_ball',0);
// [REIMPLEMENTED] One browser input path. DOM events are translated into game actions;
// individual rooms do not install ad-hoc click handlers.
const InputManager={
  dispatch(action,payload={}){
    if(state.screen==='title' && action==='confirm'){
      if(state.title.ready){startMusic();Runtime.titleContinue();return true}
      if(state.title.stage===0){state.title.pendingConfirm=true;return true}
      return true
    }
    if(state.screen==='system'){
      if(state.runtimeRoom==='room_home'){
        if(action==='up'){HomeUI.move(-1);return true}
        if(action==='down'){HomeUI.move(1);return true}
        if(action==='confirm'){return HomeUI.confirm()}
        if(action==='back'){Runtime.enter('room_title','home-back');return true}
        return true;
      }
      if(action==='up'){state.homeUI.selected=Math.max(0,(state.homeUI.selected<0?0:state.homeUI.selected-1));return true}
      if(action==='down'){state.homeUI.selected=Math.min(3,(state.homeUI.selected<0?0:state.homeUI.selected+1));return true}
      if(action==='left'||action==='right'){return true}
      if(action==='back'){Runtime.enter('room_home');return true}
      if(action==='confirm'){Runtime.enter(Runtime.next(state.runtimeRoom));return true}
      return true;
    }
    if(state.screen==='select'){
      if(action==='left'||action==='right'){
        const d=action==='left'?-1:1;
        if(state.selectSide===0)state.home=(state.home+d+teams.length)%teams.length;
        else state.away=(state.away+d+teams.length)%teams.length;
        if(state.away===state.home)state.away=(state.away+d+teams.length)%teams.length;
        return true;
      }
      if(action==='switch') {state.selectSide=1-state.selectSide;return true}
      if(action==='confirm'){startMusic();Runtime.enter('room_field');return true}
      if(action==='back'){Runtime.enter('room_home');return true}
      return true;
    }
    if(state.screen==='match'){
      if(action==='confirm' && state.ended){Runtime.enter('room_results');return true}
      if(action==='pass'){humanPass();return true}
      if(action==='shoot'){const p=state.players[state.controlled];if(p)humanKick((p.team===0?PITCH.goalRight:PITCH.goalLeft)-state.cam,PITCH.centerY,7);return true}
      if(action==='tackle'){humanTackle();return true}
      if(action==='switch'){switchPlayer();return true}
      if(action==='back'){state.paused=!state.paused;return true}
    }
    return false;
  },
  key(e){
    const k=e.key;
    const map={Enter:'confirm',' ':'confirm',ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',Tab:'switch',Escape:'back',a:'left',d:'right',z:'tackle',c:'pass',x:'shoot'};
    const action=map[k]; if(action){if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' ','Tab'].includes(k))e.preventDefault();return this.dispatch(action)}
    return false;
  },
  pointer(x,y){
    if(state.screen==='title'){return this.dispatch('confirm')}

    if(state.screen==='system'){
      if(state.runtimeRoom==='room_home'){const hit=HomeUI.hit(x,y);if(hit>=0){HomeUI.hover=hit;HomeUI.selected=hit;return HomeUI.confirm()}if(hit===-1){HomeUI.hover=-1;HomeUI.selected=-1;return HomeUI.confirm()}if(y>500)return this.dispatch('back');return true}
      if(y>300)return this.dispatch('confirm');
      return true;
    }
    if(state.screen==='select'){
      if(y>420){
        if(x<260)return this.dispatch('back');
        if(x>690)return this.dispatch('confirm');
        if(x>330&&x<630){state.selectSide=1-state.selectSide;return true}
      }
      if(y>120&&y<360){
        if(x<480) return this.dispatch('left');
        return this.dispatch('right');
      }
      return true
    }
    return false;
  }
};
// [REIMPLEMENTED/B] Browser-side equivalent of the recovered room_home controller.
// Button identities and actions come from the named GML scripts; artwork is resolved
// through GM_ANIMATION_DATA rather than recreated with HTML/CSS controls.
const UI_SCALE=2;
function uiAsset(sprite,frame=0){const d=window.GM_ANIMATION_DATA?.sprites?.[sprite];const f=d?.frames?.[frame];if(!f?.path)return null;return img(f.path.startsWith('assets/')?f.path.slice(7):f.path)}
function uiMeta(sprite){return window.GM_ANIMATION_DATA?.sprites?.[sprite]||{w:0,h:0,ox:0,oy:0}}
function drawUISprite(sprite,x,y,scale=UI_SCALE,frame=0,alpha=1){const im=uiAsset(sprite,frame);const m=uiMeta(sprite);if(!im?.complete)return false;X.save();X.globalAlpha=alpha;X.drawImage(im,Math.round(x*scale),Math.round(y*scale),Math.round(m.w*scale),Math.round(m.h*scale));X.restore();return true}
function drawUIPanel(x,y,w,h,sprite='spr_panel',frame=0){
  const im=uiAsset(sprite,frame),m=uiMeta(sprite); if(!im?.complete)return;
  const S=UI_SCALE, sw=m.w*S, sh=m.h*S;
  X.save();
  // GameMaker panel resources are stretchable/tileable UI primitives. Preserve their
  // pixel art while using the recovered source image for all four borders/corners.
  const dw=w*S,dh=h*S;
  if(m.w<=64&&m.h<=64){
    for(let yy=0;yy<dh;yy+=sh)for(let xx=0;xx<dw;xx+=sw){X.drawImage(im,0,0,im.naturalWidth,im.naturalHeight,Math.round(x*S+xx),Math.round(y*S+yy),Math.min(sw,dw-xx),Math.min(sh,dh-yy));}
  }else X.drawImage(im,x*S,y*S,dw,dh);
  X.restore();
}
function drawUIButton(sprite,x,y,w=98,h=22,label='',active=false,pressed=false,icon=null){
  const frame=pressed?2:active?1:0;drawUISprite(sprite,x,y,UI_SCALE,frame,active?1:.92);
  if(icon)drawUISprite(icon,x+7,y+3,UI_SCALE,0,active?1:.9);
  if(label)txt(bodyFont,label,(x+w/2)*UI_SCALE,(y+5)*UI_SCALE,.72,'center',active?1:.9);
}
// [REIMPLEMENTED/B] Home UI is now laid out in the recovered room_home 480x270
// coordinate system. The resources are the actual GameMaker panel/button/card/icon
// sprites; the layout is isolated because native s_home_init builds the controls at
// runtime and its stripped YYC does not expose symbolic GUI coordinates.
const HomeUI={
  get model(){return window.GM_UI_RUNTIME?.rooms?.room_home||{buttons:[]}},
  init(){const b=this.model.buttons||[];state.homeUI.buttons=b.map((x,i)=>({...x,index:i}));state.homeUI.selected=-1;state.homeUI.hover=-1;state.homeUI.pressed=-1;state.homeUI.lastAction=null},
  move(d){const n=state.homeUI.buttons.length+1;if(!n)return;state.homeUI.selected=((state.homeUI.selected+1+d+n)%n)-1;state.homeUI.hover=state.homeUI.selected},
  confirm(){if(state.homeUI.selected===-1){const c=this.model.continue;if(!c)return false;state.homeUI.lastAction=c.script;state.homeUI.pressed=-1;startMusic();Runtime.enter(c.target,'home-continue:'+c.script);return true}const b=state.homeUI.buttons[state.homeUI.selected];if(!b)return false;state.homeUI.pressed=b.index;state.homeUI.lastAction=b.script;setTimeout(()=>{if(state.homeUI.pressed===b.index)state.homeUI.pressed=-1},90);startMusic();Runtime.enter(b.target,'home-button:'+b.script);return true},
  // Logical room coordinates; pointer input is converted back to this space.
  rect(i){const col=i%2,row=Math.floor(i/2);return {x:170+col*112,y:63+row*27,w:98,h:22}},
  continueRect(){return {x:10,y:174,w:98,h:22}},
  hit(x,y){x/=UI_SCALE;y/=UI_SCALE;const c=this.continueRect();if(x>=c.x&&x<=c.x+c.w&&y>=c.y&&y<=c.y+c.h)return -1;for(let i=0;i<state.homeUI.buttons.length;i++){const r=this.rect(i);if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h)return i}return -2},
  drawButton(i){const b=state.homeUI.buttons[i],r=this.rect(i),active=i===state.homeUI.selected,pressed=i===state.homeUI.pressed;drawUIButton('spr_button',r.x,r.y,r.w,r.h,b.label,active,pressed,b.icon)},
  draw(){
    const S=UI_SCALE;
    X.fillStyle='#0871be';X.fillRect(0,0,W,H);
    // recovered room_header is 475x44 and the room is 480x270; it is rendered at
    // native room scale and clipped to the room viewport, not resized arbitrarily.
    drawUISprite('spr_header',0,0,S,0,1);
    const t=teams[state.home]||{name:'TEAM',short:'TEAM',strength:0};
    // Actual recovered team card resource: 69x87 at 2x.
    drawUISprite('spr_card_team',10,55,S,0,1);
    txt(titleFont,t.short||'TEAM',44*S,61*S,.72,'center',1);
    txt(bodyFont,t.name||'TEAM',44*S,107*S,.62,'center',1);
    txt(bodyFont,`RATING ${t.strength||0}`,44*S,119*S,.5,'center',.9);
    // Runtime-created home controls sit on a recovered panel primitive rather than
    // floating over the blue room background.
    drawUIPanel(160,48,310,184,'spr_panel',0);
    // Use the actual small navigation button for the primary continue action.
    const c=this.continueRect(),active=state.homeUI.selected===-1;
    drawUIButton('spr_button',c.x,c.y,98,22,'PLAY NEXT',active,state.homeUI.pressed===-1&&false,'spr_icon_football');
    for(let i=0;i<state.homeUI.buttons.length;i++)this.drawButton(i);
    // Recovered directional/button affordances for controller/keyboard navigation.
    drawUISprite('spr_arrow_left',157,235,S);drawUISprite('spr_arrow_right',458,235,S);
    txt(bodyFont,'SELECT',240*S,242*S,.46,'center',.8);
  }
};

// [APK-DIRECT] Runtime graph generated from the actual GameMaker ROOM/OBJT/SCPT chunks and YYC symbols.
const GM=window.GM_RUNTIME_DATA||{rooms:[],objects:[],scripts:[],native_object_events:[]};
const GMRoom=new Map((GM.rooms||[]).map(r=>[r.name,r]));
const GMObject=new Map((GM.objects||[]).map(o=>[o.name,o]));
const GMScript=new Set((GM.scripts||[]).map(s=>s.name));
const GMNative=new Set(GM.native_object_events||[]);
const Runtime={
  room(name){return GMRoom.get(name)||null},
  next(name){const m=window.GM_UI_RUNTIME?.rooms?.[name];if(m?.back)return m.back;return ({room_newcareer:'room_favouriteteam',room_favouriteteam:'room_lineup',room_lineup:'room_weekend',room_weekend:'room_prematch',room_roster:'room_profile',room_profile:'room_office',room_office:'room_formation',room_formation:'room_tactics',room_tactics:'room_prematch',room_results:'room_home',room_options:'room_home'})[name]||'room_prematch'},
  enter(name,reason){
    const r=this.room(name); if(!r)return false;
    state.runtimeRoom=name; state.transition=null;
    // [REIMPLEMENTED] This is the browser equivalent of the GameMaker room transition.
    // The title's native s_title_exit explicitly calls s_goto_room; its static GOT target
    // is stripped/unresolved, so room_home is retained as the evidence-backed fallback.
    if(name==='room_field'){state.screen='match';initMatch();const h=document.getElementById('hint');if(h)h.textContent='ARROWS / WASD MOVE • X SHOOT • C PASS • TAB SWITCH • ESC PAUSE • DRAG TO KICK'}
    else if(name==='room_prematch'){state.screen='select';state.selectSide=0}
    else if(name==='room_title'){
      state.screen='title';
      const h=document.getElementById('hint');if(h)h.textContent='Tap/click to start • keyboard, pointer and touch controls supported';
      state.title.phase='intro';state.title.stage=0;state.title.t=0;state.title.stageTime=0;state.title.outDelay=0;state.title.fade=0;state.title.ready=false;state.title.playerX=-230;state.title.ballX=-40;state.title.ballY=180;state.title.opacity=0;state.title.pendingConfirm=false;state.title.continueRequested=false;state.title.playerAnimation?.reset();state.title.ballAnimation?.reset();
    }
    else {state.screen='system';if(name==='room_home')HomeUI.init();else if(window.GM_UI_RUNTIME?.rooms?.[name])state.homeUI.lastAction=null;}
    return true;
  },
  titleContinue(){
    // [B] Native obj/title step path: s_button_snd_click -> s_title_continue ->
    // s_title_set_opacity.  s_title_continue updates the room-manager state; the
    // actual room call is performed by s_title_exit/s_goto_room.
    state.title.continueRequested=true;
    state.title.phase='exit';
    state.title.stage=2;
    state.title.stageTime=0;
    state.title.outDelay=0;
    state.title.fade=0;
    state.title.ready=false;
    state.transition={from:'room_title',event:'input',sound:'s_button_snd_click',script:'gml_Script_s_title_continue',opacity:'gml_Script_s_title_set_opacity',next:'gml_Script_s_title_exit',target:GM.title?.target_room||'unresolved-static-GOT-slot'};
  },
  tick(dt){
    if(state.runtimeRoom!=='room_title')return;
    const t=state.title; t.t+=dt; t.stageTime+=dt; t.playerAnimation.update(dt); t.ballAnimation.update(dt);
    // [B] Native title state exposes _title_stage, _title_stage_time,
    // _title_opacity and _title_out_delay. Exact stage thresholds are not encoded
    // as readable GML, so timing below remains [APPROX] while using the recovered
    // state model and the native title-step call graph.
    if(t.stage===0){
      t.opacity=Math.min(1,t.stageTime/0.55);
      t.playerX=-230+(180+230)*Math.min(1,Math.max(0,(t.stageTime-.05)/1.05));
      t.ballX=-40+75*Math.min(1,Math.max(0,(t.stageTime-.18)/.85));
      t.ballY=180;
      if(t.stageTime>1.25){t.stage=1;t.phase='idle';t.stageTime=0;t.ready=true;if(t.pendingConfirm){t.pendingConfirm=false;startMusic();this.titleContinue()}}
    }else if(t.stage===1){
      t.opacity=1;
      t.playerX=180+Math.sin(t.t*2.1)*2.2;
      t.ballX=35+Math.sin(t.t*2.7)*6;
      t.ballY=180+Math.sin(t.t*2.7)*3;
    }else if(t.stage===2){
      t.outDelay+=dt;
      t.fade=Math.min(1,t.outDelay/.42);
      t.opacity=1-t.fade;
      t.playerX=180+Math.sin(t.t*2.1)*2.2;
      t.ballX=35+Math.sin(t.t*2.7)*6; t.ballY=180+Math.sin(t.t*2.7)*3;
      if(t.fade>=1)this.enter('room_home','title-exit-fallback');
    }
  }
};
function clamp(v,a,b){return Math.max(a,Math.min(b,v))} function dist(a,b,c,d){return Math.hypot(a-c,b-d)}
function teamColor(team,away=false){return away?team.away1:team.home1} function hexRGB(h){h=(h||'#fff').replace('#','');return h.length===6?'#'+h:'#fff'}
function txt(font,s,x,y,scale=1,align='left',alpha=1){if(!font)return;X.save();X.globalAlpha=alpha;X.imageSmoothingEnabled=false;let xx=x;if(align==='center')xx=x-textWidth(font,s,scale)/2;if(align==='right')xx=x-textWidth(font,s,scale);for(const ch of String(s)){if(ch==='\n'){y+=font.meta.h*scale;xx=x;continue}const g=font.meta.glyphs[String(ch.codePointAt(0))]||font.meta.glyphs['63'];if(!g){xx+=8*scale;continue}X.drawImage(font.im,g.x,g.y,g.w,g.h,Math.round(xx+g.offset*scale),Math.round(y),g.w*scale,g.h*scale);xx+=g.shift*scale}X.restore()}
function textWidth(font,s,scale=1){let w=0;for(const ch of String(s)){const g=font.meta.glyphs[String(ch.codePointAt(0))]||font.meta.glyphs['63'];w+=(g?g.shift:8)*scale}return w}
function buttonBox(x,y,w,h,label,active=false){X.save();X.globalAlpha=active?1:.86;const fr=img(`frames_gm/spr_button/${active?'01':'00'}.png`);if(fr.complete)X.drawImage(fr,0,0,fr.naturalWidth||98,fr.naturalHeight||22,x,y,w,h);else X.drawImage(button,0,0,button.naturalWidth||98,button.naturalHeight||22,x,y,w,h);txt(bodyFont,label,x+w/2,y+6,h/22*.72,'center');X.restore()}

// [REIMPLEMENTED] Original symbols expose s_player_positions_init / s_get_pitch_position_from_formation.
// Exact formation constants are not serialized as readable GML in this YYC build, so these are explicit approximations.
const FORMATIONS={balanced:[[-.98,0],[-.72,-.52],[-.72,.52],[-.36,-.20],[-.36,.20],[0,-.45],[0,.45]],attacking:[[-.98,0],[-.70,-.52],[-.70,.52],[-.30,-.28],[-.30,.28],[.12,-.42],[.12,.42]],defensive:[[-.98,0],[-.76,-.48],[-.76,.48],[-.42,-.18],[-.42,.18],[-.08,-.36],[-.08,.36]]};
function makePlayer(team,idx,formationName){const t=teams[team===0?state.home:state.away], f=FORMATIONS[formationName||'balanced'][idx];const home=team===0;const x=home?PITCH.left+70+(f[0]+1)*690:PITCH.right-70-(f[0]+1)*690;const y=PITCH.centerY+f[1]*250;const base=clamp((t.strength||70)+(idx===0?4:((idx*7)%9)-4),35,99);return {team,idx,role:idx===0?'GK':idx<3?'DF':idx<5?'MF':'FW',x,y,vx:0,vy:0,ax:0,ay:0,facing:home?0:Math.PI,anim:0,action:'idle',kick:0,targetX:x,targetY:y,anchorX:x,anchorY:y,speed:clamp(72+base*.72,88,145),dribbling:clamp(45+base*.48,50,95),tackling:clamp(42+base*.52,48,96),technique:clamp(44+base*.50,50,97),stamina:100,ownerTime:0,yellow:0,red:false,offside:false,passTarget:-1,hasBall:false,actionUntil:0,animation:new GMAnimation('spr_player_idle_stripes',4)}}
function initMatch(){
 state.matchRunning=true; state.last=performance.now();
 state.score=[0,0];state.clock=0;state.half=1;state.paused=false;state.ended=false;state.flash=0;state.particles=[];state.kickCooldown=0;state.restart=null;state.offside=null;state.events=[];state.matchSpeed=1;state.seed=1;
 const form='balanced'; state.players=[];for(let side=0;side<2;side++)for(let i=0;i<7;i++)state.players.push(makePlayer(side,i,form));
 state.ball={x:PITCH.centerX,y:PITCH.centerY,z:0,vx:0,vy:0,vz:0,spin:0,owner:-1,lastTouch:-1,lastTouchTeam:-1,airborne:false,protected:0,animation:new GMAnimation('spr_ball1',6)};
 state.controlled=nearestPlayer(0);
 // Kickoff must leave the human side with an immediately controllable player.
 // This mirrors the game's playable kickoff state rather than requiring the user
 // to discover an invisible possession pickup before the first action.
 const kickoffPlayer=state.players[state.controlled];
 if(kickoffPlayer){kickoffPlayer.x=PITCH.centerX-18;kickoffPlayer.y=PITCH.centerY;kickoffPlayer.anchorX=kickoffPlayer.x;kickoffPlayer.anchorY=kickoffPlayer.y;state.ball.x=kickoffPlayer.x+15;state.ball.y=kickoffPlayer.y;state.ball.owner=state.controlled;kickoffPlayer.hasBall=true;state.ball.lastTouch=state.controlled;state.ball.lastTouchTeam=0;}
 state.cam=cameraTarget(); logEvent('kickoff');
}
function resetKickoff(){
 state.ball.x=PITCH.centerX;state.ball.y=PITCH.centerY;state.ball.z=0;state.ball.vx=state.ball.vy=state.ball.vz=0;state.ball.owner=-1;state.ball.protected=.5;state.restart=null;state.offside=null;
 const form=FORMATIONS.balanced;state.players.forEach((p,i)=>{const f=form[p.idx],home=p.team===0;p.anchorX=home?PITCH.left+70+(f[0]+1)*690:PITCH.right-70-(f[0]+1)*690;p.anchorY=PITCH.centerY+f[1]*250;p.targetX=p.anchorX;p.targetY=p.anchorY;p.x=p.anchorX;p.y=p.anchorY;p.vx=p.vy=0;p.action='idle';p.actionUntil=0;p.hasBall=false;p.offside=false});
 state.controlled=nearestPlayer(0);
 state.cam=cameraTarget();
}
function nearestPlayer(team,includeGK=true){let best=-1,bd=1e9;for(let i=0;i<state.players.length;i++){const p=state.players[i];if(p.team!==team||(!includeGK&&p.role==='GK'))continue;const d=dist(p.x,p.y,state.ball?.x??PITCH.centerX,state.ball?.y??PITCH.centerY);if(d<bd){bd=d;best=i}}return best}
function nearestTeammate(p,forwardOnly=false){let best=-1,score=1e9;for(let i=0;i<state.players.length;i++){const q=state.players[i];if(q.team!==p.team||q===p||q.red)continue;const dx=(q.x-p.x)*(p.team===0?1:-1);if(forwardOnly&&dx<20)continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<score){score=d;best=i}}return best}
function switchPlayer(){const p=state.players[state.controlled];const candidate=nearestPlayer(0,false);if(candidate>=0&&candidate!==state.controlled)state.controlled=candidate;else if(p){let candidates=state.players.map((q,i)=>({q,i,d:dist(q.x,q.y,state.ball.x,state.ball.y)})).filter(v=>v.q.team===0&&v.i!==state.controlled&&!v.q.red).sort((a,b)=>a.d-b.d);if(candidates[0])state.controlled=candidates[0].i}}
function inputVector(){let ax=0,ay=0;if(keysDown.has('ArrowLeft')||keysDown.has('a'))ax--;if(keysDown.has('ArrowRight')||keysDown.has('d'))ax++;if(keysDown.has('ArrowUp')||keysDown.has('w'))ay--;if(keysDown.has('ArrowDown')||keysDown.has('s'))ay++;const l=Math.hypot(ax,ay)||1;return {x:ax/l,y:ay/l,active:!!(ax||ay)}}
function setVelocity(p,tx,ty,dt){const dx=tx-p.x,dy=ty-p.y,l=Math.hypot(dx,dy)||1;const desired=Math.min(p.speed,l/dt);const dv=Math.max(250*dt,1);p.vx+=clamp(dx/l*desired-p.vx,-dv,dv);p.vy+=clamp(dy/l*desired-p.vy,-dv,dv);if(l>3)p.facing=Math.atan2(p.vy,p.vx)}
// [REIMPLEMENTED] s_speed / s_speed_change / s_speed_no_ball are explicit APK symbols. Numeric acceleration is not recoverable as source.
function updateHuman(p,dt){const v=inputVector();const sprint=keysDown.has('Shift')?1.10:1;const max=p.speed*sprint;p.actionUntil=Math.max(0,(p.actionUntil||0)-dt);if((p.actionUntil||0)<=0){if(v.active){p.vx+=v.x*520*dt;p.vy+=v.y*520*dt;const l=Math.hypot(p.vx,p.vy);if(l>max){p.vx=p.vx/l*max;p.vy=p.vy/l*max}p.facing=Math.atan2(v.y,v.x);p.action='run';p.anim+=dt*(10+max/30)}else{const f=Math.pow(.0008,dt);p.vx*=f;p.vy*=f;p.action='idle';p.anim+=dt*4}}else{p.anim+=dt*8}p.animation.set(playerSpriteName(p),p.action==='run'?10:(p.action==='kick'?8:4)).update(dt)}
function formationTarget(p){const ball=state.ball;let shiftX=clamp((ball.x-PITCH.centerX)*.20,-150,150),shiftY=clamp((ball.y-PITCH.centerY)*.12,-35,35);let tx=p.anchorX+shiftX*(p.team===0?1:-1),ty=p.anchorY+shiftY;if(p.role==='GK'){tx=p.team===0?PITCH.left+75:PITCH.right-75;ty=clamp(ball.y,PITCH.goalTop+25,PITCH.goalBottom-25)}return {x:tx,y:ty}}
function updateAI(p,i,dt){const b=state.ball,owner=b.owner;const opponentOwner=owner>=0&&state.players[owner].team!==p.team;let chase=false;
 if(owner<0){chase=i===nearestPlayer(p.team)||dist(p.x,p.y,b.x,b.y)<70}else if(opponentOwner){chase=i===nearestPlayer(p.team,false)||dist(p.x,p.y,b.x,b.y)<48}else chase=false;
 if(p.role==='GK')chase=opponentOwner&&dist(p.x,p.y,b.x,b.y)<170;
 let target=formationTarget(p); if(chase){target={x:b.x,y:b.y};}
 // [REIMPLEMENTED] s_move_to_destination / s_look_for_run / closest-player helpers support this formation/ball-relative AI structure.
 if(owner===i){p.ownerTime+=dt;const goalX=p.team===0?PITCH.right:PITCH.left;const forward=(goalX-p.x)*(p.team===0?1:-1);if(forward>420&&Math.random()<dt*(.35+p.technique/250)){const mate=nearestTeammate(p,true);if(mate>=0&&Math.random()<.55){aiPass(i,mate);return}}if(forward>900&&Math.random()<dt*(.5+p.technique/220)){aiShoot(i,goalX,PITCH.centerY+(Math.random()-.5)*90);return}target={x:p.x+(p.team===0?90:-90),y:p.y+(Math.random()-.5)*35}}
 setVelocity(p,target.x,target.y,dt);p.actionUntil=Math.max(0,(p.actionUntil||0)-dt);if((p.actionUntil||0)<=0)p.action=Math.hypot(p.vx,p.vy)>8?'run':'idle';p.anim+=dt*7;p.animation.set(playerSpriteName(p),p.action==='run'?10:(p.action==='kick'?8:4)).update(dt);
}
function takePossession(i){const b=state.ball,p=state.players[i];if(b.protected>0||p.red)return false;if(b.owner<0&&dist(p.x,p.y,b.x,b.y)<26+(p.dribbling*.18)){b.owner=i;b.lastTouch=i;b.lastTouchTeam=p.team;p.hasBall=true;p.ownerTime=0;return true}if(b.owner>=0&&b.owner!==i){const o=state.players[b.owner];if(o.team!==p.team&&dist(p.x,p.y,o.x,o.y)<30){const chance=.62+p.tackling/220;if(Math.random()<Math.min(.96,chance)){o.hasBall=false;b.owner=i;b.lastTouch=i;b.lastTouchTeam=p.team;p.hasBall=true;p.ownerTime=0;logEvent('tackle');return true}}}return false}
// [REIMPLEMENTED] s_dribble_ball. The exact GML numeric constants are not readable in game.droid; this preserves the recovered possession/dribble state model.
function updateDribble(p,dt){const b=state.ball;const lead=15+clamp(Math.hypot(p.vx,p.vy)*.08,0,8);b.x=p.x+Math.cos(p.facing)*lead;b.y=p.y+Math.sin(p.facing)*lead;b.z=2+Math.abs(Math.sin(performance.now()/90))*1.5;b.vx=p.vx*.08;b.vy=p.vy*.08;b.vz=0;b.airborne=false;b.lastTouch=p.idx;b.lastTouchTeam=p.team;p.hasBall=true}
function kickVelocity(p,tx,ty,power){const dx=tx-p.x,dy=ty-p.y,l=Math.hypot(dx,dy)||1;const tech=p.technique/100;const v=power*(38+tech*12);return {vx:dx/l*v,vy:dy/l*v,vz:power*(7+tech*5)}}
// [REIMPLEMENTED] s_get_kick_velocity + s_get_kick_tradjectory + s_throttle_kick_power.
function launchBall(i,tx,ty,power,kind='shot'){const p=state.players[i],b=state.ball;if(b.owner!==i)return false;const k=kickVelocity(p,tx,ty,power);b.owner=-1;p.hasBall=false;p.action=kind==='pass'?'pass':'kick';p.actionUntil=kind==='pass'?.18:.62;p.anim=0;if(p.animation)p.animation.set(playerSpriteName(p),kind==='pass'?1:8);b.vx=k.vx;b.vy=k.vy;b.vz=k.vz;b.z=3;b.airborne=true;b.lastTouch=i;b.lastTouchTeam=p.team;b.protected=.12;state.kickCooldown=.12;state.ball.protected=kind==='pass'?.22:.45;state.offside=kind==='pass'?computeOffsideAtPass(i):null;return true}
function computeOffsideAtPass(i){const p=state.players[i],attackers=state.players.filter(q=>q.team===p.team&&q!==p&&q.role!=='GK');const defenders=state.players.filter(q=>q.team!==p.team&&!q.red).sort((a,b)=>p.team===0?b.x-a.x:a.x-b.x);if(defenders.length<2)return null;const line=p.team===0?defenders[1].x:defenders[1].x;const flag=attackers.filter(q=>{const ahead=p.team===0?q.x>line:q.x<line;const inHalf=p.team===0?q.x>PITCH.centerX:q.x<PITCH.centerX;return ahead&&inHalf});return flag.length?{team:p.team,ids:new Set(flag.map(q=>q.idx)),line}:null}
function aiPass(i,targetIdx){const p=state.players[i],q=state.players[targetIdx];if(!q)return;launchBall(i,q.x,q.y,5.8,'pass')}
function aiShoot(i,tx,ty){launchBall(i,tx,ty,7.4,'shot')}
function humanKick(tx,ty,power=7){const p=state.players[state.controlled];if(!p||p.red||state.kickCooldown>0)return false;if(state.ball.owner!==state.controlled&&dist(p.x,p.y,state.ball.x,state.ball.y)>42)return false;if(state.ball.owner!==state.controlled)takePossession(state.controlled);if(state.ball.owner!==state.controlled)return false;return launchBall(state.controlled,tx+state.cam,ty,power,'shot')}
function humanPass(){
  let p=state.players[state.controlled]; if(!p)return;
  // If the selected player is not the carrier, first try to collect a loose ball.
  if(state.ball.owner!==state.controlled)takePossession(state.controlled);
  // If a teammate already has possession, make that carrier the active player so
  // the pass action is never silently discarded.
  if(state.ball.owner!==state.controlled){
    const carrier=state.ball.owner>=0&&state.players[state.ball.owner]?.team===0?state.ball.owner:-1;
    if(carrier>=0){state.controlled=carrier;p=state.players[carrier];}
  }
  if(state.ball.owner!==state.controlled)return false;
  let q=nearestTeammate(p,true);if(q<0)q=nearestTeammate(p,false);
  return q>=0?launchBall(state.controlled,state.players[q].x,state.players[q].y,5.4,'pass'):false;
}
function humanTackle(){
 const p=state.players[state.controlled];if(!p||p.red)return false;
 let best=-1,bd=46;
 for(let i=0;i<state.players.length;i++){const q=state.players[i];if(q.team===p.team||q.red)continue;const d=dist(p.x,p.y,q.x,q.y);if(d<bd){bd=d;best=i}}
 if(best<0)return false;
 const q=state.players[best],b=state.ball;
 if(b.owner===best&&bd<46){
   q.hasBall=false;b.owner=-1;b.x=q.x;b.y=q.y;b.z=1;b.vx=Math.cos(p.facing)*2.2;b.vy=Math.sin(p.facing)*2.2;b.vz=.4;b.protected=0;
   b.owner=state.controlled;p.hasBall=true;p.ownerTime=0;b.lastTouch=state.controlled;b.lastTouchTeam=p.team;logEvent('tackle');return true;
 }
 return takePossession(state.controlled);
}
function goalPlaneX(side,y){
  const t=clamp((y-PITCH.goalTop)/(PITCH.goalBottom-PITCH.goalTop),0,1);
  return side===0?(196+(148-196)*t):(1547+(1595-1547)*t);
}
function goalMouthContains(x,y){
  if(y<PITCH.goalTop||y>PITCH.goalBottom)return false;
  return (x<=goalPlaneX(0,y)) || (x>=goalPlaneX(1,y));
}
function ballBoundaries(dt){
 const b=state.ball,prevX=b.x-b.vx*dt;
 // [APK-DIRECT/REIMPLEMENTED] Goal crossing follows the perspective goal-mouth
 // planes recovered from the field raster, not a rectangular trigger.
 if(b.x<=goalPlaneX(0,b.y)&&prevX>goalPlaneX(0,b.y)&&b.y>=PITCH.goalTop&&b.y<=PITCH.goalBottom){goal(1);return}
 if(b.x>=goalPlaneX(1,b.y)&&prevX<goalPlaneX(1,b.y)&&b.y>=PITCH.goalTop&&b.y<=PITCH.goalBottom){goal(0);return}
 if(b.y<PITCH.top){b.y=PITCH.top;b.vy=Math.abs(b.vy)*.65;restart('throw',b.x,PITCH.top,1-(b.lastTouchTeam<0?0:b.lastTouchTeam));return}
 if(b.y>PITCH.bottom){b.y=PITCH.bottom;b.vy=-Math.abs(b.vy)*.65;restart('throw',b.x,PITCH.bottom,1-(b.lastTouchTeam<0?0:b.lastTouchTeam));return}
 if(b.x<PITCH.left){b.x=PITCH.left;b.vx=Math.abs(b.vx)*.65;restart(b.lastTouchTeam===0?'corner':'throw',b.x,b.y,1-(b.lastTouchTeam<0?0:b.lastTouchTeam));return}
 if(b.x>PITCH.right){b.x=PITCH.right;b.vx=-Math.abs(b.vx)*.65;restart(b.lastTouchTeam===1?'corner':'throw',b.x,b.y,1-(b.lastTouchTeam<0?0:b.lastTouchTeam));return}
}
// [REIMPLEMENTED] s_check_ball_boundaries / s_check_goal_bounderies / s_ball_is_crossing. Restart type is structurally recovered; exact restart animation is approximate.
function restart(type,x,y,team){if(state.ended)return;state.restart={type,x:clamp(x,PITCH.left,PITCH.right),y:clamp(y,PITCH.top,PITCH.bottom),team:team<0?0:team,delay:.55};state.ball.owner=-1;state.ball.vx=state.ball.vy=state.ball.vz=0;state.ball.z=0;state.flashText=type==='corner'?'CORNER':'THROW-IN';state.flash=.8;logEvent(type)}
function resolveRestart(dt=.016){const r=state.restart;if(!r)return;r.delay-=dt;if(r.delay>0)return;
  let pi=nearestPlayer(r.team,false);
  if(r.team===0){pi=state.controlled>=0&&state.players[state.controlled]?.team===0?state.controlled:pi;state.controlled=pi;}
  const p=pi>=0?state.players[pi]:null;if(!p){state.restart=null;return}
  p.x=clamp(r.x+(r.team===0?-12:12),PITCH.left,PITCH.right);p.y=clamp(r.y,PITCH.top,PITCH.bottom);p.vx=p.vy=0;
  state.ball.x=p.x+(r.team===0?10:-10);state.ball.y=p.y;state.ball.z=0;state.ball.vx=state.ball.vy=state.ball.vz=0;state.ball.owner=pi;state.ball.protected=.35;p.hasBall=true;p.ownerTime=0;
  state.restart=null;}
function keeperAI(dt){for(const p of state.players){if(p.role!=='GK'||p.red)continue;const b=state.ball;if(b.owner>=0&&state.players[b.owner].team===p.team){setVelocity(p,p.team===0?PITCH.left+75:PITCH.right-75,p.anchorY,dt);continue}const goalX=p.team===0?PITCH.left+75:PITCH.right-75;const threat=Math.abs(b.x-goalX)<300;let tx=goalX,ty=clamp(b.y,PITCH.goalTop+18,PITCH.goalBottom-18);if(threat&&b.z<70){tx=goalX+(b.x-goalX)*.12;ty=clamp(b.y,PITCH.goalTop+12,PITCH.goalBottom-12)}setVelocity(p,tx,ty,dt);if(b.owner<0&&dist(p.x,p.y,b.x,b.y)<28&&b.z<12){takePossession(state.players.indexOf(p))}}
}
function applyOffside(){const o=state.offside;if(!o)return;for(const p of state.players){if(p.team===o.team&&o.ids.has(p.idx))p.offside=true}if(state.ball.owner>=0){const p=state.players[state.ball.owner];if(p.offside&&p.team===o.team){restart('offside',p.x,p.y,1-p.team);state.offside=null}}}
function goal(team){if(state.restart)return;state.score[team]++;state.flash=2;state.flashText='GOAL!';state.ball.owner=-1;state.ball.vx=state.ball.vy=state.ball.vz=0;for(const p of state.players)p.hasBall=false;for(let i=0;i<80;i++)state.particles.push({x:PITCH.centerX+(Math.random()-.5)*80,y:PITCH.centerY+(Math.random()-.5)*60,vx:(Math.random()-.5)*5,vy:(Math.random()-.5)*5,life:1.2});logEvent('goal');setTimeout(()=>{if(state.screen==='match'&&!state.ended)resetKickoff()},850)}
function logEvent(e){state.events.push({t:state.clock,e});if(state.events.length>40)state.events.shift()}
function update(dt){Runtime.tick(dt);if(state.screen!=='match'||state.ended)return;if(state.restart){resolveRestart(dt);return}if(state.paused)return;state.kickCooldown=Math.max(0,state.kickCooldown-dt);state.flash=Math.max(0,state.flash-dt);state.clock+=dt*.5*state.matchSpeed;
 if(state.clock>=45&&state.half===1){state.half=2;state.paused=true;state.flashText='HALF TIME';state.flash=99;logEvent('halftime');setTimeout(()=>{if(!state.ended){state.paused=false;state.flash=0;resetKickoff()}},1800);return}
 if(state.clock>=90){state.clock=90;state.ended=true;state.matchRunning=false;state.flashText='FULL TIME';state.flash=99;state.paused=true;logEvent('fulltime');return}
 const b=state.ball;
 if(b.animation)b.animation.set(b.z>8?'spr_ball2':'spr_ball1',6).update(dt);
 state.players.forEach((p,i)=>{if(p.red)return;if(i===state.controlled){updateHuman(p,dt)}else updateAI(p,i,dt);p.x=clamp(p.x+p.vx*dt,PITCH.left,PITCH.right);p.y=clamp(p.y+p.vy*dt,PITCH.top,PITCH.bottom);p.stamina=clamp(p.stamina-dt*(p.action==='run'?.9:.12),5,100);p.hasBall=false;});
 // possession/interaction pass after movement, then dribble state.
 if(b.owner>=0){const o=state.players[b.owner];if(o.red)b.owner=-1;else updateDribble(o,dt)}
 if(b.owner<0){
   // [APK-DIRECT/REIMPLEMENTED] s_update_ball_movement + s_update_ball_height:
   // once the ball leaves a player, advance its world position and height every
   // simulation step. The previous browser pass restored kick velocity but omitted
   // this integration step, leaving a shot visually frozen at its launch point.
   b.x+=b.vx*dt;
   b.y+=b.vy*dt;
   b.z+=b.vz*dt;
   b.vz-=24*dt;
   const drag=Math.exp(-0.85*dt);
   b.vx*=drag;b.vy*=drag;
   if(b.z<=0){b.z=0;b.vz=Math.abs(b.vz)*.42;if(Math.abs(b.vz)<.45)b.vz=0;b.airborne=false}
   b.protected=Math.max(0,b.protected-dt);
   for(const p of state.players){if(p.red)continue;if(dist(p.x,p.y,b.x,b.y)<22){if(takePossession(state.players.indexOf(p)))break}}
 }
 if(b.owner<0)ballBoundaries(dt);else applyOffside();
 keeperAI(dt);
 state.cam+=(cameraTarget()-state.cam)*Math.min(1,dt*8);
 state.particles=state.particles.filter(q=>(q.life-=dt)>0);state.particles.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.vy+=.08});
}

function drawField(){
  X.save();X.beginPath();X.rect(0,0,W,MATCH_ROOM.height);X.clip();
  X.drawImage(field,-Math.floor(state.cam),0);
  // [APK-DIRECT] The recovered goal sprites use an origin of (0,96). The field
  // raster places the goal-line/mouth around x=95/1648 and y=378, so the sprite
  // must be drawn from that origin rather than from the top-left of the room.
  drawGoal(0,'back'); drawGoal(1,'back');
  X.restore();
}
function drawGoal(side,layer='fore'){
  // [APK-DIRECT] obj_goal_back/fore Draw_0 use the recovered sprites at 0.66x,
  // with origin (0,96). The right goal is mirrored around its origin; do not
  // translate by sprite width as the previous renderer did.
  const im=layer==='back'?visual.goalBack:visual.goalFore;if(!drawableAsset(im))return;
  const scale=.66, worldX=side===0?PITCH.left:PITCH.right, worldY=PITCH.goalBottom;
  X.save();X.translate(Math.round(worldX-state.cam),Math.round(worldY));
  X.scale(side===0?scale:-scale,scale);
  X.drawImage(im,0,-96,im.naturalWidth||91,im.naturalHeight||98);
  X.restore();
}
function playerSpriteName(p){
  const striped=p.team===0;if(p.role==='GK'){if(p.action==='dive')return 'spr_keeper_dive_u';if(p.action==='collect')return 'spr_keeper_collect2';if(p.action==='run')return 'spr_keeper_run2';return 'spr_keeper_idle2';}
  if(p.action==='kick')return striped?'spr_player_kick_stripes':'spr_player_kick_hoops';if(p.action==='pass')return striped?'spr_player_pass_stripes':'spr_player_pass_hoops';if(p.action==='run')return striped?'spr_player_run_stripes':'spr_player_run_hoops';if(p.action==='slide')return striped?'spr_player_slide_stripes':'spr_player_slide_hoops';return striped?'spr_player_idle_stripes':'spr_player_idle_hoops';
}
function playerSource(p,frame){
  const spriteName=playerSpriteName(p),m=window.GM_ANIMATION_DATA?.sprites?.[spriteName];
  if(m?.frames?.[frame]?.path)return m.frames[frame].path.startsWith('assets/')?m.frames[frame].path.replace('assets/frames_gm/','assets/character_textures_exact/'):m.frames[frame].path;
  const striped=p.team===0;if(p.action==='kick')return striped?keys.kickS(frame):keys.kickH(frame);if(p.action==='pass')return striped?keys.passS(frame):keys.passH(frame);if(p.action==='run')return striped?keys.runS(frame):keys.runH(frame);if(p.action==='slide')return striped?keys.slideS(frame):keys.slideH(frame);return striped?keys.idleS(frame):keys.idleH(frame);
}
function drawableAsset(v){
  // Both recovered HTML images and shader-generated canvases are legal drawImage
  // sources. Do not require the Image-only `complete` property for generated canvases.
  if(!v)return false;
  if(typeof HTMLCanvasElement!=='undefined' && v instanceof HTMLCanvasElement)return v.width>0&&v.height>0;
  if(typeof HTMLImageElement!=='undefined' && v instanceof HTMLImageElement)return v.complete&&v.naturalWidth>0;
  return !!(v.width&&v.height);
}
function drawPlayer(p,i){
  const spriteName=playerSpriteName(p),meta=(window.GM_ANIMATION_DATA?.sprites?.[spriteName]||window.SPRITE_META?.[spriteName])||{ox:16,oy:29,w:32,h:32};
  const frame=p.animation? p.animation.frame():Math.floor(p.anim)%Math.max(1,meta.frames||8),src=playerSource(p,frame),raw=img(src),team=teams[p.team===0?state.home:state.away],id=prepareKit(team,p.team===1,p.idx),im=recolorPlayerImage(raw,id);
  // [B] A cold browser cache must never make the active match appear empty.
  // The shader reconstruction returns a canvas, so it cannot be tested with `.complete`.
  const fallback=img('recovered_sprites/005_spr_player_idle_stripes.png');
  const recoloredFallback=recolorPlayerImage(fallback,id);
  // The raw recovered frame is a last-resort render target if a shader canvas has
  // not finished constructing. This is still APK artwork; it is never a generated
  // placeholder. The normal path is always the recolored shader result.
  const renderIm=drawableAsset(im)?im:(drawableAsset(recoloredFallback)?recoloredFallback:null);
  // GameMaker draws these sprites at their native dimensions/origins. The previous
  // 1.35 multiplier was an invented browser scale and made the recovered 32px art
  // visibly too large. Keep the exact sprite size and origin from the TPAG mapping.
  const sx=Math.round(p.x-state.cam-meta.ox),sy=Math.round(p.y-meta.oy);
  if(i===state.controlled){
    // [APK-DIRECT] obj_highlight Draw_0 draws spr_player_highlight (51) followed by
    // spr_player_highlight2 (67). Both are recovered TPAG sprites. They belong UNDER
    // the player, not above the head; their recovered origins are (16,7) and (31,14).
    const h=visual.highlight;if(drawableAsset(h)){const hm=window.SPRITE_META?.spr_player_highlight||{ox:16,oy:7,w:32,h:15};X.drawImage(h,Math.round(p.x-state.cam-hm.ox),Math.round(p.y-hm.oy),hm.w,hm.h)}
    const star=visual.star;if(drawableAsset(star)){const sm={ox:31,oy:14,w:63,h:29};X.drawImage(star,Math.round(p.x-state.cam-sm.ox),Math.round(p.y-sm.oy),sm.w,sm.h)}
  }
  if(renderIm){const flip=Math.cos(p.facing)<0;X.save();if(flip){X.translate(Math.round(p.x-state.cam),0);X.scale(-1,1);X.drawImage(renderIm,-meta.ox,sy,meta.w,meta.h)}else X.drawImage(renderIm,sx,sy,meta.w,meta.h);X.restore();}
  if(p.offside)txt(bodyFont,'OFF',p.x-state.cam,p.y-30,.45,'center');
}
function drawBall(){
  const b=state.ball,s=2,shadow=img('ui/ball1.png');
  if(b.z>2&&drawableAsset(shadow)){X.globalAlpha=.3;X.drawImage(shadow,b.x-state.cam-8,b.y-2,16,7);X.globalAlpha=1}
  let drawn=false;
  if(b.animation)drawn=drawGMAnimation(b.animation,b.x-state.cam,b.y-b.z*.25,{scaleX:s,scaleY:s});
  if(!drawn){
    const raw=img('frames_gm/spr_ball1/00.png');
    if(drawableAsset(raw))X.drawImage(raw,b.x-state.cam-7,b.y-b.z*.25-7,14,14);
  }
}
function drawTouchAimGuide(){
  // [APK-DIRECT] s_draw_touch_tip uses sprite 21 (spr_scoreboard9). The actual
  // swipe-to-aim indicator is represented by the recovered spr_arrow_big asset.
  if(state.drag){const p=state.players[state.controlled];if(!p)return;const dx=state.drag.x,dy=state.drag.y;const mx=state.drag.lastX??dx,my=state.drag.lastY??dy;const vx=mx-dx,vy=my-dy,len=Math.hypot(vx,vy);if(len>8){const ar=img('frames_gm/spr_arrow_big/00.png');if(drawableAsset(ar)){X.save();X.translate(dx,dy);X.rotate(Math.atan2(vy,vx)+Math.PI/2);X.globalAlpha=.95;X.drawImage(ar,-9,-11,16,16);X.restore();}}}
}
function drawMatchHUD(){
  // [APK-DIRECT] Match GUI resources recovered from room_field/Draw-GUI: scoreboard9,
  // scoretag, radar and radar dots. The previous build replaced this with a text bar.
  const sc=img('frames_gm/spr_scoreboard9/00.png'), tag=img('frames_gm/spr_scoretag/00.png'), radar=img('frames_gm/spr_radar/00.png');
  X.save();X.imageSmoothingEnabled=false;
  // timer panel
  if(drawableAsset(sc))X.drawImage(sc,8,7,96,48);
  txt(titleFont,'◷',30,16,.9,'center');
  txt(titleFont,String(Math.floor(state.clock)).padStart(2,'0'),72,14,1.05,'center');
  // central score board, using the recovered score tag as its side cap.
  X.fillStyle='#080808';X.fillRect(126,7,520,42);X.strokeStyle='#fff';X.lineWidth=2;X.strokeRect(126.5,7.5,519,41);
  if(drawableAsset(tag)){X.drawImage(tag,126,16,8,24);X.drawImage(tag,638,16,8,24)}
  const ht=teams[state.home],at=teams[state.away];txt(bodyFont,ht.short,155,17,.95);txt(titleFont,String(state.score[0]),355,13,1.45,'center');txt(titleFont,'-',390,17,1.0,'center');txt(titleFont,String(state.score[1]),425,13,1.45,'center');txt(bodyFont,at.short,458,17,.95);
  // recovered radar
  if(drawableAsset(radar)){
    X.globalAlpha=.92;X.drawImage(radar,852,5,98,68);X.globalAlpha=1;
    for(const p of state.players){const rx=852+(p.x/PITCH.right)*98,ry=5+(p.y/PITCH.bottom)*68;const d=img('frames_gm/spr_radar_dot/'+(p.team===0?'00':'01')+'.png');if(drawableAsset(d))X.drawImage(d,Math.round(rx),Math.round(ry),3,3)}
  }
  // Active-player name/condition plate. This is the native match information area,
  // kept resource-backed rather than the previous debug instructions.
  const p=state.players[state.controlled],team=p?teams[p.team===0?state.home:state.away]:null;
  if(p&&team){if(drawableAsset(sc))X.drawImage(sc,8,H-56,190,42);txt(bodyFont,`${team.short} ${p.idx+1}`,18,H-43,.82);X.fillStyle='#151515';X.fillRect(18,H-27,150,8);X.fillStyle='#35d53a';X.fillRect(18,H-27,150*(p.stamina/100),8)}
  X.restore();
}
function drawMatch(){X.fillStyle='#000';X.fillRect(0,0,W,H);drawField();state.players.slice().sort((a,b)=>a.y-b.y).forEach(p=>drawPlayer(p,state.players.indexOf(p)));drawGoal(0,'fore');drawGoal(1,'fore');drawBall();drawTouchAimGuide();drawMatchHUD();const ht=teams[state.home],at=teams[state.away];const mins=Math.floor(state.clock),secs=Math.floor((state.clock-mins)*60);txt(bodyFont,`${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`,W-45,20,.55,'center',.7);if(state.restart)txt(titleFont,state.restart.type.toUpperCase(),W/2,115,1.35,'center');if(state.paused||state.ended){X.fillStyle='rgba(0,0,0,.68)';X.fillRect(0,0,W,H);txt(titleFont,state.ended?'FULL TIME':'HALF TIME',W/2,185,2,'center');txt(bodyFont,`${ht.short} ${state.score[0]}  -  ${state.score[1]} ${at.short}`,W/2,245,1.2,'center');if(state.ended)txt(bodyFont,'ENTER TO RETURN',W/2,320,.9,'center')}if(state.flash>0&&!state.paused)txt(titleFont,state.flashText,W/2,125,2,'center');for(const q of state.particles){X.fillStyle=['#fff','#f44','#4cf','#fc4'][Math.floor(q.life*10)%4];X.fillRect(q.x-state.cam,q.y,2,2)} }
function drawTitle(){
  // [REIMPLEMENTED] Render room_title in its recovered 480x270 room coordinate
  // system at the browser's 2x display scale. This avoids inventing a new layout
  // and, importantly, preserves the wide sprite's real 584px source width.
  const r=Runtime.room('room_title')||{width:480,height:270};
  const sx=W/r.width, sy=H/r.height, S=Math.min(sx,sy);
  X.save(); X.scale(S,S);
  X.fillStyle='#07121c'; X.fillRect(0,0,r.width,r.height);
  const bg=visual.titleBg;
  X.globalAlpha=state.title.opacity;
  // The recovered sprite is 584x270 while room_title is 480x270.  GameMaker's
  // wide title composition is clipped by the room/view; it is not tiled.
  X.save(); X.beginPath(); X.rect(0,0,r.width,r.height); X.clip();
  const bgX=(r.width-bg.naturalWidth)/2 + Math.sin(state.title.t*.28)*5;
  X.drawImage(bg,bgX,0,bg.naturalWidth,bg.naturalHeight);
  X.restore();
  // [APK-DIRECT] Digital overlay is a single 584x26 sprite; it is centered once,
  // not tiled across the room.
  X.globalAlpha=state.title.opacity*.78;
  const ov=visual.titleOverlay;
  X.save(); X.beginPath(); X.rect(0,0,r.width,r.height); X.clip();
  X.drawImage(ov,(r.width-ov.naturalWidth)/2,0,ov.naturalWidth,ov.naturalHeight);
  X.restore();
  X.globalAlpha=state.title.opacity;
  // Title player/ball motion is driven by the title state, while sprite dimensions
  // and origins come from SPRT metadata.
  // [B] Title actors are rendered through the same recovered-frame animation
  // primitive as gameplay rather than bypassing the animation controller.
  const px=state.title.playerX, py=state.title.yTitle??134;
  drawGMAnimation(state.title.playerAnimation,px,py,{alpha:1});
  drawGMAnimation(state.title.ballAnimation,state.title.ballX,state.title.ballY,{alpha:1});
  const lm=window.SPRITE_META.spr_title_logo;
  X.drawImage(visual.titleLogo,r.width/2-(lm?.ox||218),170-(lm?.oy||43),lm?.w||436,lm?.h||87);
  if(state.title.ready)txt(bodyFont,'Tap to Start',r.width/2,19,0.52,'center',Math.min(1,.7+.3*Math.sin(state.title.t*3)));
  const cm=window.SPRITE_META.spr_title_copyright;
  X.globalAlpha=state.title.opacity; X.drawImage(visual.copyright,r.width/2-(cm?.ox||150),r.height-(cm?.oy||4),cm?.w||295,cm?.h||7);
  X.globalAlpha=1; X.restore();
  if(state.title.stage===2){X.fillStyle=`rgba(0,0,0,${state.title.fade})`;X.fillRect(0,0,W,H)}
}
function roomTitle(room){
  const map={room_options:'Options',room_standings:'League Standings',room_results:'Results',room_records:'Records',room_store:'Store',room_office:"Manager's Office",room_lineup:'Team lineup',room_weekend:'League Schedule',room_formation:'Formation',room_tactics:'Tactics',room_roster:'Roster',room_profile:'Profile',room_favouriteteam:'Favourite Team',room_newcareer:'New Career',room_freeagents:'Free Agents',room_seasonend:'Season Results',room_prospects:'Prospects',room_trophies:'Trophies',room_achievements:'Achievements',room_staffhires:'Staff Offices',room_hof:'Hall of Fame',room_teamrecords:'Team Records'};
  return map[room]||room.replace(/^room_/,' ').trim().replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function drawRoomHeader(title,variant='spr_header'){
  X.fillStyle='#0871be';X.fillRect(0,0,W,H);drawUISprite(variant,0,0,UI_SCALE,0,1);
  txt(titleFont,title,240*UI_SCALE,9*UI_SCALE,.72,'center',1);
}
function drawSystemRoom(){
  if(state.runtimeRoom==='room_home'){HomeUI.draw();return}
  const room=state.runtimeRoom;
  drawRoomHeader(roomTitle(room));
  // The following screens are driven by the actual room names/resources discovered
  // in ROOM/OBJT/SCPT. Layout uses recovered panel/card/button primitives; no HTML UI
  // controls or screenshot tracing are used. Where native Draw-GUI coordinates remain
  // stripped from YYC, this is explicitly a [B/C] resource-backed reconstruction.
  if(room==='room_standings'){
    drawUIPanel(18,53,444,202,'spr_panel',0); txt(titleFont,'LEAGUE STANDINGS',240*2,61*2,.66,'center');
    const sorted=[...teams].sort((a,b)=>(b.strength||0)-(a.strength||0)).slice(0,8);
    sorted.forEach((t,i)=>{const y=79+i*21; if(i===state.homeUI.selected)drawUISprite('spr_button_small',42,y-2,2); drawUISprite('spr_icon_shield',25,y,2); txt(bodyFont,String(i+1),45*2,y*2,.5,'center'); txt(bodyFont,t.name,62*2,y*2,.52); txt(bodyFont,String(t.strength||0),418*2,y*2,.5,'right');});
  } else if(room==='room_results'){
    drawUIPanel(26,57,428,154,'spr_panel',0); txt(titleFont,'RESULTS',240*2,66*2,.7,'center');
    const h=teams[state.home],a=teams[state.away]; drawUISprite('spr_card_match_1_team1',105,91,2); drawUISprite('spr_card_match_1_team2',307,91,2);
    txt(bodyFont,h.short,120*2,187*2,.55,'center');txt(titleFont,String(state.score[0]),205*2,124*2,1.2,'center');txt(titleFont,'-',240*2,124*2,.8,'center');txt(titleFont,String(state.score[1]),275*2,124*2,1.2,'center');txt(bodyFont,a.short,360*2,187*2,.55,'center');
    drawUIButton('spr_button',191,225,98,22,'BACK',false,false,'spr_arrow_left');
  } else if(room==='room_options'){
    drawUIPanel(24,52,432,194,'spr_panel',0); txt(titleFont,'OPTIONS',240*2,61*2,.7,'center');
    const opts=['CONTROLS','GAME SPEED','DIFFICULTY','SEASON LENGTH'];opts.forEach((v,i)=>{drawUIButton('spr_button',42,82+i*31,98,22,v,i===state.homeUI.selected,false);});
    txt(bodyFont,'ARROWS / D-PAD SELECT • ENTER CONFIRM • ESC BACK',240*2,228*2,.45,'center',.85);
  } else if(room==='room_lineup'||room==='room_roster'||room==='room_profile'||room==='room_office'||room==='room_weekend'||room==='room_records'||room==='room_store'||room==='room_favouriteteam'||room==='room_newcareer'||room==='room_seasonend'||room==='room_prospects'||room==='room_trophies'||room==='room_achievements'||room==='room_staffhires'||room==='room_hof'||room==='room_teamrecords'||room==='room_freeagents'){
    drawUIPanel(18,52,444,196,'spr_panel',0);
    txt(titleFont,roomTitle(room),240*2,62*2,.68,'center');
    const card=uiAsset('spr_card_team'); if(card?.complete){drawUISprite('spr_card_team',34,82,2);}
    const t=teams[state.home]||{name:'TEAM',short:'TEAM',strength:0};
    txt(titleFont,t.short,69*2,96*2,.62,'center');txt(bodyFont,t.name,69*2,112*2,.48,'center');
    if(room==='room_formation'||room==='room_tactics'){
      drawUISprite('spr_field_model',118,76,1.35); // recovered room_formation/tactics field model
    } else {
      const rows=room==='room_lineup'?['TEAM LINEUP','KEY PLAYERS','SUBSTITUTES','AUTO-PICK']:room==='room_office'?['FACILITIES','STAFF','FINANCES','NEWS']:room==='room_weekend'?['NEXT FIXTURE','SCHEDULE','LEAGUE','CUP']:['CONTINUE','VIEW DETAILS','BACK'];
      rows.forEach((v,i)=>drawUIButton('spr_button',160,82+i*31,145,22,v,i===state.homeUI.selected));
    }
    drawUIButton('spr_button',350,220,98,22,'BACK',false,false,'spr_arrow_left');
  } else if(room==='room_formation'||room==='room_tactics'){
    drawUIPanel(18,52,444,196,'spr_panel',0); txt(titleFont,roomTitle(room),240*2,62*2,.68,'center');
    drawUISprite('spr_field_model',240,143,2);
    txt(bodyFont,room==='room_formation'?'4-4-2 A':'Moderate tackling / Moderate work rate',240*2,232*2,.46,'center');
  } else {
    drawUIPanel(18,52,444,196,'spr_panel',0); txt(titleFont,roomTitle(room),240*2,62*2,.68,'center');
    txt(bodyFont,'RECOVERED ROOM / RESOURCE STATE',240*2,112*2,.52,'center');
    txt(bodyFont,'ENTER CONTINUE • ESC BACK',240*2,220*2,.46,'center',.85);
  }
}

function prematchBg(){
  X.fillStyle='#0871be';X.fillRect(0,0,W,H);
  drawUISprite('spr_header',0,0,UI_SCALE);
  // room_prematch is 480x270 and its recovered static instances are at
  // obj_button=(192,72), obj_prematch_team=(120,160)/(360,160), obj_prematch_cup=(240,152).
  drawUIPanel(24,48,432,190,'spr_panel',0);
}
function drawSelect(){
  prematchBg();
  const h=teams[state.home],a=teams[state.away];
  txt(titleFont,'NEXT GAME',240*2,9*2,.78,'center');
  drawPrematchTeam(120,h,false);drawPrematchTeam(360,a,true);
  drawUISprite('spr_icon_cup',240,152,2);
  drawUIButton('spr_button',192,72,98,22,'CHANGE KITS',state.selectSide===1,false,'spr_icon_form');
  drawUIButton('spr_button',32,224,98,22,'BACK',false,false,'spr_arrow_left');
  drawUIButton('spr_button',191,224,98,22,'FORMATION',state.selectSide===1,false,'spr_icon_form');
  drawUIButton('spr_button',350,224,98,22,'PLAY',state.selectSide===0,false,'spr_icon_football');
  txt(bodyFont,'← / → CHANGE TEAM • TAB SWITCH SIDE • ENTER PLAY',240*2,258*2,.42,'center',.9);
}
function drawPrematchTeam(x,t,away){
  drawUISprite('spr_card_team',x-34.5,117,2);
  const raw=uiAsset(away?'spr_player_idle_hoops':'spr_player_idle_stripes',0);
  if(raw?.complete){const id=prepareKit(t,away,0),im=recolorPlayerImage(raw,id);X.drawImage(im,(x-16)*2,(137)*2,32*2,32*2)}
  txt(titleFont,t.short||'TEAM',x*2,174*2,.62,'center');
  txt(bodyFont,t.name||'TEAM',x*2,187*2,.46,'center');
  txt(bodyFont,`RATING ${t.strength||0}`,x*2,198*2,.44,'center',.9);
}

function drawKit(x,y,t,away){drawPreviewTeam(x,t,away)}
function draw(){if(state.screen==='title')drawTitle();else if(state.screen==='select')drawSelect();else if(state.screen==='system')drawSystemRoom();else drawMatch()}
addEventListener('keydown',e=>{keysDown.add(e.key);InputManager.key(e);});
addEventListener('keyup',e=>keysDown.delete(e.key));
C.tabIndex=0;
C.addEventListener('pointerdown',e=>{C.focus();const r=C.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;startMusic();if(InputManager.pointer(x,y))return;if(state.screen==='match'&&!state.paused&&!state.ended){state.drag={x,y,lastX:x,lastY:y,t:performance.now(),samples:[{x,y,t:performance.now()}]}}});
C.addEventListener('pointermove',e=>{if(!state.drag||state.screen!=='match')return;const r=C.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;state.drag.lastX=x;state.drag.lastY=y;state.drag.samples.push({x,y,t:performance.now()});if(state.drag.samples.length>24)state.drag.samples.shift();});
C.addEventListener('pointerup',e=>{
  const r=C.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;
  if(state.screen!=='match' && state.screen!=='title'){InputManager.pointer(x,y);return}
  if(state.screen==='title' || state.screen==='select')return;
  if(!state.drag||state.screen!=='match')return;
  const d=Math.hypot(x-state.drag.x,y-state.drag.y);state.drag=null;if(d<12){InputManager.dispatch('pass');return}const p=state.players[state.controlled];if(p)humanKick(x+state.cam,y,Math.min(10,5+d/55));
});
C.addEventListener('click',()=>{if(state.screen==='title'){InputManager.dispatch('confirm');return}startMusic();});
// [REIMPLEMENTED] Test/inspection surface. This does not affect rendering and makes the
// browser state machine directly exercisable by automated validation.
window.__RETRO_GOAL_RUNTIME={PITCH,state,ballBoundaries,goalPlaneX,Runtime,InputManager,HomeUI,GM,GMRoom,GMObject,GMScript,GMNative,GMAnimation,update,draw,titleNative:{stage:'_title_stage',stageTime:'_title_stage_time',opacity:'_title_opacity',outDelay:'_title_out_delay',xTitle:'_x_title',yTitle:'_y_title',xScroll:'_x_scroll',yScroll:'_y_scroll',xCopy:'_x_copy',yCopy:'_y_copy',sTitle:'_s_title',sBall:'_s_ball',rBall:'_r_ball'}};
addEventListener('blur',()=>{keysDown.clear();loopState.last=performance.now();loopState.accumulator=0});
addEventListener('focus',()=>{loopState.last=performance.now();loopState.accumulator=0});
if(document.addEventListener)document.addEventListener('visibilitychange',()=>{loopState.last=performance.now();loopState.accumulator=0});
function preloadAnimationSprites(names){
  const paths=[];for(const name of names){const m=window.GM_ANIMATION_DATA?.sprites?.[name];for(const f of (m?.frames||[]))if(f.path)paths.push(f.path.startsWith('assets/')?f.path.slice(7):f.path)}
  return Promise.all([...new Set(paths)].map(p=>loadImage(/^frames_gm\/spr_player_/.test(p)?p.replace('frames_gm/','character_textures_exact/'):p)));
}

function loop(now){
  // [REIMPLEMENTED] Fixed-step gameplay clock. GameMaker advances its room Step events
  // independently of the browser's paint timing; this prevents a slow/throttled frame
  // from turning into a visually frozen match.
  if(!loopState.last)loopState.last=now;
  let elapsed=Math.max(0,Math.min(.20,(now-loopState.last)/1000));
  loopState.last=now;
  loopState.accumulator+=elapsed;
  let steps=0;
  while(loopState.accumulator>=loopState.step && steps<8){update(loopState.step);loopState.accumulator-=loopState.step;steps++;}
  if(steps===0 && state.screen==='match' && !state.paused && !state.ended) update(Math.min(elapsed,.016));
  draw();
  if(!window.__RETRO_TEST_MODE__)requestAnimationFrame(loop);
}
Promise.all([
  Promise.resolve(window.TEAMS),loadFont('title'),loadFont('body'),loadImage('field.png'),
  loadImage('recovered_sprites/162_spr_title_background_wide.png'),
  loadImage('recovered_sprites/223_spr_title_logo.png'),
  loadImage('recovered_sprites/258_spr_title_player.png'),
  loadImage('recovered_sprites/034_spr_title_ball.png'),
  loadImage('recovered_sprites/283_spr_title_digitaloverlay_wide.png'),
  loadImage('recovered_sprites/176_spr_title_copyright.png'),
  loadImage('recovered_sprites/005_spr_player_idle_stripes.png'),loadImage('ui/ball1.png'),
  loadImage('recovered_sprites/204_spr_header.png'),loadImage('recovered_sprites/123_spr_goal_fore.png'),loadImage('recovered_sprites/270_spr_goal_back.png'),loadImage('frames_gm/spr_player_highlight2/00.png'),loadImage('button.png'),loadImage('frames_gm/spr_header/00.png'),loadImage('frames_gm/spr_button/00.png'),loadImage('frames_gm/spr_button/01.png'),loadImage('frames_gm/spr_button/02.png'),loadImage('frames_gm/spr_button_small/00.png'),loadImage('frames_gm/spr_card_team/00.png'),
  loadImage('frames_gm/spr_title_player/00.png'),loadImage('frames_gm/spr_title_ball/00.png'),
  preloadAnimationSprites(['spr_player_idle_stripes','spr_player_idle_hoops','spr_player_run_stripes','spr_player_run_hoops','spr_player_kick_stripes','spr_player_kick_hoops','spr_player_pass_stripes','spr_player_pass_hoops','spr_player_slide_stripes','spr_player_slide_hoops','spr_keeper_idle2','spr_keeper_run2','spr_keeper_collect2','spr_keeper_dive_u','spr_ball1','spr_ball2','spr_player_highlight'])
]).then(v=>{teams=v[0];titleFont=v[1];bodyFont=v[2];Runtime.enter('room_title','boot');document.getElementById('loading').style.display='none';document.getElementById('hint').textContent='Tap/click to start • keyboard, pointer and touch controls supported';loop(performance.now())});
