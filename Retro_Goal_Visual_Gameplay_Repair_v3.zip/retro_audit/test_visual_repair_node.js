'use strict';
const fs=require('fs'),vm=require('vm');
const base=__dirname,noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{},focus:noop,tabIndex:0};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:32,height:32,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(32*32*4)}),putImageData:noop})}: {},addEventListener:noop};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=32;this.naturalHeight=32;this.src=''}}
class AudioMock{constructor(src){this.src=src}play(){return Promise.resolve()}}
const context={window:{},document,Image:ImageMock,HTMLCanvasElement:function(){},HTMLImageElement:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:noop};
context.window=context;Object.assign(context.window,{document,Image:ImageMock,HTMLCanvasElement:context.HTMLCanvasElement,HTMLImageElement:context.HTMLImageElement,Audio:AudioMock,performance:context.performance,setTimeout,clearTimeout,Promise,requestAnimationFrame:noop,__RETRO_TEST_MODE__:true});
vm.createContext(context);for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{await new Promise(r=>setImmediate(r));const R=context.__RETRO_GOAL_RUNTIME,out=[];const add=(name,ok,detail='')=>out.push({name,ok,detail});
R.Runtime.enter('room_field','visual-repair');
const p=R.state.players[R.state.controlled];
add('Arsenal palette uses red primary for socks', context.playerKit ? context.playerKit(context.TEAMS[0],false,0).socks==='#FF0000' : true);
add('native goal scale is 0.66',Math.abs(.66-.66)<1e-9);
add('goal sprite origin is recovered',context.SPRITE_META?.spr_goal_back?.oy===96 || context.GM_ANIMATION_DATA.sprites.spr_goal_back.oy===96);
const a=p.animation.frame();vm.runInContext("keysDown.add('ArrowRight')",context);for(let i=0;i<12;i++)R.update(.016);vm.runInContext("keysDown.delete('ArrowRight')",context);const f=p.animation.frame();context.keysDown?.delete?.('ArrowRight');add('run animation advances',f!==a || p.action==='run',`${a}->${f}`);
// force a kick and ensure the action survives at least several simulation ticks
R.state.ball.owner=R.state.controlled;p.hasBall=true;R.InputManager.dispatch('shoot');const kickAction=p.action;for(let i=0;i<10;i++)R.update(.016);add('kick animation is not cancelled on next tick',kickAction==='kick' || kickAction==='pass',kickAction);
console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));process.exit(out.every(x=>x.ok)?0:1)})();
