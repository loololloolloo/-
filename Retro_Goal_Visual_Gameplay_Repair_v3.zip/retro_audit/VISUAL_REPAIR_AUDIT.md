# Retro Goal — visual/gameplay repair audit

This checkpoint addresses the problems visible in the manual test screenshots.

## Character rendering

The source player rasters are the TPAG-derived GameMaker frames. The renderer now uses the exact recovered frame files and the native `sh_ColorReplaceClip` RGB-key replacement semantics.

The earlier head-region mask was removed. It was a browser invention and could alter legitimate pixels. Kit-channel mapping was corrected to match the recovered 12-key palette semantics for the Arsenal-style kit:

- shirt = primary
- shirt2 = darkened primary
- stripes = secondary
- stripes2 = darkened secondary
- shorts = shorts
- shorts2 = darkened shorts
- socks = primary
- socks2 = darkened primary
- skin/hair = recovered native palettes
- boots = recovered dark boot colour

## Animation

The previous action state was overwritten on the very next Step after a kick/pass. That made kick/pass animations effectively one frame. `actionUntil` now keeps the recovered kick/pass animation active for its animation window while movement/AI continues normally.

The exact player animation files are preloaded from `assets/character_textures_exact/` rather than falling back to the older frame tree.

## Goals

The APK's native `obj_goal_back_Draw_0` and `obj_goal_fore_Draw_0` were disassembled directly. Both draw the recovered goal sprites at **0.66 scale**, with the recovered sprite origin `(0,96)`. The right goal is mirrored around its origin. The browser renderer now preserves those scale/origin semantics instead of drawing the 91x98 raster at 1x from its top-left corner.

## Touch / swipe shooting

The match controller has recovered drag-start/dragging/drag-end gesture events and `s_aim_mode_hold`. The browser now keeps the pointer drag samples, updates the live drag endpoint, and displays the recovered `spr_arrow_big` while the swipe is being aimed. The exact `spr_scoreboard9` resource used by the native `s_draw_touch_tip` path is also used by the browser match GUI.

## Match GUI

The old text-only debug HUD was removed. The match HUD now consumes recovered `spr_scoreboard9`, `spr_scoretag`, `spr_radar`, and `spr_radar_dot` resources, plus the recovered pixel font. The active-player condition plate is resource-backed rather than the old keyboard-control footer.

## Validation

The existing Phase 0–6 and gameplay regression suites pass, plus `test_visual_repair_node.js`.

Automated Chromium screenshot validation remains unavailable in this environment: headless Chromium did not complete within the smoke-test timeout. Manual hosted HTTP/HTTPS testing remains the authoritative visual check.
