from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parent
FRAMES=ROOT/'assets/frames_gm'
KIT_KEYS={
'hair':'#ff0000','shirt':'#ffff00','shirt2':'#808000','skin':'#00ff00','skin2':'#008000',
'shorts':'#0000ff','shorts2':'#800080','socks':'#00ffff','socks2':'#008080',
'stripes':'#ff00ff','stripes2':'#000080','boots':'#000000'}

def rgb(h): h=h[1:]; return tuple(int(h[i:i+2],16) for i in (0,2,4))

def dark(c,f): return tuple(round(v*f) for v in c)

# Arsenal home kit, plus the same three recovered skin/hair variants used by the runtime.
kit={'shirt':rgb('#ff0000'),'shirt2':rgb('#ffffff'),'stripes':rgb('#ffffff'),'stripes2':rgb('#ff0000'),
     'shorts':rgb('#ffffff'),'shorts2':rgb('#b8b8b8'),'socks':rgb('#ffffff'),'socks2':rgb('#ff0000'),
     'skin':rgb('#eec39a'),'skin2':rgb('#ba8857'),'hair':rgb('#fac80a'),'boots':rgb('#141414')}
src={k:rgb(v) for k,v in KIT_KEYS.items()}
for sprite in ['spr_player_idle_stripes','spr_player_run_stripes','spr_player_kick_stripes','spr_player_pass_stripes','spr_player_slide_stripes',
               'spr_player_idle_hoops','spr_player_run_hoops','spr_player_kick_hoops','spr_player_pass_hoops','spr_player_slide_hoops']:
    for path in sorted((FRAMES/sprite).glob('*.png')):
        im=Image.open(path).convert('RGBA')
        bad=0; changed=0
        for y in range(im.height):
            for x in range(im.width):
                r,g,b,a=im.getpixel((x,y))
                if a!=255: continue
                k=next((name for name,c in src.items() if (r,g,b)==c),None)
                if not k: continue
                nx=(x-im.width*.5)/(im.width*.20); ny=(y-im.height*.30)/(im.height*.23)
                in_head=nx*nx+ny*ny<=1
                if in_head and k not in ('hair','skin','skin2'):
                    out=dark(kit['hair'],.55); changed+=1
                else:
                    out=kit.get(k,(r,g,b))
                # Kit primary/secondary colours must never be introduced by the head guard.
                if in_head and k not in ('hair','skin','skin2') and out in (kit['shirt'],kit['shirt2'],kit['stripes'],kit['stripes2'],kit['shorts'],kit['shorts2'],kit['socks'],kit['socks2']):
                    bad+=1
        assert bad==0, (sprite,path,bad)
    
print('PASS: head/face palette guard verified across recovered player animation frames')
