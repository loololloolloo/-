from pathlib import Path
import json
from PIL import Image, ImageChops
ROOT=Path(__file__).resolve().parent
m={x['name']:x for x in json.loads((ROOT/'recovered/sprite_texture_mapping.json').read_text())['sprites']}
for name in ('spr_player_highlight','spr_player_highlight2'):
    s=m[name]
    for fi,fr in enumerate(s['frames']):
        atlas=Image.open(ROOT/f"recovered/atlases/atlas_{fr['texturePage']}_{'2048x2048' if fr['texturePage'] in (1,2) else '2048x128'}.png").convert('RGBA')
        crop=atlas.crop((fr['sourceX'],fr['sourceY'],fr['sourceX']+fr['sourceW'],fr['sourceY']+fr['sourceH']))
        exp=Image.new('RGBA',(s['w'],s['h']),(0,0,0,0));exp.alpha_composite(crop,(fr['targetX'],fr['targetY']))
        actual=Image.open(ROOT/f'assets/frames_gm/{name}/{fi:02d}.png').convert('RGBA')
        assert ImageChops.difference(actual,exp).getbbox() is None,(name,fi)
    print(f'PASS exact indicator texture: {name} origin=({s["ox"]},{s["oy"]}) size={s["w"]}x{s["h"]}')
