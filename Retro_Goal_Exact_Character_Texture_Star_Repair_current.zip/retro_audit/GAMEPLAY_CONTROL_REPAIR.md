# Gameplay Control / Goal Repair

## Recovered resources and evidence used
- `spr_goal_fore` and `spr_goal_back` are recovered GameMaker sprites with origin `(0,96)`.
- `spr_player_highlight2` is the recovered match player-selection star/highlight resource.
- Native/YYC symbol evidence includes ball boundaries, goal boundaries, kick velocity/trajectory, ball movement, tackling/interception and passing systems.

## Repairs
- Restored match pitch coordinates to the recovered `field.png` geometry: `(95,140)` through `(1648,487)` with goal mouth `y=265..378`.
- Goals now render from their recovered origin at the actual goal-line coordinates, with the rear net behind players and the foreground net in front.
- Goal detection uses perspective goal-mouth crossing planes rather than a large rectangular trigger.
- Increased kick/pass travel velocity to gameplay-scale values so the ball does not appear frozen after a kick.
- Increased post-kick protection so the kicker cannot immediately reclaim a newly struck ball.
- Passing now releases the ball reliably and, when a teammate is already the carrier, makes that carrier active instead of silently discarding the action.
- Defensive tackle can directly win the ball from a nearby opponent carrier and is no longer blocked by the kick/pass protection timer.
- Restarts now give the restart side an actual ball carrier; human-side restarts select the controlled player.
- Added the recovered `spr_player_highlight2` star above the active player.

## Validation
- All Phase 0/2/3/4/5/6 Node tests pass.
- Added `test_gameplay_controls_regression.js` covering pass release/speed, defensive possession recovery, and goal-mouth scoring.
- `test_player_head_kit_guard.py` passes.
