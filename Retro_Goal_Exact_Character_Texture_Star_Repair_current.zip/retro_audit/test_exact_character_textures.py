from pathlib import Path
import json
from PIL import Image, ImageChops

BASE=Path(__file__).resolve().parent
mapping=json.loads((BASE/'recovered/sprite_texture_mapping.json').read_text())['sprites']
page_sizes={0:'64x64',1:'2048x2048',2:'2048x2048',3:'2048x128'}
checked=0
for sprite in mapping:
    name=sprite['name']
    if not name.startswith('spr_player_'):
        continue
    for fi,fr in enumerate(sprite.get('frames',[])):
        atlas=Image.open(BASE/f"recovered/atlases/atlas_{fr['texturePage']}_{page_sizes[fr['texturePage']]}.png").convert('RGBA')
        crop=atlas.crop((fr['sourceX'],fr['sourceY'],fr['sourceX']+fr['sourceW'],fr['sourceY']+fr['sourceH']))
        expected=Image.new('RGBA',(sprite['w'],sprite['h']),(0,0,0,0))
        expected.alpha_composite(crop,(fr['targetX'],fr['targetY']))
        actual=Image.open(BASE/f'assets/frames_gm/{name}/{fi:02d}.png').convert('RGBA')
        assert actual.size==expected.size, (name,fi,actual.size,expected.size)
        diff=ImageChops.difference(actual,expected)
        assert diff.getbbox() is None, (name,fi,diff.getbbox())
        checked+=1
print(f'PASS exact APK TPAG reconstruction: {checked} player frames')
