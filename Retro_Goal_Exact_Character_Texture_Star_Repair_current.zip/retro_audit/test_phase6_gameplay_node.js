'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const base=__dirname,noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{},focus:noop,tabIndex:0};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:32,height:32,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(32*32*4)}),putImageData:noop})}: {},addEventListener:noop};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=32;this.naturalHeight=32;this.src=''}}
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1}play(){return Promise.resolve()}}
const context={window:{},document,Image:ImageMock,HTMLCanvasElement:function(){},HTMLImageElement:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:noop};
context.window=context;context.window.window=context;context.window.document=document;context.window.Image=ImageMock;context.window.HTMLCanvasElement=context.HTMLCanvasElement;context.window.HTMLImageElement=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.__RETRO_GOAL_RUNTIME,out=[];const add=(name,ok,detail='')=>out.push({name,ok,detail});
 R.Runtime.enter('room_field','gameplay-blocker-fix');
 add('match starts live',R.state.screen==='match'&&!R.state.paused&&!R.state.ended&&R.state.matchRunning,`${R.state.screen}/${R.state.paused}/${R.state.matchRunning}`);
 add('14 playable players created',R.state.players.length===14,R.state.players.length);
 add('controlled player visible in viewport',(()=>{const p=R.state.players[R.state.controlled];return p.x-R.state.cam>80&&p.x-R.state.cam<880&&p.y>0&&p.y<540})());
 const idleFrame=R.state.players[R.state.controlled].animation.frame();
 vm.runInContext("keysDown.add('ArrowRight')",context);
 for(let i=0;i<5;i++)R.update(1/60);
 vm.runInContext("keysDown.delete('ArrowRight')",context);
 const p=R.state.players[R.state.controlled];
 add('held movement changes player position',p.x>852,`x=${p.x}`);
 add('held movement changes animation state',p.action==='run'&&p.animation.frame()!==idleFrame,`${p.action}/${idleFrame}->${p.animation.frame()}`);
 const ballBefore={x:R.state.ball.x,y:R.state.ball.y};
 const launched=R.InputManager.dispatch('shoot');
 add('shoot consumes kickoff possession',launched===true&&R.state.ball.owner===-1,`${launched}/${R.state.ball.owner}`);
 const bx0=R.state.ball.x,by0=R.state.ball.y;
 for(let i=0;i<30;i++)R.update(1/60);
 add('ball physically moves after shot',Math.hypot(R.state.ball.x-bx0,R.state.ball.y-by0)>10,`${bx0},${by0}->${R.state.ball.x},${R.state.ball.y}`);
 const aiBefore=R.state.players.filter(q=>q.team===1).map(q=>[q.x,q.y]);
 for(let i=0;i<120;i++)R.update(1/60);
 const aiMoved=R.state.players.filter(q=>q.team===1).some((q,i)=>Math.hypot(q.x-aiBefore[i][0],q.y-aiBefore[i][1])>0.5);
 add('AI players continue updating',aiMoved);
 add('match clock advances',R.state.clock>0,`${R.state.clock}`);
 add('camera remains bounded',R.state.cam>=0&&R.state.cam<=783,`${R.state.cam}`);
 try{R.draw();add('full match renderer completes',true)}catch(e){add('full match renderer completes',false,e.stack||e.message)}
 // Reinitialize and prove a clean kickoff can be played again.
 R.Runtime.enter('room_field','restart');
 add('re-entering match resets to playable kickoff',R.state.ball.owner===R.state.controlled&&!R.state.ended&&!R.state.paused,`${R.state.ball.owner}/${R.state.controlled}`);
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
