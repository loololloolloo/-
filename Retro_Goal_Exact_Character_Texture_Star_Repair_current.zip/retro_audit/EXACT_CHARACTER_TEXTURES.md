# Exact character texture extraction audit

The match character textures are not recreated drawings. They are exact TPAG crops recovered from the APK's GameMaker texture page 2.

## Source of truth

- APK: `Retro_Goal-1.0.1.apk`
- GameMaker texture page: `recovered/atlases/atlas_2_2048x2048.png`
- Sprite/frame mapping: `recovered/sprite_texture_mapping.json`
- Animation metadata: `gm_animation_data.js`
- Native clothes shader: `recovered/shaders/sh_ColorReplaceClip_fragment.glsl`

Every `spr_player_*` frame used by the match is reconstructed from its recorded `(sourceX, sourceY, sourceW, sourceH)` rectangle and `(targetX, targetY)` placement. A verification script compares the browser frame PNG byte pixels against the atlas-derived reconstruction.

The browser recolour pass now follows the recovered shader literally: only fully opaque pixels whose RGB matches one of the recovered palette keys are replaced. The previous browser-only head ellipse has been removed because it was not part of the native shader.

## Native selection indicator

`obj_highlight_Draw_0` in the YYC binary directly draws:

1. `spr_player_highlight` (resource 51)
2. `spr_player_highlight2` (resource 67)

The browser now uses those exact recovered sprites, with their recovered origins, beneath the controlled player. `spr_player_highlight2` is the large star-shaped indicator; no replacement graphic is used.
