# Visual validation — APK-driven pass

## Asset pipeline

- `assets/game.droid` remains the source of truth.
- All 295 sprite resources have all referenced TPAG items resolved: 1011/1011.
- Texture pages retained at their recovered dimensions: 64×64, 2048×2048, 2048×2048 and 2048×128.
- `recovered/sprite_texture_mapping.json` records source/target/bounding rectangles and page IDs.

## Fixed issues

### Player textures

**Fixed at the rendering layer.** Raw player sprites are GameMaker shader-key textures, not final team-coloured sprites. Canvas now applies the recovered `sh_ColorReplaceClip` palette-replacement behavior before drawing. Exact sprite origins from SPRT metadata are also used.

### Goals

**Fixed from original resources.** `spr_goal_back` and `spr_goal_fore` are drawn at both goal mouths and use the same field coordinate system as the gameplay goal boundaries.

### White circle

**Removed at source.** The previous reconstruction-only circular debug draw is gone. The recovered `spr_player_highlight` is now used for the controlled-player indicator.

### Title

**Rebuilt from original resources.** The previous generic menu composition is gone. The browser now layers the recovered title stadium, player, ball, logo, digital overlay and copyright resources. `Tap to Start` uses the recovered bitmap font and APK English localization string.

### Team/prematch presentation

**Replaced the kit rectangles.** The browser now uses recovered player sprites with the clothes shader reconstruction, recovered match header/button resources and the existing APK team data.

## Checks performed

- `node --check game.js` — passed.
- VM canvas harness rendered title, prematch and match paths without renderer exceptions.
- VM match harness initialized 14 players and a ball.
- 2,000+ simulation ticks after the visual changes produced finite player/ball state.
- Goal, halftime and fulltime state paths were exercised.
- No remaining `X.arc(...)` debug player-circle draw exists in `game.js`.
- The old `QUICK MATCH` / `TEAM SELECT` title placeholder labels are no longer present.
- The old rectangle-based `drawKit()` implementation is no longer present.

## Environment limitation

Chromium headless in this execution environment starts but does not terminate reliably, so a real browser screenshot could not be captured automatically. The runtime was nevertheless served over HTTP and exercised through a DOM/canvas harness, while the visual asset compositions were independently rendered from the recovered resources for inspection.

## Remaining work

The broader recovered resource set is intentionally retained. 273 of 295 sprite resources are not yet directly drawn by the current browser runtime. These include career/menu, keeper, replay, cards, tactics, weather and other systems. They are candidates for subsequent data-driven screen reconstruction and have not been deleted or replaced.


## Player head/kit-color leakage repair

The recovered 32x32 player rasters use the native `sh_ColorReplaceClip` palette, but kit-key colours also occur as pixel-art shading inside the head region. A blind canvas palette replacement therefore allowed primary/secondary kit colours to leak into hair/face pixels. The browser recolour pass now preserves recovered skin/hair keys in the head and maps other key colours inside the head silhouette to a hair shadow, while leaving body kit replacement unchanged. This is a browser rendering correction; the recovered source rasters and native shader source remain untouched.
