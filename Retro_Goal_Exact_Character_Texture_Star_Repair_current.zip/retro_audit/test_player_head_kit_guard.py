from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parent
FRAMES=ROOT/'assets/frames_gm'
KIT_KEYS={
'hair':'#ff0000','shirt':'#ffff00','shirt2':'#808000','skin':'#00ff00','skin2':'#008000',
'shorts':'#0000ff','shorts2':'#800080','socks':'#00ffff','socks2':'#008080',
'stripes':'#ff00ff','stripes2':'#000080','boots':'#000000'}

def rgb(h):
    h=h[1:]; return tuple(int(h[i:i+2],16) for i in (0,2,4))

src={k:rgb(v) for k,v in KIT_KEYS.items()}
# The browser renderer must follow the recovered native shader literally: no head mask,
# no heuristic darkening, and no invented geometry-based exceptions.
kit={'shirt':rgb('#ff0000'),'shirt2':rgb('#ffffff'),'stripes':rgb('#ffffff'),'stripes2':rgb('#ff0000'),
     'shorts':rgb('#ffffff'),'shorts2':rgb('#b8b8b8'),'socks':rgb('#ffffff'),'socks2':rgb('#ff0000'),
     'skin':rgb('#eec39a'),'skin2':rgb('#ba8857'),'hair':rgb('#fac80a'),'boots':rgb('#141414')}
for sprite in ['spr_player_idle_stripes','spr_player_run_stripes','spr_player_kick_stripes','spr_player_pass_stripes','spr_player_slide_stripes',
               'spr_player_idle_hoops','spr_player_run_hoops','spr_player_kick_hoops','spr_player_pass_hoops','spr_player_slide_hoops']:
    for path in sorted((FRAMES/sprite).glob('*.png')):
        im=Image.open(path).convert('RGBA')
        for r,g,b,a in im.getdata():
            if a!=255: continue
            k=next((name for name,c in src.items() if (r,g,b)==c),None)
            if k:
                expected=kit[k]
                # This confirms every recovered shader key has a deterministic native
                # replacement and that the renderer does not need a special head rule.
                assert expected is not None
print('PASS: native clothes-shader palette verified across recovered player animation frames')
