# Phase 6 — Gameplay Blocker Audit / Playability Fix

## User-reported blocker

The match room could be entered, but manual testing showed a visually frozen pitch with no usable gameplay presentation or response after `PLAY NEXT`.

## Root-cause investigation

The match room itself is recovered as `room_field` (1743×530) with native objects `obj_camera`, `obj_match_controller`, `obj_digital_ad`, and `obj_transition`. The native match-controller Step event calls `s_match_controller_step`, while the player Step event calls `s_update_fundamentals`. Native match-controller gesture events dispatch to the recovered global tap/drag handlers.

The browser implementation had the underlying simulation state, but the browser presentation/input path was too fragile for a cold/manual load:

- player shader canvases were not treated identically to image assets;
- fallback gameplay assets were not explicitly preloaded;
- browser render cadence was used directly as the simulation clock;
- camera tracking was based on ball position rather than the controlled player;
- gameplay input did not expose a clear live-match control state;
- a shoot request could be rejected by an inherited cooldown state;
- touch/drag input was not clearly surfaced as the recovered global tap/drag interaction model.

## Fixes

1. Recovered player frames remain the primary artwork and shader-recolored Canvas is the primary render target.
2. Raw recovered player frames are a last-resort render target; no generated placeholder art is used.
3. Recovered ball/player fallback assets are preloaded.
4. Match simulation uses a fixed 60 Hz browser-side step accumulator with a bounded catch-up window.
5. Camera tracks the active controlled player through the recovered match-world bounds.
6. Match entry explicitly initializes a live kickoff: 14 players, controlled player, ball possession, and camera.
7. Keyboard controls are centralized through InputManager; WASD/arrow movement, X shoot, C pass, Tab switch, Escape pause are supported by the browser layer.
8. Pointer/touch remains centralized; tap passes and drag produces a kick, corresponding to the APK's recovered global tap/drag gesture family.
9. Match HUD hint changes to live gameplay controls when `room_field` is entered.
10. Visibility/focus changes reset the browser timing accumulator so backgrounding the tab cannot leave a stale simulation delta.

## Native evidence

The APK contains:

- `gml_Object_obj_match_controller_Create_0` → `s_match_controller_init`
- `gml_Object_obj_match_controller_Step_0` → `s_match_controller_step`
- `gml_Object_obj_match_controller_Step_2` → `s_match_controller_end_step`
- `gml_Object_obj_match_controller_Gesture_64` → `s_match_controller_global_tap`
- `gml_Object_obj_match_controller_Gesture_65` → `s_match_controller_double_tap`
- `gml_Object_obj_match_controller_Gesture_66` → `s_match_controller_global_drag_start`
- `gml_Object_obj_match_controller_Gesture_67` → `s_match_controller_global_dragging`
- `gml_Object_obj_match_controller_Gesture_68` → `s_match_controller_global_drag_end`
- `gml_Object_obj_player_Step_0` → `s_update_fundamentals`

These are browser-side reimplementations of the recovered application behavior, not execution of the original native code in JavaScript.

## Functional verification

`test_phase6_gameplay_node.js`: **12/12 PASS**

Verified:

- live match starts;
- 14 players exist;
- controlled player is in the viewport;
- held movement changes player position;
- run animation advances;
- shoot consumes possession;
- ball physically moves after a shot;
- AI players continue updating;
- match clock advances;
- camera remains bounded;
- complete match renderer executes;
- re-entering the match resets to a playable kickoff.

`test_phase6_node.js`: **11/11 PASS**

`node --check game.js`: **PASS**

## Browser-environment limitation

The local automated Chromium environment is policy-blocked from navigating the project (`ERR_BLOCKED_BY_ADMINISTRATOR`), so no false claim of a successful automated Chromium screenshot is made. Manual browser testing of the packaged build remains the final visual verification.
