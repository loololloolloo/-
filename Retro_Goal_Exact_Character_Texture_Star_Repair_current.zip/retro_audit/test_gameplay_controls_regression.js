'use strict';
const fs=require('fs'),vm=require('vm');
const base=__dirname,noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{},focus:noop,tabIndex:0};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:32,height:32,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(32*32*4)}),putImageData:noop})}: {},addEventListener:noop};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=32;this.naturalHeight=32;this.src=''}}
class AudioMock{constructor(src){this.src=src}play(){return Promise.resolve()}}
const context={window:{},document,Image:ImageMock,HTMLCanvasElement:function(){},HTMLImageElement:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:noop};
context.window=context;Object.assign(context.window,{document,Image:ImageMock,HTMLCanvasElement:context.HTMLCanvasElement,HTMLImageElement:context.HTMLImageElement,Audio:AudioMock,performance:context.performance,setTimeout,clearTimeout,Promise,requestAnimationFrame:noop,__RETRO_TEST_MODE__:true});
vm.createContext(context);for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{await new Promise(r=>setImmediate(r));const R=context.__RETRO_GOAL_RUNTIME,out=[];const add=(name,ok,detail='')=>out.push({name,ok,detail});R.Runtime.enter('room_field','controls-regression');
 add('kickoff possession',R.state.ball.owner===R.state.controlled);
 const shooter=R.state.controlled, startX=R.state.ball.x; add('pass accepted',R.InputManager.dispatch('pass')===true); add('pass releases ball',R.state.ball.owner===-1);add('pass travels at gameplay speed',Math.hypot(R.state.ball.vx,R.state.ball.vy)>100);
 add('pass direction is active',Math.hypot(R.state.ball.vx,R.state.ball.vy)>100);
 // Defensive steal: place the opponent carrier directly in front of the controlled player.
 const p=R.state.players[R.state.controlled],opp=R.state.players.find(q=>q.team===1&&!q.red),oi=R.state.players.indexOf(opp);p.x=opp.x-12;p.y=opp.y;R.state.ball.owner=oi;opp.hasBall=true;R.InputManager.dispatch('tackle');add('tackle recovers possession',R.state.ball.owner===R.state.controlled);
 // Goal crossing: place a free ball just inside the left mouth and drive it through the recovered perspective plane.
 R.state.ball.owner=-1;R.state.restart=null;R.state.score=[0,0];R.state.ball.x=R.goalPlaneX(0,320)-2;R.state.ball.y=320;R.state.ball.z=0;R.state.ball.vx=-500;R.state.ball.vy=0;R.ballBoundaries(.01);add('goal crossing increments score',R.state.score[1]===1,`${R.state.score[0]}-${R.state.score[1]}`);
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));process.exit(out.every(x=>x.ok)?0:1)})();
