# Exact character texture/render repair

- 250 `spr_player_*` animation frames were copied byte-for-byte from the TPAG-derived `assets/frames_gm` extraction into `assets/character_textures_exact`.
- `recovered/EXACT_CHARACTER_TEXTURE_MANIFEST.json` records each texture-page source rectangle, target rectangle, origin and SHA-256.
- `game.js` now loads those exact character files for match rendering.
- Removed the unsupported 1.35x browser player scale; native GameMaker sprite dimensions/origins are used.
- The clothes replacement still uses the recovered `sh_ColorReplaceClip` palette keys and recovered skin/hair colours.
- Because the recovered player textures reuse kit palette colours as pixel-art shading inside the head, the browser shader-equivalent pass now derives a head mask from the actual recovered hair/skin pixels instead of an invented geometric ellipse. Only shared palette pixels inside that recovered head region are reassigned to the nearest hair/skin semantic source.
- The player indicator uses the exact TPAG-derived `spr_player_highlight2` frame; no generated star graphic is used.
