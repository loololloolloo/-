import express from "express";
import { createServer } from "node:http";
import { WebSocketServer } from "ws";

const app = express();
const server = createServer(app);
const PORT = process.env.PORT || 8080;

app.use((req, res, next) => {
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  next();
});

app.use(express.static("public"));

app.get("/health", (_req, res) => {
  res.json({ ok: true, target: "https://www.madxka.com/" });
});

const wss = new WebSocketServer({ server, path: "/wisp/" });
wss.on("connection", (socket) => {
  // This starter intentionally keeps the transport endpoint isolated.
  // The browser-side proxy UI remains usable for normal HTTP resources.
  socket.close(1000, "Wisp transport not configured");
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Madxka proxy: http://localhost:${PORT}`);
});