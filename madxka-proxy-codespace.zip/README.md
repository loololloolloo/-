# Madxka Proxy

A ChromeOS/Codespaces-friendly starter project for inspecting the publicly accessible Madxka site.

## Codespaces

1. Upload this repository to GitHub.
2. Open it in GitHub Codespaces.
3. Wait for `npm install`.
4. Run:

```bash
npm start
```

5. Open the forwarded port 8080.

## ChromeOS

ChromeOS itself does not need Python, BAT files, or local executables for this project. The intended deployment is a Codespace (or another Node host), then open its forwarded HTTPS URL in Chrome.

## Architecture

A robust interception proxy is more than an iframe: it uses a service worker, URL/JS/CSS rewriting, and a server transport. Scramjet is designed around that architecture.

This package provides the Codespace shell and UI. The included transport endpoint is intentionally not wired to a censorship-bypass transport. If you control the deployment and want a general-purpose web compatibility proxy, integrate the upstream Scramjet packages following their current documentation.

Target used for testing: https://www.madxka.com/
