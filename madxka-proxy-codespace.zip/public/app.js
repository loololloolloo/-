const form = document.querySelector("#form");
const input = document.querySelector("#url");
const frame = document.querySelector("#frame");

function normalize(value) {
  value = value.trim();
  if (!/^https?:\/\//i.test(value)) value = "https://" + value;
  return value;
}

// This UI is deliberately separated from any school/network filtering logic.
// For a full interception proxy, use the Scramjet stack in the Codespace.
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const target = normalize(input.value);
  frame.src = target;
});