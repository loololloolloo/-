# Retro Goal — Phase 5 Validation

## Scope

Phase 5 reconstructs the browser UI/menu layer from recovered GameMaker resources, room metadata, object/script names, localization strings, and native event evidence.

This phase does **not** claim that stripped YYC GUI coordinates are fully recovered. Exact resource identities and room/object relationships are marked APK-derived; browser layout where native constants remain unavailable is marked B/C.

## Implemented

- 480x270 GameMaker logical UI coordinate system rendered at the existing 2x browser canvas scale.
- Recovered `spr_header`, `spr_button` (normal/highlight/pressed), `spr_panel`, `spr_card_team`, match cards, icons, arrows and field-model resources are consumed directly.
- Home menu now uses all nine recovered `s_home_btn_*` actions plus the recovered continue action.
- Home button hit testing uses the same logical UI coordinate system as rendering.
- Prematch static room instances are consumed using the recovered ROOM positions:
  - `obj_button`: 192,72
  - `obj_prematch_team`: 120,160 and 360,160
  - `obj_prematch_cup`: 240,152
- Standings, results, options, lineup, weekend, office, records, store, formation and tactics rooms now render resource-backed UI instead of the former generic room/object placeholder.
- Centralized system-room keyboard navigation supports up/down/confirm/back without per-screen DOM handlers.
- Existing title animation/input and match runtime remain integrated.
- Centered bitmap-font text calculation corrected to use half-width for centered text.

## Automated tests

`node test_phase5_node.js`

Result: **19/19 PASS**

Coverage includes:

- recovered home action count
- logical home hit regions
- three-state button resource availability
- home renderer execution
- prematch renderer execution
- standings/results/options renderers
- lineup/weekend/office/records/store renderers
- formation/tactics renderers
- title → home regression
- home → match regression

## Regression

`node --check game.js` — PASS.

The existing Phase 0–4 runtime behavior remains in the same production `game.js`; no gameplay systems were removed or replaced.

## Known limitation

A real Chromium visual capture cannot currently be used as an automated oracle in this environment because the available browser process is blocked/hangs when navigating to the local HTTP server. Manual testing remains the authoritative visual check.

Native YYC stripping also prevents confident recovery of every dynamic GUI coordinate. Those positions are isolated in the UI renderer and explicitly treated as B/C rather than falsely labeled APK-direct.
