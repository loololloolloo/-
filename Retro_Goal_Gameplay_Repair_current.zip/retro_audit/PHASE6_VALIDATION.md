# Retro Goal — Phase 6 Validation

## Scope

Phase 6 is the gameplay-runtime integration pass. The Phase 5 UI/runtime systems and recovered assets are retained. This phase addresses the manual-test failure where `PLAY NEXT` reached `room_field` but the visible match could appear empty/off-screen.

## APK evidence used

- `room_field` recovered as **1743×530** with `obj_camera`, `obj_match_controller`, `obj_digital_ad`, and `obj_transition`.
- Native `obj_camera Step_2` calls `s_update_match_cam` every frame.
- Native `obj_camera Create_0` calls `s_camera_setview`.
- Recovered match symbols include player, ball, goal, camera, movement, kick, pass, tackle, interception and restart systems.

These facts are used as the structural basis for the browser implementation. Numeric camera interpolation and some gameplay constants remain `[APPROX]` where the stripped YYC does not expose readable GML source.

## Implementation

### Match camera

- Added a 1743px match-world model.
- Camera target follows the active controlled player.
- Camera is clamped to the recovered room width.
- Camera initializes immediately at kickoff so the controlled player is inside the viewport.
- Camera updates every live match frame.

### World rendering

- Field, players, ball and goals now share the same world-to-camera transform.
- Goal rendering is camera-relative instead of remaining fixed to screen coordinates.
- Match rendering is clipped to the recovered room height.

### Player visibility/loading

- Gameplay animation families are preloaded before the runtime starts.
- Player rendering uses the recovered animation resources and SPRT origins.
- A recovered player sprite remains available as a cold-cache fallback rather than allowing a completely blank player draw.

### Gameplay state

- Existing possession, dribble, pass, shoot, tackle, interception, goalkeeper, offside, restart, halftime and fulltime systems remain integrated.
- Kickoff continues to give the controlled player immediate possession.

## Automated validation

`test_phase6_node.js`: **11/11 PASS**

- 14 players created
- recovered 1743px match world recognized
- controlled player immediately inside viewport
- kickoff possession assigned
- player movement changes world position
- camera follows active player
- camera stays within bounds
- all 16 gameplay animation families resolve to real files
- match renderer completes
- shoot input accepted
- fulltime state completes

Regression suites for prior phases were rerun after the gameplay changes. Historical Phase 0 test expectations were aligned with the current recovered home `continue` target (`room_field`), while the prematch room remains independently reachable for regression coverage.

## Manual-browser limitation

The local environment's Chromium process does not terminate reliably during headless capture, so a real Chromium screenshot is **not** claimed as automated evidence. The production project is intended to be manually tested from the supplied ZIP.

## Provenance

- `[APK-DIRECT]` recovered room dimensions, object names, sprite/frame resources, texture mappings, and native symbol relationships.
- `[B]` browser reconstruction of the camera/state/rendering behavior evidenced by native GameMaker code.
- `[APPROX]` only where exact numeric behavior cannot be recovered from stripped YYC code.

## Manual-test hotfix — 2026-09-14 17:36 EDT

The manual browser capture showed `room_field` rendering the pitch but not the players/HUD. Root cause was identified in `drawPlayer()`: the clothes-shader reconstruction returns an `HTMLCanvasElement`, but the renderer tested the result using `image.complete`. Canvas elements do not expose that property, so every recolored player was rejected as non-renderable. The frame preload and recovered player assets themselves were present.

Hotfix: `drawableAsset()` now accepts both loaded `HTMLImageElement` instances and generated `HTMLCanvasElement` shader results. The controlled-player highlight is guarded the same way. No asset was replaced or cropped.

Validation:
- `node --check game.js`: PASS
- production asset paths: PASS
- local HTTP server: PASS
- browser-level headless capture attempted; Chromium still hangs in this environment, so no automated visual claim is made.
