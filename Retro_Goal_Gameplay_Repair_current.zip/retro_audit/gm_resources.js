(function(){
  'use strict';
  const M=window.GM_RESOURCE_MANIFEST;
  if(!M) throw new Error('GM resource manifest not loaded');
  const sprites=new Map((M.sprites||[]).map(s=>[s.name,s]));
  const rooms=new Map((M.rooms||[]).map(r=>[r.name,r]));
  const objects=new Map((M.objects||[]).map(o=>[o.name,o]));
  const scripts=new Map((M.scripts||[]).map(s=>[s.name,s]));
  const files=new Map((M.resources||[]).map(f=>[f.path,f]));
  function byName(name){return sprites.get(name)||rooms.get(name)||objects.get(name)||scripts.get(name)||null}
  function sprite(name){return sprites.get(name)||null}
  function room(name){return rooms.get(name)||null}
  function object(name){return objects.get(name)||null}
  function script(name){return scripts.get(name)||scripts.get('gml_Script_'+name)||null}
  function file(path){return files.get(path)||null}
  function asset(name){
    const s=sprite(name);
    if(s) return {kind:'sprite',name,path:s.image,metadata:s};
    const f=file(name);
    if(f) return {kind:f.kind,name:pathName(f.path),path:f.path,metadata:f};
    return null;
  }
  function pathName(p){return p.split('/').pop()}
  function resolveSpriteFrame(name,frame){
    const s=sprite(name); if(!s) return null;
    const n=s.frames||1, i=((frame%n)+n)%n;
    return {sprite:s,frame:i,mapping:(s.frame_mapping||[])[i]||null,path:s.image};
  }
  function roomInstances(name){const r=room(name); return r?r.instances||[]:[]}
  window.GMResourceRegistry={manifest:M,byName,sprite,room,object,script,file,asset,resolveSpriteFrame,roomInstances};
})();
