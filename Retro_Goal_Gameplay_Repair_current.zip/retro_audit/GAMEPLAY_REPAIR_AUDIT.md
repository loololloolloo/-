# Retro Goal — Gameplay Repair Audit

This build is a gameplay repair checkpoint, not a claim that every original mechanic is complete.

## Source evidence used

- `game.droid` GameMaker room/object/resource graph
- YYC native symbols for `obj_match_controller` gesture events
- native `s_match_controller_global_drag_start`
- native `s_match_controller_global_dragging`
- native `s_match_controller_global_drag_end`
- native `s_aim_mode_hold`
- native `s_tap_to_pass`
- native `s_get_kick_velocity`
- native `s_get_kick_tradjectory`
- native `s_player_positions_init`
- native `s_get_pitch_position_from_formation`
- native `obj_goal_fore` / `obj_goal_back` draw/create events
- recovered `field.png`, player sprites, palette shader and animation metadata

## Repairs in this checkpoint

1. Corrected the pitch entity coordinate band to match the recovered field raster rather than the previous guessed vertical offset.
2. Stopped drawing goal meshes at an invented `y=270`; the recovered field raster already contains the fixed goal geometry, while separate goal objects are depth-layer resources whose exact dynamic placement is not yet fully resolved.
3. Added central drag gesture state with start/move/end samples.
4. Implemented swipe-derived shot power and lateral curve state. This is a B/C reimplementation of the recovered drag/aim/trajectory architecture because the stripped YYC does not expose readable GML constants.
5. Added curved-ball lateral acceleration and decay to the actual ball simulation.
6. Added double-tap handling as an explicit second gesture path rather than treating every tap as a shot.
7. Added facing-aware horizontal mirroring for player sprites.
8. Expanded off-ball teammate behavior: support lanes, forward runs, defensive pressure and ball-relative movement.
9. Kept the recovered clothes-shader palette model and actual recovered player frames.
10. Added a browser/runtime regression that verifies the match renderer completes with player canvases, ball, field and UI.

## Automated gameplay checkpoint

`test_gameplay_repair.js`: PASS

- live match initializes
- 14 players initialize
- player positions stay inside recovered pitch raster
- kickoff possession active
- teammate makes an off-ball run while human has possession
- drag gesture launches shot
- drag gesture produces nonzero curve
- curved trajectory changes velocity laterally
- central pass action works
- goal-mouth collision increments score
- full match renderer completes

## Important limitation

A real hosted-browser manual test is still required. The automated harness proves state/renderer execution but does not prove that the user's exact browser/input device presentation matches the original. Do not treat this checkpoint as completion of the gameplay reconstruction phase.
