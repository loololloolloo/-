# Retro Goal — Phase 3 Validation

## Scope

Phase 3 reconstructs the title → main-menu application state machine around the recovered GameMaker room/object/script graph. It preserves the Phase 0–2 runtime and adds a manifest-backed browser controller for `room_home`.

## APK evidence used

- `ROOM`: `room_title`, `room_home`, `room_prematch`, `room_field`, and the discovered application rooms.
- `OBJT`: `obj_master`, `obj_room_manager`, `obj_button` and related UI objects.
- `SCPT`: `gml_Script_s_home_init`, `gml_Script_s_home_step`, and the nine recovered `gml_Script_s_home_btn_*` handlers.
- YYC symbols/native bodies for `obj_room_manager` and `obj_button`.
- `s_button_draw_gui` native body, which confirms the button GUI path uses recovered sprite/font resources.
- Recovered UI sprites: `spr_header`, `spr_button`, `spr_button_small`, `spr_card_team`, and menu icons.

## Browser implementation

`gm_ui_runtime.js` contains the recovered script identities and room/action graph. `HomeUI` in `game.js` consumes that manifest and renders the home state using recovered sprite resources. Keyboard/pointer input is routed through the existing centralized `InputManager`.

The home state has a dedicated recovered `CONTINUE` action plus nine recovered home button scripts. Exact native draw-GUI coordinates and some target-room constants remain explicitly marked B/C where stripped YYC does not expose readable GML source values.

## Functional tests

`node test_phase3_node.js`

Result: **16/16 assertions passed**.

Covered:

1. Runtime exposure
2. Fresh title room load
3. Title reaches input-ready state
4. Title → home transition
5. Nine recovered home buttons are present
6. Home starts on recovered continue state
7. Home continue → match
8. Match creates 14 players
9. Home keyboard selection
10. Recovered standings action → `room_standings`
11. Room back → `room_home`
12. Pointer hit testing
13. Pointer activation of recovered home action
14. Home renderer execution using recovered resources
15. Play-next pointer → match
16. Central keyboard gameplay input remains functional

## Runtime serving

The production `index.html` was served with a basic local HTTP server and the entry point plus loaded JavaScript/resources returned HTTP 200.

## Regression

Phase 0 title/input/match behavior remains exercised by the Phase 3 flow. No recovered artwork was replaced with screenshots or external substitutes.

## Provenance

- **A / APK-direct:** resource names, room names, object names, script names, sprite/frame data.
- **B / reverse-engineered:** browser state/controller structure, button-action routing, resource-driven GUI dispatch.
- **C / approximation:** exact home GUI placement/spacing where native draw-GUI numeric values could not be confidently recovered from stripped YYC.

Phase 3 is considered implemented/integrated/tested for the recovered home state-machine layer. The remaining native-draw details are tracked as provenance-limited work rather than presented as recovered facts.
