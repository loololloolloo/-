# Retro Goal — Phase 2 Validation

## Status

**PHASE 2 — COMPLETE**

Phase 2 introduces a reusable browser-native GameMaker-style animation layer driven by the recovered SPRT/TPAG frame relationship data. It does not replace the recovered artwork with manually authored animation sequences.

## Source evidence

- `recovered/sprite_texture_mapping.json` — recovered sprite frame and texture-page rectangles.
- recovered texture-page atlases under `recovered/atlases/`.
- recovered SPRT metadata represented in `visual_meta.js` / Phase 1 resource manifest.
- YYC/native title and gameplay resource names used to select state-specific animation clips.

## Deliverables

- `gm_animation_data.js` — browser-loaded recovered animation/frame manifest.
- `recovered/animation_manifest.json` — machine-readable animation audit.
- `assets/frames_gm/` — 1,008 exact recovered sprite frames reconstructed from texture-page source rectangles and GameMaker target rectangles.
- `GMAnimation` in `game.js` — reusable animation controller with image index, image speed, looping, reset, frame callbacks and recovered frame resolution.
- `drawGMAnimation` in `game.js` — common sprite rendering primitive using recovered origins.

## Animation coverage

- 295 recovered sprite resources represented.
- 1,008 decoded/reconstructed sprite frames represented by the animation manifest.
- All generated frame paths exist on disk.
- Multi-frame and non-looping behavior exercised by automated tests.

## Runtime integration

The animation layer is connected to:

- player idle/run/pass/kick/slide clips
- goalkeeper idle/run/dive/collect clip families
- ball `spr_ball1` / `spr_ball2` animation states
- title player and title ball animation controllers
- recovered sprite origins and dimensions

The existing player palette replacement remains intact; the animation controller supplies the recovered frame sequence while the existing shader-equivalent Canvas recoloring supplies kit appearance.

## Provenance

**A — recovered:** frame order, texture-page coordinates, target rectangles, dimensions and origins.

**B — reimplemented:** browser animation controller, frame extraction, state-to-clip dispatch and renderer integration.

**C — approximate:** per-clip timing values where the stripped YYC build does not expose a readable original `image_speed` value. Timing is explicitly represented as a reimplementation parameter rather than claimed as recovered source behavior.

## Regression

Phase 0 test suite remains **11 / 11 passed**.

Phase 2 animation suite verifies:

- animation manifest loading
- 295-sprite coverage
- 1,008-frame coverage
- generated frame-path integrity
- advancing multi-frame animation
- non-loop termination
- goalkeeper clip resolution
- ball animation controller

JavaScript syntax checks pass.

## Gate result

Phase 2 satisfies implementation, integration, testing, regression and provenance requirements. The project may proceed to Phase 3, title/main-menu state-machine reconstruction.
