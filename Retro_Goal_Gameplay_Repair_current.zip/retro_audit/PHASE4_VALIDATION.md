# Retro Goal — Phase 4 Validation

## Scope

Phase 4 addresses the title rendering defect and the playability blocker reported during manual testing. It does not replace recovered assets with a mock screen.

## Implemented

- Title background and digital overlay are rendered once from their recovered 584px-wide resources and clipped to the recovered 480x270 `room_title` viewport.
- Title player/ball remain driven by the Phase 2 animation controller and recovered SPRT origins.
- Title confirmation remains centralized and now also has a click-path fallback through the same `InputManager` action.
- Entering `room_title` resets title animation/input state, preventing a stale exit state when returning to the title.
- `room_prematch` pointer regions distinguish Back, Formation/side switching, and Play instead of treating every lower-screen click as Play.
- Match kickoff now places the controlled human player at the ball and gives immediate possession, so the first action is playable.
- Human pass falls back to the nearest teammate when no strictly forward teammate is available.

## Functional tests

`test_phase4_node.js`: **10/10 PASS**.

Covered flow:

1. Fresh boot → title
2. Title animation → ready
3. Pointer confirm → home
4. Home PLAY NEXT → match
5. 14 players initialized
6. Immediate human kickoff possession
7. Immediate keyboard movement
8. Immediate pass action
9. Return to title resets title state
10. Keyboard title confirmation → home

## Asset-path audit

`recovered/PHASE4_ASSET_PATH_AUDIT.json` reports:

- direct production `img()` references: 18
- missing direct paths: 0
- recovered animation frame paths: 1,008
- missing animation frame paths: 0

## Browser limitation

A real Chromium navigation test could not be completed in this execution environment because Chromium is blocked from navigating to the local HTTP server (`ERR_BLOCKED_BY_ADMINISTRATOR`). This is recorded rather than represented as a successful browser test.

## Provenance

Recovered artwork and resource relationships remain sourced from the APK extraction. Title viewport/clip behavior and input/kickoff behavior are browser-side reimplementations. Timing/position constants that are not recoverable as readable GML remain explicitly reimplemented/approximate rather than claimed as original source values.
