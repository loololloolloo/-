# Validation log — audited runtime

## APK/resource validation

- APK opened successfully as a ZIP/Android package.
- `assets/game.droid` parsed as a GameMaker FORM/IFF container.
- STRG contains 2,129 string entries; object/room/script names were recovered from the original resource data.
- 29 named rooms and 71 GameMaker objects were identified.
- Native `lib/arm64-v8a/libyoyo.so` is AArch64 YYC code. It is stripped of DWARF/debug sections but retains many GML symbols and compiled function bodies.
- Match/player/ball/keeper/camera/kicking/tactics/replay/career-related symbols were independently enumerated.

## Browser runtime validation

- `game.js` passes `node --check`.
- A VM-based DOM/canvas harness initialized the match with **14 player entities** and a ball.
- The harness advanced the simulation through **halftime and fulltime** without NaN/Infinity values.
- A direct shot trajectory test produced a **goal event** and reset state correctly.
- Runtime stress testing covered repeated player switching, passing, shooting, tackling and long simulation advancement.

## Browser rendering validation

A local HTTP server returned `200 OK` for `index.html`. Chromium headless was then launched against that server, but this execution environment did not terminate the browser process and no screenshot was produced before the imposed timeout. This is an environment limitation, not evidence that the static web app cannot run in a normal browser.

## Provenance correction

The previous build's match behavior was mostly an authored approximation despite using recovered visual assets. This audit documents that distinction explicitly. The current runtime implements systems whose structure is evidenced by the APK, while numeric behavior that cannot yet be recovered confidently from the stripped YYC binary remains marked as approximate.
