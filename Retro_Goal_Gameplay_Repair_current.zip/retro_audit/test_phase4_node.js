'use strict';
const fs=require('fs'),vm=require('vm');
const base=__dirname;
const noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:0,height:0,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(4)}),putImageData:noop})}: {}};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=960;this.naturalHeight=540;this.src=''} }
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1}play(){return Promise.resolve()}}
const listeners={};
const context={window:{},document,Image:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:(t,f)=>(listeners[t]=f)};
context.window=context;context.window.window=context;context.window.document=document;context.window.Image=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.__RETRO_GOAL_RUNTIME;const out=[];const add=(name,ok,detail)=>out.push({name,ok,detail});
 add('fresh boot is title',R.state.screen==='title'&&R.state.runtimeRoom==='room_title','');
 for(let i=0;i<90;i++)R.update(.016);
 add('title animation reaches ready state',R.state.title.ready===true,R.state.title.stage);
 R.InputManager.pointer(480,270); for(let i=0;i<40;i++)R.update(.016);
 add('title pointer actually enters home',R.state.runtimeRoom==='room_home'&&R.state.screen==='system',R.state.runtimeRoom);
 add('home continue is selected',R.state.homeUI.selected===-1,R.state.homeUI.selected);
 R.InputManager.pointer(80,355);
 add('home PLAY NEXT actually enters match',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',R.state.runtimeRoom);
 add('match creates 14 players',R.state.players.length===14,R.state.players.length);
 add('kickoff immediately gives human possession',R.state.ball.owner===R.state.controlled&&R.state.players[R.state.controlled].hasBall===true,JSON.stringify({owner:R.state.ball.owner,controlled:R.state.controlled}));
 const p=R.state.players[R.state.controlled],x=p.x,y=p.y;listeners.keydown?.({key:'ArrowRight',preventDefault:noop});for(let i=0;i<20;i++)R.update(.016);listeners.keyup?.({key:'ArrowRight'});add('human can move immediately',p.x!==x||p.y!==y,JSON.stringify({x,y,x1:p.x,y1:p.y}));
 const oldOwner=R.state.ball.owner;R.InputManager.dispatch('pass');add('pass action is accepted from kickoff possession',R.state.ball.owner===-1||R.state.ball.owner!==oldOwner,R.state.ball.owner);
 // fresh title keyboard path
 R.Runtime.enter('room_title','phase4-reset');for(let i=0;i<90;i++)R.update(.016);listeners.keydown?.({key:'Enter',preventDefault:noop});for(let i=0;i<40;i++)R.update(.016);add('keyboard title path works after reset',R.state.runtimeRoom==='room_home',R.state.runtimeRoom);
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
