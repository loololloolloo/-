varying vec2 v_vTexcoord;

uniform vec3 colorShirt;
uniform vec3 colorSkin;
uniform vec3 colorHair;
uniform vec3 colorShorts;
uniform vec3 colorSocks;
uniform vec3 colorStripes;
uniform vec3 colorBoots;

uniform vec3 colorShirt2;
uniform vec3 colorSkin2;
uniform vec3 colorShorts2;
uniform vec3 colorSocks2;
uniform vec3 colorStripes2;

uniform vec3 replaceShirt;
uniform vec3 replaceSkin;
uniform vec3 replaceHair;
uniform vec3 replaceShorts;
uniform vec3 replaceSocks;
uniform vec3 replaceStripes;
uniform vec3 replaceBoots;

uniform vec3 replaceShirt2;
uniform vec3 replaceSkin2;
uniform vec3 replaceShorts2;
uniform vec3 replaceSocks2;
uniform vec3 replaceStripes2;

void main() {
	vec4 pixel = texture2D( gm_BaseTexture, v_vTexcoord );
	
	if (pixel.a == 1.0) {	
		vec3 eps = vec3(0.009, 0.009, 0.009);
		
		if( all( greaterThanEqual(pixel, vec4(colorShirt - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorShirt + eps, 1.0)) ) )
			pixel = vec4(replaceShirt, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorShirt2 - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorShirt2 + eps, 1.0)) ) )
			pixel = vec4(replaceShirt2, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorSkin - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorSkin + eps, 1.0)) ) )
			pixel = vec4(replaceSkin, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorSkin2 - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorSkin2 + eps, 1.0)) ) )
			pixel = vec4(replaceSkin2, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorHair - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorHair + eps, 1.0)) ) )
			pixel = vec4(replaceHair, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorShorts - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorShorts + eps, 1.0)) ) )
			pixel = vec4(replaceShorts, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorShorts2 - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorShorts2 + eps, 1.0)) ) )
			pixel = vec4(replaceShorts2, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorSocks - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorSocks + eps, 1.0)) ) )
			pixel = vec4(replaceSocks, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorSocks2 - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorSocks2 + eps, 1.0)) ) )
			pixel = vec4(replaceSocks2, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorStripes - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorStripes + eps, 1.0)) ) )
			pixel = vec4(replaceStripes, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorStripes2 - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorStripes2 + eps, 1.0)) ) )
			pixel = vec4(replaceStripes2, 1.0);
		else if( all( greaterThanEqual(pixel, vec4(colorBoots - eps, 1.0)) ) && all( lessThanEqual(pixel, vec4(colorBoots + eps, 1.0)) ) )
			pixel = vec4(replaceBoots, 1.0);
	}

	gl_FragColor = pixel;
}

