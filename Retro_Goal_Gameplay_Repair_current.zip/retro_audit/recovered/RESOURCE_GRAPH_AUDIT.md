# RETRO GOAL — PHASE 1 RESOURCE GRAPH AUDIT

## Purpose

This manifest maps recovered GameMaker resources into the browser runtime without using screenshots as implementation source. The APK remains the source of truth.

## Inventory

- files: **411**
- sprites: **295**
- texture_page_items: **1011**
- rooms: **29**
- objects: **71**
- scripts: **1593**
- native_object_events: **250**

## Runtime entry and scripts

- Entry point: `index.html`
- `data.js`
- `visual_meta.js`
- `gm_runtime_data.js`
- `game.js`

## Resource relationship model

```text
GameMaker resource → resource type → texture/data → sprite/frame → object → room/state
```

### Sprite → object coverage

- 36 / 295 recovered sprites have at least one decoded object reference.
- 259 recovered sprites currently have no decoded object reference; they remain preserved as recovered/unused resources.

### Room → object coverage

- `room_title` (480×270): obj_master, obj_room_manager
- `room_splash` (480×270): obj_room_manager, obj_scanlines
- `room_home` (480×270): obj_room_manager
- `room_field` (1743×530): obj_camera, obj_match_controller, obj_digital_ad, obj_transition
- `room_options` (480×270): obj_room_manager, obj_credits
- `room_results` (480×270): obj_room_manager
- `room_prematch` (480×270): obj_room_manager, obj_button, obj_prematch_team, obj_prematch_team, obj_prematch_cup
- `room_halftime` (480×270): obj_overlay_field, obj_room_manager
- `room_standings` (480×270): obj_room_manager
- `room_base` (480×270): obj_screen_header, obj_room_manager
- `room_newcareer` (480×270): obj_room_manager, obj_panel, obj_text_exp, obj_text_exp, obj_input_box, obj_input_box, obj_panel, obj_button, obj_button
- `room_favouriteteam` (480×270): obj_room_manager
- `room_lineup` (480×270): obj_room_manager, obj_panel_header
- `room_weekend` (480×270): obj_room_manager, obj_panel_header
- `room_roster` (480×270): obj_room_manager
- `room_profile` (480×270): obj_room_manager
- `room_office` (480×270): obj_room_manager
- `room_formation` (480×270): obj_room_manager, obj_field_model
- `room_tactics` (480×270): obj_room_manager, obj_field_model
- `room_freeagents` (480×270): obj_button_info, obj_button, obj_button, obj_button, obj_button, obj_button, obj_button, obj_room_manager
- `room_seasonend` (480×270): obj_room_manager
- `room_prospects` (480×270): obj_room_manager
- `room_trophies` (480×270): obj_room_manager
- `room_store` (480×270): obj_room_manager
- `room_achievements` (480×270): obj_room_manager
- `room_staffhires` (480×270): obj_room_manager
- `room_records` (480×270): obj_room_manager
- `room_hof` (480×270): obj_room_manager
- `room_teamrecords` (480×270): obj_room_manager

### Texture mapping

- Each sprite entry carries its recovered texture-page references and per-frame source/target rectangles from `sprite_texture_mapping.json`.
- The four recovered texture pages are preserved under `recovered/atlases/`.

### Fonts / shaders / audio

**Fonts:**
- `assets/fonts/body.json` (24477 bytes)
- `assets/fonts/body.png` (4055 bytes)
- `assets/fonts/title.json` (34021 bytes)
- `assets/fonts/title.png` (20948 bytes)
**Shaders:**
- `recovered/shaders/sh_ColorReplaceClip_fragment.glsl` (2887 bytes)
**Audio:**
- `assets/track1.ogg` (1320531 bytes)
- `assets/track2.ogg` (1463581 bytes)
- `assets/track3.ogg` (1443930 bytes)

## Browser resolution contract

`GMResourceRegistry` resolves a GameMaker resource name to its recovered asset path and metadata. It does not synthesize replacement art when a recovered resource exists.

## Provenance

- **A — recovered:** directly decoded/recovered APK resource/data.
- **B — reimplemented:** browser-side system reconstructed from APK structures/code evidence.
- **C — approximate:** only used where the stripped YYC/APK evidence does not uniquely determine behavior.

## Phase 1 acceptance checks

- Manifest is machine-readable JSON.
- Human-readable audit records counts and relationships.
- Every runtime asset referenced by the current browser build is present.
- Every recovered sprite remains addressable by GameMaker name.
- Texture-page/frame mapping remains attached to sprite metadata.
- Unused recovered resources are preserved rather than discarded.
