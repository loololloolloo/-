'use strict';
const fs=require('fs'),vm=require('vm');
const base='/mnt/data/retro_next/retro_audit';
const noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:0,height:0,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(4)}),putImageData:noop})}: {}};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=960;this.naturalHeight=540;this.src=''} }
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1}play(){return Promise.resolve()}}
const listeners={};
const context={window:{},document,Image:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:(t,f)=>(listeners[t]=f)};
context.window=context.window;context.window.window=context.window;context.window.document=document;context.window.Image=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.window.__RETRO_GOAL_RUNTIME;const out=[];const add=(name,ok,detail)=>out.push({name,ok,detail});
 add('runtime exposed',!!R,''); add('title room loaded',R.state.runtimeRoom==='room_title',R.state.runtimeRoom);
 for(let i=0;i<90;i++)R.update(.016); add('title reaches idle input state',R.state.title.ready===true&&R.state.title.stage===1,R.state.title.phase);
 R.InputManager.dispatch('confirm'); for(let i=0;i<40;i++)R.update(.016); add('title transition reaches home',R.state.runtimeRoom==='room_home'&&R.state.screen==='system',R.state.runtimeRoom);
 add('home has recovered buttons',R.state.homeUI.buttons.length===9,R.state.homeUI.buttons.length);
 add('home starts on recovered continue action',R.state.homeUI.selected===-1,R.state.homeUI.selected);
 R.InputManager.dispatch('confirm'); add('home continue launches field',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',R.state.runtimeRoom);
 add('match initialized with players',R.state.players.length===14,R.state.players.length);
 R.Runtime.enter('room_home','button-test'); R.InputManager.dispatch('down'); add('home down enters first recovered button',R.state.homeUI.selected===0,R.state.homeUI.selected);
 R.InputManager.dispatch('confirm'); add('standings action enters mapped room',R.state.runtimeRoom==='room_standings'&&R.state.screen==='system',R.state.runtimeRoom);
 R.InputManager.dispatch('back'); add('room back uses recovered room mapping',R.state.runtimeRoom==='room_home',R.state.runtimeRoom);
 R.Runtime.enter('room_home','pointer-test'); add('home pointer hit resolves first button',R.HomeUI.hit(350,130)===0,R.HomeUI.hit(350,130));
 R.state.homeUI.selected=0; R.InputManager.pointer(350,130); add('home pointer activates recovered action',R.state.runtimeRoom==='room_standings',R.state.runtimeRoom);
 R.Runtime.enter('room_home','draw-test'); R.draw(); add('home renderer consumes recovered UI resources',true,'draw completed');
 R.Runtime.enter('room_home','play-test'); R.InputManager.pointer(40,355); add('play-next pointer launches match',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',R.state.runtimeRoom);
 const cp=R.state.players[R.state.controlled],x=cp.x,y=cp.y; listeners.keydown?.({key:'ArrowRight',preventDefault:noop});for(let i=0;i<20;i++)R.update(.016);listeners.keyup?.({key:'ArrowRight'});add('central input remains functional after home flow',cp.x!==x||cp.y!==y,JSON.stringify({x,y,x1:cp.x,y1:cp.y}));
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
