# Phase 0 — Current Build Audit and Blocker Fix

## Status

**Implementation/test harness: PASS. Full real-browser demonstration: BLOCKED by the execution environment.**

This phase is intentionally not packaged as a phase ZIP until the browser-side interaction can be demonstrated in a terminating browser session.

## APK evidence used

The title flow was traced to the recovered YYC symbols rather than inferred from screenshots:

- `room_title` is a recovered 480×270 GameMaker room.
- Native `s_title_step` contains the input path:
  `s_button_snd_click → s_title_continue → s_title_set_opacity`.
- Native `s_title_exit` calls `s_goto_room` with the compiled room argument.
- Native title state variables recovered from the GOT are:
  - `_title_stage`
  - `_title_stage_time`
  - `_title_opacity`
  - `_title_out_delay`
  - `_x_title`, `_y_title`
  - `_x_scroll`, `_y_scroll`
  - `_x_copy`, `_y_copy`
  - `_s_title`, `_s_ball`, `_r_ball`
- The exact compiled target-room constant remains unresolved in the stripped YYC image, so `room_home` remains an explicit fallback rather than being mislabeled as recovered.

## Browser changes

1. Added a centralized `InputManager` for keyboard, mouse/pointer and touch-compatible pointer input.
2. Removed per-screen ad-hoc title click logic.
3. Added a reusable `GMAnimation` runtime using recovered `SPRITE_META` frame counts and image-speed semantics.
4. Connected player animation state to the generic animation system.
5. Reworked title rendering to use the recovered 480×270 room coordinate system at 2× display scale.
6. The recovered `spr_title_digitaloverlay_wide` is rendered once as a 584×26 source sprite and is **not tiled**.
7. Title state now explicitly tracks stage, stage time, opacity and output delay, mirroring the recovered native state variables.
8. Exposed a non-rendering runtime inspection surface for automated validation; this does not alter game rendering.

## Functional integration test

`test_phase0_node.js` exercises the actual browser runtime code with DOM/canvas/audio adapters:

- fresh title room load
- title animation progression
- input-ready state
- title confirm transition
- title → home
- home → prematch
- prematch → match
- centralized keyboard input → player movement
- full-time → results transition

Result on 2026-09-14: **11/11 assertions passed**.

## Regression checks

- `node --check game.js`: PASS
- Existing match runtime remains callable through `Runtime.enter('room_field')`.
- Existing recovered asset paths and shader-based player recolouring remain intact.
- No screenshot-derived implementation was added.

## Browser-environment limitation

The available Chromium binary does not terminate in this execution environment, including on a minimal static HTML page. Therefore a fresh-page browser screenshot/DOM session could not be used as the final phase demonstration. This is recorded as a test-environment limitation, not as evidence that browser interaction is broken.

## Next gate

Before Phase 0 is declared complete, run the same fresh-load flow in a normal browser and verify:

`TITLE → input → HOME → TEAM SELECTION → confirm → MATCH`

Only after that gate passes should Phase 1/2 work continue.
