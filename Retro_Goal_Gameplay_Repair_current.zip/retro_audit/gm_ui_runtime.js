'use strict';
/*
 * Retro Goal UI/state runtime manifest.
 * [APK-DIRECT] names/room relationships come from ROOM/SCPT/YYC symbols.
 * [B] target mapping is reconstructed from named button scripts and room graph.
 * [C] layout is intentionally isolated so it can be replaced as more native
 * draw-GUI constants are recovered; it never substitutes external artwork.
 */
window.GM_UI_RUNTIME={
  version:'phase3-ui-state-v1',
  rooms:{
    room_home:{init:'gml_Script_s_home_init',step:'gml_Script_s_home_step',buttons:[
      {script:'gml_Script_s_home_btn_standings',label:'STANDINGS',icon:'spr_icon_shield',target:'room_standings'},
      {script:'gml_Script_s_home_btn_schedule',label:'SCHEDULE',icon:'spr_icon_form',target:'room_weekend'},
      {script:'gml_Script_s_home_btn_cupschedule',label:'CUP SCHEDULE',icon:'spr_icon_cup',target:'room_standings'},
      {script:'gml_Script_s_home_btn_lineup',label:'LINEUP',icon:'spr_icon_bench',target:'room_lineup'},
      {script:'gml_Script_s_home_btn_office',label:'OFFICE',icon:'spr_icon_spanner',target:'room_office'},
      {script:'gml_Script_s_home_btn_results',label:'RESULTS',icon:'spr_icon_football',target:'room_results'},
      {script:'gml_Script_s_home_btn_records',label:'RECORDS',icon:'spr_icon_star',target:'room_records'},
      {script:'gml_Script_s_home_btn_store',label:'STORE',icon:'spr_icon_coins',target:'room_store'},
      {script:'gml_Script_s_home_btn_options',label:'OPTIONS',icon:'spr_icon_spanner',target:'room_options'}
    ],continue:{script:'gml_Script_s_home_btn_continue',target:'room_field'}},
    room_options:{init:'gml_Script_s_options_init',back:'room_home'},
    room_standings:{init:'gml_Script_s_panel_standings_init',back:'room_home'},
    room_results:{init:'gml_Script_s_results_init',back:'room_home'},
    room_records:{init:'gml_Script_s_records_init',back:'room_home'},
    room_store:{init:'gml_Script_s_store_init',back:'room_home'},
    room_office:{init:'gml_Script_s_office_init',back:'room_home'}
  },
  menuOrder:['room_standings','room_weekend','room_standings','room_lineup','room_office','room_results','room_records','room_store','room_options']
};
