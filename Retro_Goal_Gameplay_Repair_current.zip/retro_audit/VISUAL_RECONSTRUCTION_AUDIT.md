# Visual reconstruction audit — APK-driven pass

## Source of truth

The supplied `Retro_Goal-1.0.1.apk` was inspected directly. `assets/game.droid` contains the GameMaker `SPRT`, `TPAG`, `SHDR`, `ROOM`, `OBJT`, `STRG` and `TXTR` resources used by this pass.

## Player texture problem — root cause

The exported 32×32 player sprites are **not broken artwork**. They contain the original GameMaker clothes-shader key palette. The APK's `sh_ColorReplaceClip` fragment shader defines replacement uniforms for shirt, skin, hair, shorts, socks, stripes and boots. Rendering the raw texture without that shader produces the apparent rainbow/block corruption.

The browser now reproduces the shader's exact-key replacement model in Canvas. The 12 placeholder key colours are retained as source data and are replaced by kit/appearance colours before drawing.

The YYC also exposes `s_get_skin_colour_by_index` and `s_get_hair_colour_by_index`. Native disassembly recovered these exact appearance colours:

- skin 0: `#EEC39A`
- skin 1: `#BA8857`
- skin 2: `#5D3324`
- hair 0: `#FAC80A`
- hair 1: `#5A2D08`
- hair 2: `#141414`

The current runtime uses the recovered light/brown appearance pair for the default match players and retains the full source palette mapping.

## Goal graphics — root cause

The APK contains real `spr_goal_fore` and `spr_goal_back` resources. Their TPAG entries resolve to texture page 2 and are now rendered at both ends of the recovered `spr_field` geometry. The gameplay goal boundaries use the same field-space coordinates.

## White circle — root cause

The previous white circle was a reconstruction-only debug visualization in `drawPlayer()`. It was not the original goal/player visual. It has been removed and replaced with the recovered `spr_player_highlight` resource.

## Title screen

The previous generic browser menu has been replaced with the recovered title composition resources:

- `spr_title_background_wide`
- `spr_title_player`
- `spr_title_ball`
- `spr_title_logo`
- `spr_title_digitaloverlay_wide`
- `spr_title_copyright`

The menu text is rendered with the recovered GameMaker bitmap font rather than a browser system font. `Tap to Start` is sourced from the APK English localization as `ui_PressStart`.

## Prematch/team presentation

The previous coloured rectangles were removed. The browser now uses recovered `spr_header`, the original bitmap font, recovered player sprites with the actual kit shader reconstruction, team data already extracted from the APK, and original red button artwork. This follows the structure of the APK's `room_prematch` / `obj_prematch_team` resources rather than inventing kit rectangles.

## Texture-page mapping

A complete TPAG mapping was generated at `recovered/sprite_texture_mapping.json`:

- 1,011 / 1,011 TPAG items resolved
- 295 / 295 sprite resources resolved
- every sprite frame reference was matched to its source rectangle, target rectangle, bounding dimensions and texture-page ID

`recovered/TEXTURE_PAGE_AUDIT.md` contains representative mappings and the list of resources that are still not directly used by the browser runtime.

## Deliberately retained

The existing Canvas runtime, recovered field, music, fonts, animation assets, match logic and extracted GameMaker data remain in place. This pass changes the visual interpretation of the original resources rather than replacing the renderer or gameplay implementation.
