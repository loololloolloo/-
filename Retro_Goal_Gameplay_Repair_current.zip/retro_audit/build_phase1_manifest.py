import json, hashlib, os, mimetypes, struct
from pathlib import Path
root=Path('/mnt/data/retro_next/retro_audit')
rec=root/'recovered'
rg=json.loads((rec/'gm_runtime_graph.json').read_text())
sm=json.loads((rec/'sprite_texture_mapping.json').read_text())
rooms=rg['rooms']; objects=rg['objects']; sprites=rg['sprites']; scripts=rg['scripts']; native=rg['native_object_events']
obj_by_id={o['id']:o for o in objects}
spr_by_id={s['i']:s for s in sprites}
# Files under runtime assets/recovered resources.
files=[]
for base in [root/'assets', root/'recovered']:
    for p in sorted(base.rglob('*')):
        if p.is_file():
            rel=p.relative_to(root).as_posix()
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            kind='asset'
            if rel.endswith('.png'): kind='image'
            elif rel.endswith('.ogg'): kind='audio'
            elif rel.endswith('.json'): kind='json'
            elif rel.endswith('.glsl'): kind='shader'
            elif rel.endswith('.md'): kind='documentation'
            files.append({'path':rel,'bytes':p.stat().st_size,'sha256':h,'kind':kind})
# Sprite relationship graph.
sprite_entries=[]
for s in sm['sprites']:
    used_by=[{'object_id':o['id'],'object_name':o['name']} for o in objects if o.get('sprite')==s['i']]
    sprite_entries.append({
        'id':s['i'],'name':s['name'],'width':s['w'],'height':s['h'],'origin':[s['ox'],s['oy']],
        'frames':len(s.get('frames',[])),'image':'recovered/'+s['image'],'texture_page_refs':s.get('refs',[]),
        'frame_mapping':s.get('frames',[]),'used_by':used_by
    })
room_entries=[]
for r in rooms:
    inst=[]
    for i in r.get('game_objects',[]):
        o=obj_by_id.get(i['object_id'])
        spr=spr_by_id.get(o['sprite']) if o else None
        inst.append({**i,'sprite_id':o['sprite'] if o else None,'sprite_name':spr['name'] if spr else None})
    room_entries.append({**{k:r[k] for k in ['id','name','width','height','speed','persistent','flags']},'instances':inst,'layers':r.get('layers',[])})
# Script inventory + native events by object.
native_by_obj={}
for ev in native:
    # gml_Object_obj_name_Event
    parts=ev.split('_')
    # find obj_ and event suffix robustly
    try: idx=parts.index('obj'); obj='obj_'+'_'.join(parts[idx+1:-1])
    except: obj='unknown'
    native_by_obj.setdefault(obj,[]).append(ev)
manifest={
 'format':'Retro Goal Phase 1 resource manifest',
 'source':rg['source'],
 'application':{'name':'Retro Goal','engine':'GameMaker / YoYo Runner','build':'Android YYC'},
 'counts':{'files':len(files),'sprites':len(sprites),'texture_page_items':sm['tpage_item_count'],'rooms':len(rooms),'objects':len(objects),'scripts':len(scripts),'native_object_events':len(native)},
 'runtime_entry':'index.html',
 'runtime_scripts':['data.js','visual_meta.js','gm_runtime_data.js','game.js'],
 'resources':files,
 'sprites':sprite_entries,
 'rooms':room_entries,
 'objects':objects,
 'scripts':scripts,
 'native_object_events':list(native),
 'native_events_by_object':native_by_obj,
 'fonts':[f for f in files if '/fonts/' in f['path']],
 'shaders':[f for f in files if f['kind']=='shader'],
 'audio':[f for f in files if f['kind']=='audio'],
 'texture_pages':[f for f in files if '/atlases/' in f['path']],
 'provenance':{
   'A':'Directly recovered GameMaker resource/data evidence or exact decoded asset.',
   'B':'Browser behavior/structure reimplemented from recovered GameMaker metadata, symbols, disassembly, and resource relationships.',
   'C':'Approximation used only where original behavior cannot be confidently recovered from available APK evidence.'
 }
}
(rec/'resource_manifest.json').write_text(json.dumps(manifest,indent=2))
# Human audit.
lines=[]
lines += ['# RETRO GOAL — PHASE 1 RESOURCE GRAPH AUDIT','',
'## Purpose','',
'This manifest maps recovered GameMaker resources into the browser runtime without using screenshots as implementation source. The APK remains the source of truth.', '',
'## Inventory','',
]
for k,v in manifest['counts'].items(): lines.append(f'- {k}: **{v}**')
lines += ['', '## Runtime entry and scripts','', '- Entry point: `index.html`']
for s in manifest['runtime_scripts']: lines.append(f'- `{s}`')
lines += ['', '## Resource relationship model','', '```text','GameMaker resource → resource type → texture/data → sprite/frame → object → room/state','```','',
'### Sprite → object coverage','']
covered=sum(1 for s in sprite_entries if s['used_by'])
lines.append(f'- {covered} / {len(sprite_entries)} recovered sprites have at least one decoded object reference.')
lines.append(f'- {len(sprite_entries)-covered} recovered sprites currently have no decoded object reference; they remain preserved as recovered/unused resources.')
lines += ['', '### Room → object coverage','']
for r in room_entries:
    names=', '.join(i['object_name'] for i in r['instances']) or '(none)'
    lines.append(f'- `{r["name"]}` ({r["width"]}×{r["height"]}): {names}')
lines += ['', '### Texture mapping','', '- Each sprite entry carries its recovered texture-page references and per-frame source/target rectangles from `sprite_texture_mapping.json`.', '- The four recovered texture pages are preserved under `recovered/atlases/`.', '', '### Fonts / shaders / audio','']
for cat,label in [('fonts','Fonts'),('shaders','Shaders'),('audio','Audio')]:
    lines.append(f'**{label}:**')
    for x in manifest[cat]: lines.append(f'- `{x["path"]}` ({x["bytes"]} bytes)')
lines += ['', '## Browser resolution contract','',
'`GMResourceRegistry` resolves a GameMaker resource name to its recovered asset path and metadata. It does not synthesize replacement art when a recovered resource exists.', '',
'## Provenance','', '- **A — recovered:** directly decoded/recovered APK resource/data.', '- **B — reimplemented:** browser-side system reconstructed from APK structures/code evidence.', '- **C — approximate:** only used where the stripped YYC/APK evidence does not uniquely determine behavior.', '',
'## Phase 1 acceptance checks','', '- Manifest is machine-readable JSON.', '- Human-readable audit records counts and relationships.', '- Every runtime asset referenced by the current browser build is present.', '- Every recovered sprite remains addressable by GameMaker name.', '- Texture-page/frame mapping remains attached to sprite metadata.', '- Unused recovered resources are preserved rather than discarded.',]
(rec/'RESOURCE_GRAPH_AUDIT.md').write_text('\n'.join(lines)+'\n')
print('wrote',rec/'resource_manifest.json',rec/'RESOURCE_GRAPH_AUDIT.md')
