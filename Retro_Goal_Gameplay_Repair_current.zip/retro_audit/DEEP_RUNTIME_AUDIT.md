# Deep Runtime Bug / Asset Audit — Phase 3 blocker pass

## Findings

### 1. Title actor placement was wrong
- `spr_title_player` is 208×262 with recovered origin (10,134).
- The previous browser state placed its room-space Y at ~54, which clipped the head and shifted the actor upward.
- The corrected runtime uses room-space Y=134 and X≈180, matching the recovered sprite origin model and the recovered 480×270 room.
- `spr_title_ball` is 74×74 with origin (37,37); corrected room-space placement starts near the left edge instead of the previous center position.
- The title logo is now positioned in room coordinates rather than using the previous hard-coded vertical offset.

### 2. Title assets were being lazy-loaded
- Only a subset of title assets was awaited before the loading overlay disappeared.
- The runtime now preloads the title background, logo, player, ball, digital overlay, copyright, header, button and first title animation frames before entering `room_title`.

### 3. Title input could be missed during the intro
- The centralized input path previously discarded confirmation input while `_title_stage` was still 0.
- Confirmation is now queued during the intro and consumed when the recovered title state reaches its input-ready stage.
- Keyboard, pointer and touch continue through the same `InputManager` path.

### 4. The repeated blue-bar screenshot is not produced by the current title background asset
- The recovered `spr_title_background_wide` is a single 584×270 stadium/field image.
- The recovered `spr_title_digitaloverlay_wide` is a single 584×26 strip.
- The current renderer draws each exactly once; it does not tile either resource.
- Therefore the repeated-bar artifact is not supported by the recovered source image dimensions and is being treated as a renderer/runtime capture-path bug rather than cropped artwork.

### 5. UI texture problem identified
- The APK recovery contains the UI textures in `assets/frames_gm`; they are not generally missing from extraction.
- The current browser renderer only directly consumes a small subset of them. The generic system-room renderer is still an approximation and does not instantiate the recovered GameMaker UI object draw behavior.
- This is the major Phase 3 UI blocker: the textures exist, but the browser state renderer is not yet consuming the room-manager/object draw graph faithfully.

## Coverage checks

- Rooms: 29
- Sprite resources: 295
- Animation frame files: 1008
- Direct `game.js` image references: 18
- Direct image-reference path failures: 0
- Static room-object sprite IDs: 10
- Static room-object sprite frame directories missing: 0

## Current gate

The title-specific blocker fixes pass the existing Phase 0 integration suite. Phase 3 is **not complete** yet because the recovered room-manager/UI draw graph still needs to replace the generic system-room renderer.

## Provenance

- Recovered: room dimensions, sprite dimensions/origins, title resources, room/object graph, animation frame paths.
- Reimplemented: browser title state/input/preload behavior.
- Remaining approximation: detailed room-manager Draw GUI/UI state rendering.
