# Retro Goal — Runtime Reconstruction Audit

Date: 2026-09-14
Source APK: `Retro_Goal-1.0.1.apk`

## Executive finding

The previous browser match was **not** an authentic translation of the original match runtime. Its renderer/assets were strongly source-derived, but most simulation behavior was newly authored. This audit corrects that provenance claim.

The APK is a GameMaker/YoYo Runner YYC build. `assets/game.droid` is a resource container containing GameMaker resource metadata, script/object/room names, textures, audio and other resources. The Android native library `lib/arm64-v8a/libyoyo.so` is stripped of DWARF/debug sections but retains a large set of exported/global GML symbols and compiled function bodies. Therefore the original GML source is not directly present, but substantial native machine code and the resource graph are recoverable evidence.

The browser runtime remains a native JavaScript/Canvas implementation. It does **not** execute the Android binary.

## Evidence recovered from the APK

### Match/player/ball object graph

Recovered symbols include:

- `gml_Object_obj_match_controller_Create_0`
- `gml_Object_obj_match_controller_Step_0`
- `gml_Object_obj_match_controller_Step_2`
- `gml_Object_obj_player_Create_0`
- `gml_Object_obj_player_Step_0`
- `gml_Object_obj_player_Step_2`
- `gml_Object_obj_player_df_Create_0`
- `gml_Object_obj_player_of_Create_0`
- `gml_Object_obj_ball_Create_0`
- `gml_Object_obj_ball_Step_0`
- `gml_Object_obj_ball_arc_Create_0`
- `gml_Object_obj_ball_arc_Step_0`
- `gml_Object_obj_camera_Create_0`
- `gml_Object_obj_camera_Step_2`
- `gml_Object_obj_goal_back_Create_0`
- `gml_Object_obj_goal_fore_Create_0`

### Recovered gameplay scripts

The GameMaker string table explicitly contains groups named `player_scripts`, `ball_scripts`, `keeper_scripts`, `kicking_scripts`, `match_controller_scripts`, `anim_scripts`, `room_tactics_script`, etc.

Particularly relevant symbols/scripts:

- `s_update_fundamentals`
- `s_get_closest_player`
- `s_get_closest_player_of`
- `s_get_closest_player_df`
- `s_move_to_destination`
- `s_look_for_run`
- `s_face_ball`
- `s_do_repulsion`
- `s_update_player_z`
- `s_get_match_player_attributes`
- `s_get_match_player_attributes_cpu`
- `s_update_match_player_skills`
- `s_update_stat_pass`
- `s_update_stat_tackle`
- `s_update_stat_goal`
- `s_control_ball`
- `s_get_header_teammate`
- `s_intercept_ball`
- `s_update_ball_movement`
- `s_update_ball_height`
- `s_check_ball_boundaries`
- `s_check_hoardings`
- `s_check_goal_bounderies`
- `s_hit_post`
- `s_hit_bar`
- `s_hit_net`
- `s_hit_net_roof`
- `s_hit_sidenet`
- `s_deflect_ball`
- `s_parry_ball`
- `s_tip_ball_over`
- `s_tip_ball_wide`
- `s_update_closest_players`
- `s_ball_is_crossing`
- `s_kick_ball`
- `s_get_kick_velocity`
- `s_get_kick_tradjectory`
- `s_throttle_kick_power`
- `s_dribble_ball`
- `s_clear_ball`
- `s_tackle_ball`
- `s_insta_shoot`
- `s_do_header`
- `s_update_goalkeeper_position`
- `s_do_keeper_closing`
- `s_keeper_dive_ai`
- `s_do_random_dive`
- `s_update_offsides`
- `s_is_corner`
- `s_is_throwin`
- `s_is_setpiece`
- `s_count_restarts`
- `s_check_for_cards`
- `s_match_yellow`
- `s_sent_off`
- `s_check_for_injury`
- `s_process_injury`
- `s_count_subs_made`
- `s_suitable_sub`
- `s_aim_mode_hold`
- `s_tap_to_pass`
- `s_match_controller_closest_facing_player`
- `s_is_volley_expired_or_cancellable`
- `s_speed`
- `s_speed_change`
- `s_speed_no_ball`
- `s_speed_boost_update`
- `s_speed_step`
- `s_speed_plot_gap`

### Match/career resources

The APK also contains 29 named rooms including:

`room_title`, `room_splash`, `room_home`, `room_field`, `room_options`, `room_results`, `room_prematch`, `room_halftime`, `room_standings`, `room_base`, `room_newcareer`, `room_favouriteteam`, `room_lineup`, `room_weekend`, `room_roster`, `room_profile`, `room_office`, `room_formation`, `room_tactics`, `room_freeagents`, `room_seasonend`, `room_prospects`, `room_trophies`, `room_store`, `room_achievements`, `room_staffhires`, `room_records`, `room_hof`, `room_teamrecords`.

Career-related scripts include transfer offers, contracts, free agents, facilities, youth academy, XP, morale, standings, competitions, season progression, saves and records.

## Provenance classification

### Legend

- **A — Directly recovered:** browser uses the original data/resource itself, rather than recreating it from appearance.
- **B — Reverse-engineered/reimplemented:** structure or behavior is evidenced by original compiled code/resource metadata and independently reimplemented in JavaScript. Numeric details are marked approximate when the stripped YYC code does not expose source-level constants cleanly.
- **C — Approximation:** behavior is newly authored without sufficient APK evidence for its exact implementation.
- **Not implemented:** the APK clearly contains the system, but the browser build does not yet implement it.

| System | Status | Evidence / current state |
|---|---|---|
| Player movement | **B** | `obj_player_Step_0`, `s_update_fundamentals`, `s_speed*` recovered. Browser now uses acceleration/deceleration instead of direct velocity assignment. |
| Acceleration/deceleration | **B/C numeric** | `s_speed`, `s_speed_change`, `s_speed_no_ball` are real APK functions. Exact numeric tuning remains approximate. |
| Turning/facing | **B/C numeric** | `s_face_ball` plus player step code support facing state. Exact turn-rate constants are approximate. |
| Ball physics | **B/C numeric** | `s_update_ball_movement`, `s_update_ball_height`, boundary/goal functions are present. Browser now has planar velocity, height/arc, drag and bounce. Exact coefficients remain approximate. |
| Ball-player interaction | **B** | `s_control_ball`, `s_intercept_ball`, closest-player helpers and player/ball objects directly support this model. |
| Possession | **B/C numeric** | `s_control_ball`/`s_dribble_ball` recovered. Browser has explicit owner state and contested possession; exact radius/chance is approximate. |
| Dribbling | **B/C numeric** | `s_dribble_ball` recovered; browser keeps ball attached to player facing with movement-dependent lead. |
| Passing | **B/C numeric** | `s_tap_to_pass`, `s_is_player_pass_worthy`, kick functions and pass animation are recovered. Browser implements nearest forward teammate passing; exact targeting rules remain approximate. |
| Shooting | **B/C numeric** | `s_kick_ball`, `s_get_kick_velocity`, `s_get_kick_tradjectory`, `s_throttle_kick_power`, `s_insta_shoot` recovered. Browser implements velocity/arc shooting; exact coefficients remain approximate. |
| Player AI | **B** | `s_update_fundamentals`, `s_move_to_destination`, `s_look_for_run`, closest-player helpers, player DF/OF objects. Browser now has role/formation/ball-relative AI. |
| Team AI | **B/C** | Formation/position and match-controller structures are recovered; exact tactical weighting is not source-readable. |
| Positioning | **B** | `s_player_positions_init`, `s_get_pitch_position_from_formation`, formation/tactics scripts recovered. Browser uses explicit formation anchors and ball-relative shifts. |
| Tactical behavior | **B/C** | `s_create_tactics`, `s_tactics_*`, formation scripts and tactics room recovered. Match runtime currently uses a balanced formation; tactical UI/runtime not fully ported. |
| Player switching | **B/C** | `s_match_controller_closest_facing_player` and controller input scripts recovered. Browser switches among nearest eligible players; exact original selection scoring remains approximate. |
| Collision/repulsion | **B/C** | `s_do_repulsion` is recovered. Browser has proximity/tackle possession resolution but not the complete original repulsion/collision solver. |
| Goal detection | **B** | `s_check_goal_bounderies`, `s_ball_is_crossing`, goal objects recovered. Browser has goal-mouth detection and restart flow. Exact net/post sequencing remains incomplete. |
| Match timer | **B/C numeric** | `s_match_time_remaining`, match-controller scripts recovered. Browser preserves 45/90 match phases; clock scale is an explicit browser-time approximation. |
| Match state | **B** | Match controller plus kickoff/half/full-time object/event structure recovered. Browser implements kickoff, halftime and fulltime states. |
| Half-time | **B** | `room_halftime` and match-controller phase evidence recovered. Browser implements halftime transition. |
| Full-time | **B** | Results/match-controller evidence recovered. Browser implements full-time state. |
| Camera | **B/C numeric** | `obj_camera`, `s_camera_setview`, `s_update_match_cam` recovered. Browser follows ball with smoothed camera; exact original easing is approximate. |
| Animations | **A/B** | Original sprite frames are recovered directly; state transitions use recovered animation/function names. Exact animation-state transition graph is incomplete. |
| Input | **B** | Match controller has keyboard, gesture, drag, finger and gamepad functions. Browser supports keyboard/pointer/touch-style drag. Exact platform-specific mapping is incomplete. |
| Game rules | **B/C** | Offside/restart/card/injury/substitution symbols are present. Only a subset is currently implemented; exact rules need further native-code tracing. |
| Set pieces | **B/C** | `s_is_setpiece`, `s_is_corner`, `s_is_throwin`, `s_count_restarts`, match kickoff functions recovered. Browser implements throw-in/corner/offside restart state, but not original animations/UI. |
| Fouls/tackles | **B/C** | `s_tackle_ball`, `s_check_for_cards`, `s_match_yellow`, `s_sent_off`, stat-tackle functions recovered. Browser has basic tackle possession; foul/card logic is not yet complete. |
| Substitutions | **Not implemented** | `s_count_subs_made`, `s_suitable_sub`, bench/lineup systems are recovered. |
| Match setup | **B** | `room_prematch`, `s_prematch_*`, `s_match_controller_init` and team/kit functions recovered. Browser has team selection but not full original prematch flow. |
| Team data | **A** | Team names/IDs/kit information are sourced from recovered APK data. |
| Difficulty | **Not implemented** | `s_options_increase_difficulty` and control-op/difficulty-related scripts are present. |
| Keeper AI | **B/C numeric** | `s_update_goalkeeper_position`, `s_do_keeper_closing`, `s_keeper_dive_ai`, `s_do_random_dive` recovered. Browser now has keeper positioning/ball collection, but dive timing is approximate. |
| Headers/volleys | **B/C** | `s_can_header`, `s_do_header`, volley cancellation/training symbols recovered. Browser does not yet reproduce the complete original aerial-control state machine. |
| Replay | **Not implemented** | `s_record_frame`, `s_start_replay`, `s_replay_frame` and replay UI assets/scripts are recovered. |
| Cards | **Not implemented** | Card objects and `s_check_for_cards`/`s_match_yellow`/`s_sent_off` are recovered. |
| Injuries/energy | **Not implemented** | `s_do_post_match_energy`, `s_process_injury`, `s_injury_recovery`, `s_check_for_injury` recovered. |
| Career progression | **Not implemented** | Rooms/scripts for career, contracts, transfers, standings, competitions, facilities, XP, morale, etc. are present. |
| Save/load | **Not implemented** | `load_savedgame_to_string`, `s_get_save_filename`, slot/options functions are recovered. |
| UI/menu flow | **A/B** | Original sprites/fonts and named rooms/scripts recovered. Current browser flow remains a reduced subset. |

## What changed in this audit pass

The existing renderer and recovered visual assets were retained. The match runtime was expanded to better follow the APK's recovered structure:

1. Player acceleration/deceleration rather than direct velocity assignment.
2. Explicit facing and movement state.
3. Role-based formation anchors.
4. Ball owner/possession state.
5. Dribble attachment state.
6. Pass vs shot actions.
7. Ball height/arc state.
8. Keeper positioning/collection behavior.
9. Formation-relative team AI.
10. Throw-in/corner/offside restart states.
11. Offside state tracking at pass time.
12. Tackle/interception possession logic.
13. 45-minute halftime and 90-minute fulltime state handling.
14. Smoothed match camera following the ball.
15. Original pass/kick/idle/run sprite states where assets exist.

These are **reimplementations informed by APK evidence**, not recovered original GML source. Where numeric constants could not be confidently reconstructed from the stripped YYC assembly, the code explicitly treats the tuning as approximate.

## Native-code findings

`readelf` confirms that the native library has a `.dynsym` section and no `.debug*` or `.symtab` section. Nevertheless, many GML functions remain globally symbolized. Examples include:

- `s_update_ball_movement`: 5,944 bytes at `0x0b82140`
- `s_control_ball`: 16,540 bytes at `0x0b7c578`
- `s_kick_ball`: 21,920 bytes at `0x0aa97fc`
- `s_tackle_ball`: 2,172 bytes at `0x0ab1ad4`
- `s_update_fundamentals`: 4,892 bytes at `0x0b50fe8`
- `s_move_to_destination`: 3,116 bytes at `0x0b54940`
- `s_update_goalkeeper_position`: recovered as a GML function symbol

The `s_update_ball_movement` body visibly reads object/global variables and calls other GameMaker runtime/script functions. This confirms that the symbols correspond to compiled executable behavior, not merely names copied into an asset manifest. It does **not**, by itself, reveal the original GML source or justify assuming a particular numeric formula.

## Remaining reverse-engineering priorities

1. Trace `obj_player_Step_0` and `obj_match_controller` control-flow paths into the native script bodies.
2. Recover variable-name/index relationships from the GameMaker resource tables so native variable accesses can be mapped to semantic fields.
3. Trace `s_kick_ball` → `s_get_kick_velocity` → `s_get_kick_tradjectory` to reconstruct exact shot/pass math.
4. Trace `s_control_ball`/`s_dribble_ball`/`s_tackle_ball` to reconstruct possession and tackle windows.
5. Trace `s_update_ball_height` plus post/bar/net functions for aerial collisions.
6. Trace `s_update_goalkeeper_position` and `s_keeper_dive_ai` for goalkeeper timing.
7. Recover exact formation/tactics data from formation/tactics scripts and room instances.
8. Port cards, injuries, substitutions and replay only after their original state transitions are mapped.
9. Port career/management systems from the existing rooms and data files rather than inventing a replacement progression model.
10. Add browser save/progression only after the original save schema is understood.

## Validation performed

- APK and browser ZIP re-extracted successfully.
- `game.droid` parsed as an IFF/FORM GameMaker container.
- 2,129 string entries recovered from the STRG chunk.
- 29 rooms and 71 objects identified from the resource graph.
- Native GML symbols and function sizes inspected with ELF symbol data.
- Browser JavaScript passes `node --check`.
- Runtime stress test initializes 14 players and advances through halftime to fulltime without NaN/Infinity state corruption.
- Explicit shooting/goal test produced a goal event.
- A Chromium HTTP render was attempted against a local static server; the execution environment kept Chromium alive until the test timeout and did not produce a screenshot. Therefore this environment still cannot provide a successful end-to-end visual browser capture, despite the static HTTP server itself responding with `200 OK`.

## Bottom line

The previous build should be described as **source-asset-accurate with an initially approximate match simulation**. After this pass, the match simulation is better aligned with the original GameMaker architecture and its recovered systems, but it is still a **browser-native reimplementation**, not the original game's GML code translated verbatim.
