# Retro Goal — Phase 1 Validation

## Status

**PHASE 1 — COMPLETE**

Phase 1 establishes a machine-readable resource relationship graph and a browser-side resolver over the recovered GameMaker resources. No recovered assets were replaced or discarded.

## Source of truth

- `assets/game.droid`
- `lib/arm64-v8a/libyoyo.so`
- recovered GameMaker chunks and decoded texture pages

## Deliverables

- `recovered/resource_manifest.json` — complete machine-readable inventory/relationship manifest
- `recovered/RESOURCE_GRAPH_AUDIT.md` — human-readable audit
- `gm_resource_manifest.js` — browser-loaded manifest
- `gm_resources.js` — `GMResourceRegistry`
- `index.html` — loads the registry before the production runtime

## Recovered inventory represented

- 295 sprites
- 1,011 texture-page items
- 29 rooms
- 71 objects
- 1,593 scripts
- 250 native object-event symbols
- recovered texture pages / atlases
- recovered fonts
- recovered shader source
- recovered audio
- recovered sprite/frame assets

## Relationship coverage

The manifest records:

```text
GameMaker resource
    ↓
resource type / metadata
    ↓
texture page + source rectangle
    ↓
sprite / frame
    ↓
object reference
    ↓
room instance / state
```

All 250 native object-event symbols are mapped to their decoded object names in the manifest.

Sprites without a decoded object reference remain in the manifest and on disk as preserved recovered/unused resources.

## Browser resolution checks

The registry was exercised against:

- `spr_title_player`
- its recovered frame mapping
- `room_title`
- `obj_master`
- `s_title_continue`
- `sh_ColorReplaceClip_fragment.glsl`
- complete manifest inventory

**7 / 7 registry checks passed.**

## Regression checks

Existing Phase 0 functional suite:

**11 / 11 tests passed.**

The suite still verifies:

`TITLE LOAD → ANIMATION → INPUT → HOME → PREMATCH → MATCH → PLAYER MOVEMENT → FULLTIME → RESULTS`

JavaScript syntax checks also pass for the production runtime and resource registry.

## HTTP serving check

A basic local HTTP server successfully returned HTTP 200 for:

- `index.html`
- `game.js`
- `gm_runtime_data.js`
- `gm_resource_manifest.js`
- `gm_resources.js`
- recovered title artwork
- recovered shader
- resource manifest JSON

## Provenance

**A — recovered:** GameMaker resource/data and exact decoded asset evidence.

**B — reimplemented:** browser resource-resolution layer and relationship model built from recovered structures.

**C — approximate:** not introduced by the Phase 1 resource graph itself.

## Gate result

Phase 1 satisfies implementation, integration, testing, regression, and provenance requirements. The project can now proceed to the separate animation-system phase.
