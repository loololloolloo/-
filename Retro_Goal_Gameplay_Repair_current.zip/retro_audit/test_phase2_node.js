'use strict';
const fs=require('fs'),vm=require('vm');
const base='/mnt/data/retro_next/retro_audit';
const noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}};
const document={getElementById:id=>id==='game'?canvas:{style:{},textContent:''},createElement:type=>type==='canvas'?{width:0,height:0,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(4)}),putImageData:noop})}: {}};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=64;this.naturalHeight=64;this.src='';}}
class AudioMock{constructor(src){this.src=src}play(){return Promise.resolve()}}
const listeners={};const context={window:{},document,Image:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:(t,f)=>listeners[t]=f,setInterval,clearInterval};
context.window.window=context.window;Object.assign(context.window,{document,Image:ImageMock,Audio:AudioMock,performance:context.performance,setTimeout,clearTimeout,Promise,requestAnimationFrame:noop,__RETRO_TEST_MODE__:true});
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
const R=context.window.__RETRO_GOAL_RUNTIME;const A=context.window.GM_ANIMATION_DATA;const out=[];const add=(name,ok,detail='')=>out.push({name,ok,detail});
add('animation data loaded',!!A && !!A.sprites, Object.keys(A?.sprites||{}).length);
add('all recovered sprites represented',Object.keys(A.sprites).length===295,Object.keys(A.sprites).length);
const frameTotal=Object.values(A.sprites).reduce((n,s)=>n+(s.frames?.length||0),0);add('recovered frame count represented',frameTotal===1008,frameTotal);
let missing=0;for(const s of Object.values(A.sprites))for(const f of s.frames||[]){if(!fs.existsSync(base+'/'+f.path))missing++;}add('all generated frame paths exist',missing===0,missing);
const a=new R.GMAnimation('spr_confetti',8);let seen=[];a.onFrame=f=>seen.push(f);for(let i=0;i<20;i++)a.update(.1);add('multi-frame animation advances',seen.length>0&&seen.includes(5),JSON.stringify({frame:a.frame(),seen:seen.slice(0,6)}));
a.set('spr_confetti',8);a.loop=false;for(let i=0;i<10;i++)a.update(.5);add('non-loop animation clamps at final frame',a.frame()===7&&a.playing===false,JSON.stringify({frame:a.frame(),playing:a.playing}));
const clips=['spr_keeper_idle2','spr_keeper_run2','spr_keeper_dive_u','spr_keeper_collect2','spr_ball1','spr_ball2','spr_title_player','spr_title_ball'];for(const n of clips)add('clip '+n+' resolves',!!A.sprites[n]&&A.sprites[n].frames.length>0,A.sprites[n]?.frames.length);
(async()=>{for(let i=0;i<20 && (!context.window.teams?.length && !context.teams?.length);i++)await new Promise(r=>setImmediate(r));R.Runtime.enter('room_prematch');R.InputManager.dispatch('confirm');R.update(.1);const gk=R.state.players.filter(p=>p.role==='GK');add('match contains recovered GK animation clips',gk.length===2&&gk.every(p=>['spr_keeper_idle2','spr_keeper_run2'].includes(p.animation.sprite)),gk.map(p=>p.animation.sprite).join(','));R.update(.1);add('ball has animation controller',!!R.state.ball?.animation&&['spr_ball1','spr_ball2'].includes(R.state.ball.animation.sprite),R.state.ball?.animation?.sprite);console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));})().catch(e=>{console.error(e.stack);process.exitCode=1});
