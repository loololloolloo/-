'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const base=__dirname,noop=()=>{};
class HTMLCanvasElementMock{constructor(){this.width=0;this.height=0;this._ctx={drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(32*32*4)}),putImageData:noop};}getContext(){return this._ctx}}
class HTMLImageElementMock{constructor(){this.complete=true;this.naturalWidth=32;this.naturalHeight=32;this.src=''}}
class ImageMock extends HTMLImageElementMock{constructor(){super()}}
class AudioMock{constructor(src){this.src=src}play(){return Promise.resolve()}}
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{},setPointerCapture:noop};
const document={getElementById:id=>({game:canvas,loading:{style:{}},hint:{textContent:''}}[id]||{style:{},textContent:''}),createElement:t=>t==='canvas'?new HTMLCanvasElementMock():{}};
const context={window:{},document,Image:ImageMock,HTMLImageElement:HTMLImageElementMock,HTMLCanvasElement:HTMLCanvasElementMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:noop};
context.window=context;context.window.window=context;context.window.document=document;context.window.Image=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(path.join(base,f),'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.__RETRO_GOAL_RUNTIME,out=[];const add=(n,o,d='')=>out.push({name:n,ok:!!o,detail:d});
 R.Runtime.enter('room_field','deep-gameplay-repair');
 add('live match initializes',R.state.screen==='match'&&R.state.players.length===14);
 add('pitch bounds align with recovered field raster',R.state.players.every(p=>p.y>=140&&p.y<=487));
 add('kickoff possession is active',R.state.ball.owner===R.state.controlled&&R.state.players[R.state.controlled].hasBall);
 const owner=R.state.players[R.state.controlled];
 const mate=R.state.players.find(p=>p.team===0&&p!==owner&&p.role==='FW'); const mx=mate.x,my=mate.y;
 for(let i=0;i<45;i++)R.update(.016);
 add('teammate makes an off-ball run while human has possession',Math.hypot(mate.x-mx,mate.y-my)>3,`${mx},${my} -> ${mate.x.toFixed(1)},${mate.y.toFixed(1)}`);
 // Restore controlled possession for drag test.
 R.state.ball.owner=R.state.controlled;owner.hasBall=true;R.state.ball.x=owner.x+15;R.state.ball.y=owner.y;
 const ok=R.humanDragKick({startX:owner.x-R.state.cam,startY:owner.y,endX:owner.x-R.state.cam+170,endY:owner.y-35,points:[{x:owner.x-R.state.cam,y:owner.y,t:0},{x:owner.x-R.state.cam+80,y:owner.y-28,t:40},{x:owner.x-R.state.cam+170,y:owner.y-35,t:80}]});
 add('drag gesture launches a shot',ok&&R.state.ball.owner===-1&&Math.hypot(R.state.ball.vx,R.state.ball.vy)>0);
 add('drag gesture produces a nonzero curve from swipe path',Math.abs(R.state.ball.curve)>0,R.state.ball.curve);
 const vx=R.state.ball.vx,vy=R.state.ball.vy;R.update(.016);add('curved ball trajectory changes velocity laterally',Math.hypot(R.state.ball.vx-vx,R.state.ball.vy-vy)>0.01);
 // Double-tap / tap-to-pass paths are available through the central input manager.
 R.state.ball.owner=R.state.controlled;owner.hasBall=true;add('central pass action is callable',R.InputManager.dispatch('pass')===true&&R.state.ball.owner===-1);
 // Goal geometry test using the recovered goal-mouth band.
 R.state.ball.owner=-1;R.state.ball.z=0;R.state.ball.vx=-2;R.state.ball.vy=0;R.state.ball.x=R.state.ball.x*0+73;R.state.ball.y=320;R.state.score=[0,0];R.state.restart=null;R.update(.016);add('goal-mouth collision uses goal-line band',R.state.score[1]===1,R.state.score);
 try{R.draw();add('full match renderer completes with players, ball and UI',true)}catch(e){add('full match renderer completes with players, ball and UI',false,e.message)}
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
