'use strict';
const C=document.getElementById('game'),X=C.getContext('2d');
X.imageSmoothingEnabled=false;
const W=C.width,H=C.height;
const A='assets/';
const imgCache=new Map();
function img(src){if(!imgCache.has(src)){const i=new Image();i.src=A+src;imgCache.set(src,i)}return imgCache.get(src)}
function loadImage(src){return new Promise(r=>{const i=img(src);if(i.complete)r(i);else i.onload=()=>r(i)})}
let teams=[];
let titleFont,bodyFont;
async function loadJSON(src){return fetch(src).then(r=>r.json())}
async function loadFont(name){const meta=name==='title'?window.FONT_TITLE:window.FONT_BODY;const im=await loadImage('fonts/'+name+'.png');return {meta,im}}
const keys={
 idleS:n=>`frames/spr_player_idle_stripes/${String(n%2).padStart(2,'0')}.png`,
 runS:n=>`frames/spr_player_run_stripes/${String(n%8).padStart(2,'0')}.png`,
 kickS:n=>`frames/spr_player_kick_stripes/${String(n%5).padStart(2,'0')}.png`,
 passS:n=>`frames/spr_player_pass_stripes/${String(n%1).padStart(2,'0')}.png`,
 slideS:n=>`frames/spr_player_slide_stripes/${String(n%3).padStart(2,'0')}.png`,
 idleH:n=>`frames/spr_player_idle_hoops/${String(n%2).padStart(2,'0')}.png`,
 runH:n=>`frames/spr_player_run_hoops/${String(n%8).padStart(2,'0')}.png`,
 kickH:n=>`frames/spr_player_kick_hoops/${String(n%5).padStart(2,'0')}.png`,
 passH:n=>`frames/spr_player_pass_hoops/${String(n%1).padStart(2,'0')}.png`,
 slideH:n=>`frames/spr_player_slide_hoops/${String(n%3).padStart(2,'0')}.png`,
 ballS:n=>`frames/spr_ball1/${String(n%6).padStart(2,'0')}.png`,
 ballH:n=>`frames/spr_ball2/${String(n%6).padStart(2,'0')}.png`
};
const field=img('field.png'),logo=img('title_logo.png'),splash=img('splash.png');
const button=img('button.png'),scoreboard=img('scoreboard.png');
const music=[img('track1.ogg'),img('track2.ogg'),img('track3.ogg')];
let audio=null;
function startMusic(){if(audio)return;audio=new Audio('assets/track1.ogg');audio.loop=true;audio.volume=.32;audio.play().catch(()=>{})}
const state={screen:'title',home:0,away:1,menu:0,selectSide:0,cam:0,score:[0,0],clock:0,half:1,paused:false,ended:false,flash:0,flashText:'',controlled:0,drag:null,players:[],ball:null,particles:[],last:performance.now(),kickCooldown:0};
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function teamColor(team,away=false){return away?team.away1:team.home1}
function hexRGB(h){h=(h||'#fff').replace('#','');if(h.length===6)return '#'+h;return '#fff'}
function txt(font,s,x,y,scale=1,align='left',alpha=1){if(!font)return;X.save();X.globalAlpha=alpha;X.imageSmoothingEnabled=false;let xx=x;if(align==='center')xx=x-textWidth(font,s,scale)/2;if(align==='right')xx=x-textWidth(font,s,scale);for(const ch of String(s)){if(ch==='\n'){y+=font.meta.h*scale;xx=x;continue}const g=font.meta.glyphs[String(ch.codePointAt(0))]||font.meta.glyphs['63'];if(!g){xx+=8*scale;continue}X.drawImage(font.im,g.x,g.y,g.w,g.h,Math.round(xx+g.offset*scale),Math.round(y),g.w*scale,g.h*scale);xx+=g.shift*scale}X.restore()}
function textWidth(font,s,scale=1){let w=0;for(const ch of String(s)){const g=font.meta.glyphs[String(ch.codePointAt(0))]||font.meta.glyphs['63'];w+=(g?g.shift:8)*scale}return w}
function buttonBox(x,y,w,h,label,active=false){X.save();X.globalAlpha=active?1:.86;X.drawImage(button,0,0,button.naturalWidth||98,button.naturalHeight||22,x,y,w,h);txt(bodyFont,label,x+w/2,y+6,h/22*.72,'center');X.restore()}
function initMatch(){
 state.score=[0,0];state.clock=0;state.half=1;state.paused=false;state.ended=false;state.flash=0;state.particles=[];state.kickCooldown=0;
 const formations=[[-1,0],[-.7,-.28],[-.7,.28],[-.35,-.12],[-.35,.12],[0,-.28],[0,.28]];
 state.players=[];
 for(let side=0;side<2;side++){
  const home=side===0, team=teams[home?state.home:state.away];
  formations.forEach((f,i)=>{let x=home?220+(f[0]+1)*420:1520-(f[0]+1)*420;let y=335+f[1]*180;state.players.push({team:side,x,y,vx:0,vy:0,home,idx:i,role:i===0?'GK':'P',anim:0,action:'idle',kick:0,targetX:x,targetY:y})})
 }
 state.ball={x:870,y:335,vx:0,vy:0,spin:0,owner:-1};state.controlled=1;state.cam=0;
}
function resetKickoff(){state.ball.x=870;state.ball.y=335;state.ball.vx=0;state.ball.vy=0;state.ball.owner=-1;state.players.forEach((p,i)=>{const home=p.team===0;p.x=home?p.targetX:1743-p.targetX;p.y=p.targetY;p.vx=p.vy=0;p.action='idle'});state.controlled=1;state.flash=0}
function nearestPlayer(team){let best=-1,bd=1e9;for(let i=0;i<state.players.length;i++){let p=state.players[i];if(p.team!==team)continue;let d=(p.x-state.ball.x)**2+(p.y-state.ball.y)**2;if(d<bd){bd=d;best=i}}return best}
function switchPlayer(){const i=nearestPlayer(0);if(i>=0)state.controlled=i}
function kick(dx,dy,power=7){const b=state.ball;if(state.kickCooldown>0)return;const l=Math.hypot(dx,dy)||1;b.vx=dx/l*power;b.vy=dy/l*power;b.owner=-1;state.kickCooldown=.18;const p=state.players[state.controlled];p.action='kick';p.anim=0}
function userKickToward(tx,ty){const p=state.players[state.controlled];const dx=tx-p.x,dy=ty-p.y;const near=Math.hypot(state.ball.x-p.x,state.ball.y-p.y)<48;if(near)kick(dx,dy,Math.min(13,6+Math.hypot(dx,dy)/90))}
function aiKick(i){const p=state.players[i],goalX=p.team===0?1660:80;let targetX=goalX,targetY=335+(Math.random()-.5)*160;const mate=state.players.filter(q=>q.team===p.team&&q!==p).sort((a,b)=>Math.abs(a.x-p.x)-Math.abs(b.x-p.x))[0];if(Math.random()<.34&&mate){targetX=mate.x;targetY=mate.y}kickAI(i,targetX,targetY)}
function kickAI(i,tx,ty){const p=state.players[i],b=state.ball,l=Math.hypot(tx-p.x,ty-p.y)||1;b.vx=(tx-p.x)/l*(5.2+Math.random()*2.2);b.vy=(ty-p.y)/l*(5.2+Math.random()*2.2);b.owner=-1;p.action='kick';p.anim=0}
function goal(team){state.score[team]++;state.flash=2.0;state.flashText='GOAL!';for(let i=0;i<80;i++)state.particles.push({x:870+(Math.random()-.5)*80,y:335+(Math.random()-.5)*60,vx:(Math.random()-.5)*5,vy:(Math.random()-.5)*5,life:1.2});setTimeout(()=>{if(state.screen==='match')resetKickoff()},850)}
function update(dt){
 if(state.screen!=='match'||state.paused||state.ended)return;
 state.kickCooldown=Math.max(0,state.kickCooldown-dt);state.flash=Math.max(0,state.flash-dt);
 state.clock+=dt*.5;if(state.clock>=45&&state.half===1){state.half=2;state.paused=true;state.flashText='HALF TIME';state.flash=99;setTimeout(()=>{state.paused=false;state.flash=0},1800)}
 if(state.clock>=90){state.ended=true;state.flashText='FULL TIME';state.flash=99;state.paused=true;return}
 const b=state.ball;
 // player movement / AI
 state.players.forEach((p,i)=>{
  const controlled=i===state.controlled;
  let tx=p.targetX,ty=p.targetY;
  const dist=Math.hypot(p.x-b.x,p.y-b.y);
  if(controlled){
   let ax=0,ay=0;if(keysDown.has('ArrowLeft')||keysDown.has('a'))ax--;if(keysDown.has('ArrowRight')||keysDown.has('d'))ax++;if(keysDown.has('ArrowUp')||keysDown.has('w'))ay--;if(keysDown.has('ArrowDown')||keysDown.has('s'))ay++;
   const sp=keysDown.has('Shift')?150:105; p.vx=ax*sp;p.vy=ay*sp;
   if(ax||ay){p.action='run';p.anim+=dt*12}else{p.action='idle';p.anim+=dt*5}
   if(dist<34&&b.owner<0){b.owner=i}
  }else{
   const chase=(p.team===b.owner?false:(i===nearestPlayer(p.team)||dist<150));
   if(chase){tx=b.x;ty=b.y}
   const dx=tx-p.x,dy=ty-p.y,l=Math.hypot(dx,dy)||1;const sp=55+(p.idx%3)*8;p.vx=dx/l*sp;p.vy=dy/l*sp;p.anim+=dt*7;p.action=l>5?'run':'idle';
   if(dist<25&&b.owner<0){if(Math.random()<dt*.9){b.owner=i;}}
  }
  p.x=clamp(p.x+p.vx*dt,70,1670);p.y=clamp(p.y+p.vy*dt,195,485);
  if(b.owner===i){b.x=p.x+(p.team===0?15:-15);b.y=p.y-3;b.vx=p.vx*.08;b.vy=p.vy*.08;if(!controlled&&Math.random()<dt*.8)aiKick(i)}
 });
 if(b.owner<0){b.x+=b.vx*60*dt;b.y+=b.vy*60*dt;b.vx*=Math.pow(.03,dt);b.vy*=Math.pow(.03,dt);b.spin+=dt*8;
  if(b.y<180||b.y>495){b.y=clamp(b.y,180,495);b.vy*=-.65}
  if(b.x<55&&b.y>275&&b.y<400){goal(1)} else if(b.x>1685&&b.y>275&&b.y<400){goal(0)} else {if(b.x<55||b.x>1685){b.vx*=-.65;b.x=clamp(b.x,55,1685)}}
 }
 state.cam=clamp(b.x-W*.5,0,1743-W);
 state.particles=state.particles.filter(q=>(q.life-=dt)>0);state.particles.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.vy+=.08})
}
function drawField(){X.drawImage(field,-Math.floor(state.cam),0);}
function drawPlayer(p,i){const team=teams[p.team===0?state.home:state.away];let frame=Math.floor(p.anim)%8;let src;if(p.action==='kick')src=p.team===0?keys.kickS(frame):keys.kickH(frame);else if(p.action==='run')src=p.team===0?keys.runS(frame):keys.runH(frame);else src=p.team===0?keys.idleS(frame):keys.idleH(frame);const im=img(src);const scale=1.55;const sx=p.x-state.cam-im.naturalWidth*scale/2,sy=p.y-im.naturalHeight*scale+8;X.drawImage(im,sx,sy,im.naturalWidth*scale,im.naturalHeight*scale);if(i===state.controlled){X.strokeStyle='#fff';X.lineWidth=2;X.beginPath();X.arc(p.x-state.cam,p.y+10,14,0,Math.PI*2);X.stroke();}}
function drawBall(){const im=img(keys.ballS(Math.floor(state.ball.spin)));const s=2;X.drawImage(im,state.ball.x-state.cam-im.naturalWidth*s/2,state.ball.y-im.naturalHeight*s/2,im.naturalWidth*s,im.naturalHeight*s)}
function drawMatch(){
 X.fillStyle='#000';X.fillRect(0,0,W,H);drawField();
 state.players.slice().sort((a,b)=>a.y-b.y).forEach((p,i)=>drawPlayer(p,state.players.indexOf(p)));
 drawBall();
 X.fillStyle='rgba(0,0,0,.58)';X.fillRect(0,0,W,42);
 const ht=teams[state.home],at=teams[state.away];txt(bodyFont,ht.short,24,13,1.3);txt(bodyFont,String(state.score[0]),220,8,2.0,'center');txt(bodyFont,'-',240,12,1.3,'center');txt(bodyFont,String(state.score[1]),260,8,2.0,'center');txt(bodyFont,at.short,278,13,1.3);
 const mins=Math.floor(state.clock),secs=Math.floor((state.clock-mins)*60);txt(bodyFont,`${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`,W-70,13,1.2,'center');
 txt(bodyFont,'WASD / ARROWS MOVE   SPACE SWITCH   X SHOOT   DRAG TO KICK',W/2,H-17,.72,'center',.9);
 if(state.paused||state.ended){X.fillStyle='rgba(0,0,0,.68)';X.fillRect(0,0,W,H);txt(titleFont,state.ended?'FULL TIME':'HALF TIME',W/2,185,2.0,'center');txt(bodyFont,`${ht.short} ${state.score[0]}  -  ${state.score[1]} ${at.short}`,W/2,245,1.2,'center');if(state.ended)txt(bodyFont,'ENTER TO RETURN',W/2,320,.9,'center')}
 if(state.flash>0&&!state.paused){txt(titleFont,state.flashText,W/2,125,2.0,'center');}
 for(const q of state.particles){X.fillStyle=['#fff','#f44','#4cf','#fc4'][Math.floor(q.life*10)%4];X.fillRect(q.x-state.cam,q.y,2,2)}
}
function drawTitle(){X.fillStyle='#000';X.fillRect(0,0,W,H);X.globalAlpha=.28;X.drawImage(splash,0,0,W,H);X.globalAlpha=1;X.drawImage(logo,(W-436)/2,70,436,87);txt(bodyFont,'BROWSER RECONSTRUCTION',W/2,185,.75,'center',.7);buttonBox(340,250,280,50,'QUICK MATCH',state.menu===0);buttonBox(340,315,280,50,'TEAM SELECT',state.menu===1);txt(bodyFont,'ENTER / TAP TO START',W/2,405,.8,'center');txt(bodyFont,'Original GameMaker assets + browser-native runtime',W/2,485,.55,'center',.55)}
function drawSelect(){X.fillStyle='#111';X.fillRect(0,0,W,H);X.drawImage(field,-390,0);X.fillStyle='rgba(0,0,0,.72)';X.fillRect(0,0,W,H);txt(titleFont,'SELECT TEAMS',W/2,45,1.45,'center');const h=teams[state.home],a=teams[state.away];txt(bodyFont,h.name,250,145,1.0,'center');txt(bodyFont,'VS',W/2,145,1.0,'center');txt(bodyFont,a.name,710,145,1.0,'center');drawKit(250,225,h,false);drawKit(710,225,a,true);txt(bodyFont,state.selectSide===0?'LEFT / RIGHT  HOME':'TAB: AWAY',250,380,.65,'center',state.selectSide===0?1:.5);txt(bodyFont,state.selectSide===1?'LEFT / RIGHT  AWAY':'TAB: HOME',710,380,.65,'center',state.selectSide===1?1:.5);buttonBox(350,425,260,50,'PLAY MATCH');}
function drawKit(x,y,t,away){X.fillStyle=hexRGB(away?t.away1:t.home1);X.fillRect(x-25,y-25,50,65);X.fillStyle=hexRGB(away?t.away2:t.home2);X.fillRect(x-25,y-25,50,12);X.fillStyle='#fff';X.fillRect(x-17,y+40,14,28);X.fillRect(x+3,y+40,14,28);}
function draw(){if(state.screen==='title')drawTitle();else if(state.screen==='select')drawSelect();else drawMatch()}
const keysDown=new Set();
addEventListener('keydown',e=>{keysDown.add(e.key);if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();if(e.key==='ArrowUp'&&state.screen==='title')state.menu=0;if(e.key==='ArrowDown'&&state.screen==='title')state.menu=1;if(e.key==='Tab'&&state.screen==='select'){e.preventDefault();state.selectSide=1-state.selectSide}if(e.key==='Enter'||e.key===' '){startMusic();if(state.screen==='title'){state.screen=state.menu===1?'select':'match';if(state.screen==='match')initMatch()}else if(state.screen==='select'){state.screen='match';initMatch()}else if(state.ended){state.screen='title';state.ended=false}}if(state.screen==='select'&&(e.key==='ArrowLeft'||e.key==='a')){if(state.selectSide===0)state.home=(state.home+teams.length-1)%teams.length;else state.away=(state.away+teams.length-1)%teams.length;if(state.away===state.home)state.away=(state.away+teams.length-1)%teams.length}if(state.screen==='select'&&(e.key==='ArrowRight'||e.key==='d')){if(state.selectSide===0)state.home=(state.home+1)%teams.length;else state.away=(state.away+1)%teams.length;if(state.away===state.home)state.away=(state.away+1)%teams.length}if(state.screen==='match'&&e.key.toLowerCase()==='x'){const p=state.players[state.controlled];userKickToward(p.team===0?1660:80,335)}if(state.screen==='match'&&e.key==='Tab'){e.preventDefault();switchPlayer()}});
addEventListener('keyup',e=>keysDown.delete(e.key));
C.addEventListener('pointerdown',e=>{const r=C.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;startMusic();if(state.screen==='title'){if(y>300&&y<380)state.menu=1;else if(y>235&&y<300)state.menu=0;state.screen=state.menu===1?'select':'match';if(state.screen==='match')initMatch();return}if(state.screen==='select'){if(y>410){state.screen='match';initMatch()}return}if(state.screen==='match'&&!state.paused&&!state.ended){state.drag={x,y};}});
C.addEventListener('pointerup',e=>{if(!state.drag||state.screen!=='match')return;const r=C.getBoundingClientRect(),x=(e.clientX-r.left)*W/r.width,y=(e.clientY-r.top)*H/r.height;const sx=state.drag.x,sy=state.drag.y;state.drag=null;const p=state.players[state.controlled];userKickToward(x+state.cam,y);});
C.addEventListener('click',()=>startMusic());
let last=performance.now();function loop(now){const dt=Math.min(.033,(now-last)/1000);last=now;update(dt);draw();requestAnimationFrame(loop)}
Promise.all([Promise.resolve(window.TEAMS),loadFont('title'),loadFont('body'),loadImage('field.png'),loadImage('title_logo.png')]).then(v=>{teams=v[0];titleFont=v[1];bodyFont=v[2];document.getElementById('loading').style.display='none';document.getElementById('hint').textContent='Tap/click to start • keyboard and pointer controls supported';requestAnimationFrame(loop)});
