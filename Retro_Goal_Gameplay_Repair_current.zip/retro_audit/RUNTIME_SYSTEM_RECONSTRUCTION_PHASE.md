# Runtime systems reconstruction — phase 3

This phase preserves the previous browser renderer, recovered assets, player shader, and match runtime. The change is architectural: the browser now has a GameMaker-derived room/object/script graph and uses it as the state-machine authority.

## APK evidence recovered

- 29 GameMaker rooms were parsed from `ROOM`.
- 71 GameMaker object definitions were parsed from `OBJT`.
- 1,593 script/resource names were parsed from `SCPT`.
- 250 native `gml_Object_obj_*` event functions were identified in the YYC ELF.
- The title-specific native script family is present:
  - `s_title_init`
  - `s_title_create_anim`
  - `s_title_step`
  - `s_title_draw_gui`
  - `s_title_scroll_draw`
  - `s_title_set_opacity`
  - `s_title_continue`
  - `s_title_exit`
  - `s_title_create_video`
  - `s_title_step_video`
  - `s_title_draw_gui_video`
- `s_title_exit` was disassembled and explicitly calls `gml_Script_s_goto_room`.
- `obj_master` and `obj_room_manager` are the room-level persistent controllers; their native Create/Step events call the corresponding recovered GML scripts.

## Room graph

The actual room names recovered from the APK are:

`room_title`, `room_splash`, `room_home`, `room_field`, `room_options`, `room_results`, `room_prematch`, `room_halftime`, `room_standings`, `room_base`, `room_newcareer`, `room_favouriteteam`, `room_lineup`, `room_weekend`, `room_roster`, `room_profile`, `room_office`, `room_formation`, `room_tactics`, `room_freeagents`, `room_seasonend`, `room_prospects`, `room_trophies`, `room_store`, `room_achievements`, `room_staffhires`, `room_records`, `room_hof`, `room_teamrecords`.

The browser runtime now stores this graph in `recovered/gm_runtime_graph.json` and exposes it to the application through `gm_runtime_data.js`.

## Title runtime

The title is no longer a static screen transition.

The browser now has a title state with:

`intro → idle/ready → exit/fade → room transition`

The state is explicitly associated with the recovered GameMaker title script family. The player and ball now animate during the title state rather than being rendered as fixed images.

The exact motion constants are **not** claimed to be recovered. The YYC binary is stripped and the title script's static room target is behind a runtime GOT slot. Those numeric motion/target details remain marked as approximation/unresolved rather than being presented as original values.

## Title input

The browser input path now models the recovered script ownership:

`pointer/keyboard → s_title_continue → s_title_exit → s_goto_room`

instead of directly doing `canvas.onclick = showTeamSelect`.

Mouse/pointer and keyboard Enter/Space both use the same title transition state. Touch works through the pointer event path.

## Generic room host

Non-match rooms are now entered through the recovered GameMaker room graph rather than independent `screen` implementations. The current generic host intentionally does **not** claim to reproduce native Draw GUI behavior that has not yet been recovered.

The current flow shell follows recovered room relationships for the career/menu graph and routes into the existing prematch and match runtime.

## Provenance

### A — Directly recovered

Room names, dimensions, object definitions, room instances, layer metadata, script names, native YYC event symbols, sprite resources and asset references.

### B — Reverse-engineered/reimplemented

The browser room/state host, title lifecycle, animation state machine, and transition ownership are reimplemented from the recovered GameMaker structure and native script evidence.

### C — Approximation / unresolved

Exact title animation numeric constants and the static target value held behind the stripped YYC/GOT room-transition reference. These are explicitly marked in the runtime rather than silently presented as authentic.

## Phase 0 blocker-fix update — 2026-09-14

The title input path is now centralized through `InputManager`, and the browser title state mirrors the native `_title_stage`, `_title_stage_time`, `_title_opacity`, and `_title_out_delay` variables. Native disassembly shows `s_title_step` invoking `s_button_snd_click`, `s_title_continue`, and `s_title_set_opacity`, while `s_title_exit` invokes `s_goto_room`. The browser reimplementation records this sequence and preserves the unresolved compiled room constant as provenance metadata instead of inventing a recovered value.

`GMAnimation` now provides a reusable GameMaker-style sprite animation abstraction and is connected to match player animation selection. Title rendering is now expressed in the recovered 480×270 `room_title` coordinate system; the 584×26 digital overlay is drawn once and not tiled.

Automated runtime integration validation is recorded in `PHASE0_VALIDATION.md` and `test_phase0_node.js`. A terminating Chromium session was not available in the current execution environment, so Phase 0 remains gated on a real-browser fresh-load demonstration.
