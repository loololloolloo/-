'use strict';
const fs=require('fs'),vm=require('vm');
const base=__dirname, noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?{width:0,height:0,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(4)}),putImageData:noop})}: {}};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=960;this.naturalHeight=540;this.src=''} }
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1}play(){return Promise.resolve()}}
const listeners={};
const context={window:{},document,Image:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:(t,f)=>(listeners[t]=f)};
context.window=context;context.window.window=context;context.window.document=document;context.window.Image=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.__RETRO_GOAL_RUNTIME;const out=[];R.Runtime.enter('room_home','phase5-test');const add=(name,ok,detail='')=>out.push({name,ok,detail});
 add('home exposes all recovered button actions',R.state.homeUI.buttons.length===9,R.state.homeUI.buttons.length);
 add('home continue hit is inside logical room coordinates',R.HomeUI.hit(20,350)===-1,R.HomeUI.hit(20,350));
 add('first home action hit resolves from logical coordinates',R.HomeUI.hit(350,130)===0,R.HomeUI.hit(350,130));
 add('second home column resolves',R.HomeUI.hit(575,130)===1,R.HomeUI.hit(575,130));
 add('home uses recovered button frame resources',!!context.GM_ANIMATION_DATA.sprites.spr_button && context.GM_ANIMATION_DATA.sprites.spr_button.frames.length===3,'');
 R.Runtime.enter('room_home'); R.draw(); add('home renderer completes with recovered resources',true);
 R.Runtime.enter('room_prematch'); R.draw(); add('prematch renderer completes',true);
 for(const room of ['room_standings','room_results','room_options','room_lineup','room_weekend','room_office','room_records','room_store','room_formation','room_tactics']){R.Runtime.enter(room);R.draw();add(room+' renderer completes',true)}
 // fresh title/menu/match regression
 R.Runtime.enter('room_title');for(let i=0;i<90;i++)R.update(.016);R.InputManager.dispatch('confirm');for(let i=0;i<40;i++)R.update(.016);add('title to home regression',R.state.runtimeRoom==='room_home',R.state.runtimeRoom);
 R.InputManager.dispatch('confirm');add('home continue launches match regression',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',R.state.runtimeRoom);
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
