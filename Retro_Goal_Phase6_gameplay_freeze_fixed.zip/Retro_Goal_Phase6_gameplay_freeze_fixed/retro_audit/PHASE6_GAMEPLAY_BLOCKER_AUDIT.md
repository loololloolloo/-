# Retro Goal — Phase 6 Gameplay Blocker Audit

## User-reported blocker

After entering `room_field`, the browser displayed the pitch but no players, ball, HUD, or live gameplay. The supplied screen recording showed the same state persisting after the transition from the home screen.

## Root cause isolated

The match renderer drew the field first and then entered `drawGoal()`. The goal images were runtime `Image` objects but were **not included in the Phase 6 startup preload list**. In a cold browser cache, `drawImage()` was therefore called with an image element that had not completed loading. Chromium can throw for this condition, aborting the remainder of the frame's `drawMatch()` call.

That explains the exact observed symptom: the field had already been painted, while everything drawn after `drawField()` — players, ball, scoreboard and controls — never reached the canvas.

This was a renderer lifecycle bug, not evidence that the match simulation itself was absent.

## Fix

1. Added `spr_goal_fore` and `spr_goal_back` to the startup preload set.
2. Made `drawGoal()` explicitly test both images with the shared `drawableAsset()` guard before calling `drawImage()`.
3. If either goal asset is still cold, the goal draw is skipped for that frame instead of aborting the entire match renderer.
4. The rest of the match continues updating independently of the goal asset load state.
5. Added a regression test that deliberately marks both goal images as unloaded and verifies the complete match renderer still finishes.

## Gameplay verification

`test_phase6_gameplay_node.js`: **13/13 PASS**

Verified:

- live match starts
- 14 players created
- controlled player inside camera viewport
- held movement changes position
- run animation advances
- shooting consumes kickoff possession
- ball physically moves after shot
- AI continues updating
- match clock advances
- camera remains bounded
- full renderer completes
- **cold goal textures cannot freeze renderer**
- clean match re-entry resets playable kickoff

Earlier Phase 6 regression suite: **11/11 PASS**.

## Important testing limitation

A real Chromium capture is not available in this execution environment because the supplied environment's Chromium instance cannot load the local test origin reliably. The user-provided recording is therefore treated as the manual-browser evidence for the blocker, while the Node/browser-runtime harness is used for deterministic regression coverage.

## Status

The freeze blocker is fixed in the current working build. Do not advance to the next reconstruction phase until the user manually verifies that this build renders the players/ball and accepts movement after `PLAY NEXT`.
