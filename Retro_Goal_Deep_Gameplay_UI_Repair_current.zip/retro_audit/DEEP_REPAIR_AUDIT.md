# Retro Goal — Deep APK Repair Audit

This checkpoint is based on the recovered GameMaker resource graph, `game.droid`, recovered SPRT/TPAG metadata, recovered shader source, and YYC/native symbol evidence.

## Player texture root cause

The player artwork is not a normal RGB sprite. The recovered `spr_player_*_stripes` / `spr_player_*_hoops` frames contain the flat rainbow key palette consumed by the native `sh_ColorReplaceClip` shader.

Recovered native shader key mapping:

- hair `#ff0000`
- shirt `#ffff00`
- shirt2 `#808000`
- skin `#00ff00`
- skin2 `#008000`
- shorts `#0000ff`
- shorts2 `#800080`
- socks `#00ffff`
- socks2 `#008080`
- stripes `#ff00ff`
- stripes2 `#000080`
- boots `#000000`

The shader uses an RGB epsilon of `0.009`, so the browser implementation now uses a 3/255 channel tolerance rather than only exact RGB equality.

Native skin/hair values recovered from `s_get_skin_colour_by_index` are preserved:

- skin 0 `#EEC39A`
- skin 1 `#BA8857`
- skin 2 `#5D3324`
- hair 0 `#FAC80A`
- hair 1 `#5A2D08`
- hair 2 `#141414`

The renderer no longer falls back to the home team's idle raster when an animation frame is still loading. It falls back to frame 0 of the *same action and kit*.

## Player animation

The runtime selects recovered GameMaker sprites by gameplay state:

- idle
- run
- pass
- kick
- slide
- goalkeeper idle/run/collect/dive

Frame metadata and origins are read from `GM_ANIMATION_DATA`, rather than inventing frame rectangles.

## Goal geometry

The recovered `field.png` already contains the visible goal geometry. The previous browser build had a second invented goal overlay and a rectangular goal collision test. The visible overlay is no longer drawn.

Goal detection now uses a perspective goal plane derived from the recovered field raster, with the visible mouth band at approximately `y=265..378`. Post collision checks occur before normal pitch boundary handling.

## Drag-to-shoot

The recovered controller contains separate drag start / drag / drag end gestures and the gameplay script family includes aim mode, kick velocity, kick trajectory, and kick power throttling. The browser runtime now retains the complete pointer path and derives:

- shot direction
- power from drag length
- lateral curve from the drag path
- live curved-ball velocity change
- aim-preview trajectory

## Teammates

The AI now uses possession-aware support behavior instead of formation-only parking:

- nearest-player pressure
- defensive cover lanes
- forward runs
- support positioning around the ball carrier
- passing-lane checks
- AI shooting when advanced
- goalkeeper positioning

## Fixed-step simulation

The browser simulation now advances in 60 Hz fixed steps with a bounded accumulator. This prevents render-frame cadence from changing gameplay behavior.

## UI / application graph

Recovered room graph contains 29 rooms, including:

`room_title`, `room_home`, `room_prematch`, `room_field`, `room_options`, `room_results`, `room_halftime`, `room_standings`, `room_lineup`, `room_weekend`, `room_roster`, `room_profile`, `room_office`, `room_formation`, `room_tactics`, `room_freeagents`, `room_seasonend`, `room_prospects`, `room_trophies`, `room_store`, `room_achievements`, `room_staffhires`, `room_records`, `room_hof`, and `room_teamrecords`.

Home actions are mapped from recovered script names such as:

- `s_home_btn_standings`
- `s_home_btn_schedule`
- `s_home_btn_cupschedule`
- `s_home_btn_lineup`
- `s_home_btn_office`
- `s_home_btn_results`
- `s_home_btn_records`
- `s_home_btn_store`
- `s_home_btn_options`

UI rendering uses recovered GameMaker button, panel, header, card, icon, arrow, field-model, trophy, league-logo and match-card resources.

## Provenance rule

This remains a browser-native reimplementation. The original YYC machine code is not executed as JavaScript. Browser behavior is reconstructed from the original GameMaker resources and compiled-code evidence.
