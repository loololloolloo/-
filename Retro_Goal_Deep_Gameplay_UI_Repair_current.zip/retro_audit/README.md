# Retro Goal — browser-native reconstruction

This build reconstructs a playable core of the supplied `Retro_Goal-1.0.1.apk` without executing the APK, an Android compatibility layer, a streamed copy, or a screenshot-only imitation.

## What was recovered

- Identified the application as **Retro Goal** by New Star Games.
- Identified the runtime as **GameMaker / YoYo Runner**, with `assets/game.droid` as the GameMaker data container and `lib/arm64-v8a/libyoyo.so` as a YYC native build.
- Parsed the GameMaker FORM container and inventory of `GEN8`, `SOND`, `SPRT`, `FONT`, `OBJT`, `ROOM`, `TPAG`, `STRG`, `TXTR`, and `AUDO` chunks.
- Reverse-decoded GameMaker's `2zoq` / `fioq` texture pipeline (BZip2 + GameMaker's modified QOI-like encoding) and reconstructed the original texture pages.
- Reconstructed sprite-to-texture-page references and exported original sprite frames.
- Recovered the two embedded GameMaker fonts (`Upheaval Pro` and `Press Start`) as bitmap font atlases plus glyph metadata.
- Reused original team data from the APK's `assets/v1/teams.txt` and original English UI strings as source data.
- Reused original music tracks from the APK.

## Browser runtime

The playable runtime is native HTML5 Canvas + JavaScript. It does **not** execute the Android binary.

Implemented core systems:

- title / team-selection flow
- original field, logo, player, ball and UI assets
- 7v7 arcade match simulation
- player AI and possession
- player switching
- movement, dribbling and kick/shoot controls
- ball physics, bounces and goal detection
- score and match clock / half-time / full-time states
- camera following the ball
- original pixel-art rendering behavior (nearest-neighbour / pixelated presentation)
- keyboard + pointer/touch controls
- original music playback

## Run

Serve this directory over HTTP (rather than opening `index.html` directly):

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/` in a browser.

## Controls

- **WASD / Arrow keys:** move the controlled player
- **Space:** switch to nearest player
- **X:** shoot toward the opponent goal
- **Pointer/touch drag:** aim and kick
- **Enter / tap:** advance menus

## Validation

The included build was tested with a local HTTP server and Chromium. The test checks the title screen, team selection, match scene, recovered textures, animation frames, pointer input, keyboard input, score/clock rendering and a goal/reset path.

The project deliberately focuses on a functional browser-native match reconstruction rather than pretending that every management screen and every native platform service has been ported.

## Deep gameplay / texture repair checkpoint

This build includes a second-pass repair of the recovered player shader pipeline, action-specific player fallback, perspective goal detection, post collision, fixed-step simulation, drag-to-curve shooting, possession-aware teammate support, and renderer guards.

Run on an HTTP/HTTPS origin rather than `file://`. The extracted GameMaker assets are served from the project `assets/` tree.

Primary validation:

- `node test_gameplay_repair.js`
- `python test_player_texture_pipeline.py`
- phase regression tests `test_phase0_node.js` through `test_phase6_node.js`
