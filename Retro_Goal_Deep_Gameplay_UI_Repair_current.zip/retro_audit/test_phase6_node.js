'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const base=__dirname,noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1},{get(t,p){if(p in t)return t[p];return noop},set(t,p,v){t[p]=v;return true}});
const canvas={width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}};
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:t=>t==='canvas'?new HTMLCanvasElementMock(): {}};
class HTMLCanvasElementMock{constructor(){this.width=0;this.height=0;this._ctx={drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(32*32*4)}),putImageData:noop,clearRect:noop};}getContext(){return this._ctx}}
class HTMLImageElementMock{constructor(){this.complete=true;this.naturalWidth=32;this.naturalHeight=32;this.src=''}}
class ImageMock extends HTMLImageElementMock{constructor(){super()}}
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1}play(){return Promise.resolve()}}
const context={window:{},document,Image:ImageMock,HTMLCanvasElement:HTMLCanvasElementMock,HTMLImageElement:HTMLImageElementMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,requestAnimationFrame:noop,addEventListener:noop};
context.window=context;context.window.window=context;context.window.document=document;context.window.Image=ImageMock;context.window.Audio=AudioMock;context.window.performance=context.performance;context.window.setTimeout=setTimeout;context.window.clearTimeout=clearTimeout;context.window.Promise=Promise;context.window.requestAnimationFrame=noop;context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js'])vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
 await new Promise(r=>setImmediate(r)); const R=context.__RETRO_GOAL_RUNTIME,out=[];const add=(name,ok,detail='')=>out.push({name,ok,detail});
 R.Runtime.enter('room_field','phase6-test');
 add('match creates 14 players',R.state.players.length===14,R.state.players.length);
 add('match room uses recovered 1743px world width',R.state.cam>=0&&R.state.cam<=783,R.state.cam);
 add('controlled player is immediately inside viewport',R.state.players[R.state.controlled].x-R.state.cam>100&&R.state.players[R.state.controlled].x-R.state.cam<860,R.state.players[R.state.controlled].x-R.state.cam);
 add('kickoff ball is owned by controlled player',R.state.ball.owner===R.state.controlled,`${R.state.ball.owner}/${R.state.controlled}`);
 const before=R.state.players[R.state.controlled].x;vm.runInContext("keysDown.add('ArrowRight')",context);R.update(.1);vm.runInContext("keysDown.delete('ArrowRight')",context);
 add('player movement changes world position',R.state.players[R.state.controlled].x!==before,`${before}->${R.state.players[R.state.controlled].x}`);
 for(let i=0;i<60;i++)R.update(.016);
 const px=R.state.players[R.state.controlled].x-R.state.cam;
 add('camera follows active player instead of leaving him at edge',px>260&&px<700,px);
 add('camera remains within room bounds',R.state.cam>=0&&R.state.cam<=783,R.state.cam);
 const names=['spr_player_idle_stripes','spr_player_idle_hoops','spr_player_run_stripes','spr_player_run_hoops','spr_player_kick_stripes','spr_player_kick_hoops','spr_player_pass_stripes','spr_player_pass_hoops','spr_player_slide_stripes','spr_player_slide_hoops','spr_keeper_idle2','spr_keeper_run2','spr_keeper_collect2','spr_keeper_dive_u','spr_ball1','spr_ball2'];
 let missing=[];for(const n of names){const m=context.GM_ANIMATION_DATA.sprites[n];if(!m||!m.frames.length)missing.push(n);for(const f of (m?.frames||[])){const rel=f.path.startsWith('assets/')?f.path.slice(7):f.path;if(!fs.existsSync(path.join(base,'assets',rel)))missing.push(rel)}}
 add('all gameplay animation families resolve to real files',missing.length===0,missing.slice(0,5).join(',')||'16 families verified');
 // render-path smoke: drawMatch must execute with real state without throwing.
 try{R.draw();add('match renderer completes after camera/player integration',true)}catch(e){add('match renderer completes after camera/player integration',false,e.message)}
 // basic goal and fulltime state paths
 R.state.ball.x=R.state.ball.x+1;R.InputManager.dispatch('shoot');
 add('shoot input is accepted during live match',true);
 R.state.restart=null;R.state.paused=false;R.state.half=2;R.state.clock=90;R.update(.016);add('fulltime state still works after gameplay integration',R.state.ended&&R.state.paused,`${R.state.ended}/${R.state.paused}`);
 console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
