from PIL import Image
from pathlib import Path
ROOT=Path(__file__).parent
KIT={
'hair':'#141414','shirt':'#FF0000','shirt2':'#FFFFFF','skin':'#EEC39A','skin2':'#BA8857',
'shorts':'#FFFFFF','shorts2':'#CCCCCC','socks':'#FFFFFF','socks2':'#FF0000','stripes':'#FFFFFF','stripes2':'#FF0000','boots':'#141414'}
SRC={
'hair':'#ff0000','shirt':'#ffff00','shirt2':'#808000','skin':'#00ff00','skin2':'#008000',
'shorts':'#0000ff','shorts2':'#800080','socks':'#00ffff','socks2':'#008080','stripes':'#ff00ff','stripes2':'#000080','boots':'#000000'}
def rgb(h): return tuple(bytes.fromhex(h[1:]))
frames=['spr_player_idle_stripes','spr_player_run_stripes','spr_player_kick_stripes','spr_player_pass_stripes','spr_player_slide_stripes','spr_player_idle_hoops','spr_player_run_hoops','spr_player_kick_hoops']
changed=0
for sprite in frames:
    p=ROOT/'assets'/'frames_gm'/sprite/'00.png'
    im=Image.open(p).convert('RGBA'); pix=im.load(); local=0
    for y in range(im.height):
        for x in range(im.width):
            r,g,b,a=pix[x,y]
            if a!=255: continue
            for k,src in SRC.items():
                sr,sg,sb=rgb(src)
                if abs(r-sr)<=3 and abs(g-sg)<=3 and abs(b-sb)<=3:
                    q=rgb(KIT[k]);pix[x,y]=(*q,255);local+=1;break
    assert local>0, f'{sprite}: no shader-key pixels found'
    changed+=local
    out=ROOT/'recovered'/'texture_tests'
    out.mkdir(exist_ok=True)
    im.save(out/(sprite+'_arsenal.png'))
print(f'PASS: {len(frames)} player action/kit frames recoloured; {changed} opaque pixels replaced with native shader key mapping.')
