'use strict';
const fs=require('fs'), vm=require('vm');
const base=__dirname;
const noop=()=>{};
const ctx=new Proxy({imageSmoothingEnabled:false,globalAlpha:1}, {get(t,p){if(p in t)return t[p]; if(p==='measureText')return()=>({width:0}); return noop}, set(t,p,v){t[p]=v;return true}});
function mockCanvas(){return {width:960,height:540,getContext:()=>ctx,addEventListener:noop,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),style:{}}}
const canvas=mockCanvas();
const els={game:canvas,loading:{style:{}},hint:{textContent:''}};
const document={getElementById:id=>els[id]||{style:{},textContent:''},createElement:type=>type==='canvas'?{width:0,height:0,getContext:()=>({drawImage:noop,getImageData:()=>({data:new Uint8ClampedArray(4),}),putImageData:noop})}:{}};
class ImageMock{constructor(){this.complete=true;this.naturalWidth=960;this.naturalHeight=540;this.src='';} }
class AudioMock{constructor(src){this.src=src;this.loop=false;this.volume=1;}play(){return Promise.resolve()}}
const listeners={};
const context={window:{},document,Image:ImageMock,Audio:AudioMock,performance:{now:()=>Date.now()},console,setTimeout,clearTimeout,Promise,Math,Uint8ClampedArray,KeyboardEvent:function(type,init){return {...init,type}},requestAnimationFrame:noop,addEventListener:(t,f)=>(listeners[t]=f),setInterval,clearInterval};
context.window=context.window; context.window.window=context.window; context.window.document=document; context.window.Image=ImageMock; context.window.Audio=AudioMock; context.window.performance=context.performance; context.window.setTimeout=setTimeout; context.window.clearTimeout=clearTimeout; context.window.Promise=Promise; context.window.requestAnimationFrame=noop; context.window.__RETRO_TEST_MODE__=true;
vm.createContext(context);
for(const f of ['data.js','visual_meta.js','gm_runtime_data.js','gm_resource_manifest.js','gm_animation_data.js','gm_resources.js','gm_ui_runtime.js','game.js']) vm.runInContext(fs.readFileSync(base+'/'+f,'utf8'),context,{filename:f});
(async()=>{
  for(let i=0;i<50&&!context.window.__RETRO_GOAL_RUNTIME;i++) await new Promise(r=>setImmediate(r));
  const R=context.window.__RETRO_GOAL_RUNTIME; const out=[]; const add=(name,ok,detail)=>out.push({name,ok,detail});
  await new Promise(r=>setImmediate(r));
  add('runtime exposed',!!R,'');
  add('title room loaded',R.state.runtimeRoom==='room_title',R.state.runtimeRoom);
  R.update(.016);
  const p0=R.state.title.playerX; for(let i=0;i<100;i++)R.update(.016);
  add('title animation runs',R.state.title.playerX!==p0 || R.state.title.t>0,JSON.stringify(R.state.title));
  for(let i=0;i<5;i++)R.update(.016);
  add('title becomes input-ready',R.state.title.ready===true,R.state.title.phase);
  R.Runtime.enter('room_title','queued-input-test'); R.state.title.stage=0; R.state.title.stageTime=0; R.state.title.ready=false; R.state.title.pendingConfirm=false; R.InputManager.dispatch('confirm');
  for(let i=0;i<100;i++)R.update(.016);
  add('intro confirmation is not lost',R.state.title.phase==='exit'&&R.state.title.continueRequested===true,R.state.title.phase);
  R.Runtime.enter('room_title','continue-flow'); R.state.title.stage=1; R.state.title.ready=true; R.state.title.continueRequested=false; R.state.title.pendingConfirm=false;
  const transitionBefore=R.state.transition;
  R.InputManager.dispatch('confirm');
  add('title confirm enters transition',R.state.title.phase==='exit' && R.state.transition!==transitionBefore,JSON.stringify(R.state.transition));
  // Reset title and exercise the same centralized pointer path used by mouse/touch.
  R.Runtime.enter('room_title','pointer-test'); R.state.title.ready=true; R.InputManager.pointer(480,270);
  add('pointer/touch path enters title transition',R.state.title.phase==='exit'&&R.state.title.continueRequested===true,R.state.title.phase);
  R.Runtime.enter('room_title','continue-flow'); R.state.title.stage=1; R.state.title.ready=true; R.state.title.continueRequested=false; R.InputManager.dispatch('confirm');
  for(let i=0;i<40;i++)R.update(.016);
  add('title transition reaches home',R.state.runtimeRoom==='room_home'&&R.state.screen==='system',R.state.runtimeRoom);
  R.InputManager.dispatch('confirm');
  add('home continue launches live match',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',R.state.runtimeRoom);
  R.Runtime.enter('room_prematch','phase0-prematch-regression');
  add('prematch room remains reachable',R.state.runtimeRoom==='room_prematch'&&R.state.screen==='select',R.state.runtimeRoom);
  R.InputManager.dispatch('right');
  const home=R.state.home,away=R.state.away; R.InputManager.dispatch('confirm');
  add('prematch confirm launches match',R.state.runtimeRoom==='room_field'&&R.state.screen==='match',JSON.stringify({home,away}));
  const cp=R.state.players[R.state.controlled]; const x=cp.x,y=cp.y;
  const kd=listeners.keydown; kd({key:'ArrowRight',preventDefault:noop}); for(let i=0;i<20;i++)R.update(.016); listeners.keyup?.({key:'ArrowRight'});
  add('central keyboard input moves player',cp.x!==x||cp.y!==y,JSON.stringify({x,y,x1:cp.x,y1:cp.y}));
  R.state.ended=true; R.InputManager.dispatch('confirm');
  add('fulltime result transition',R.state.runtimeRoom==='room_results'&&R.state.screen==='system',R.state.runtimeRoom);
  console.log(JSON.stringify({pass:out.every(x=>x.ok),tests:out},null,2));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
